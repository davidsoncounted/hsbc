<!doctype html>
<html lang="en-gb" dir="ltr" itemscope itemtype="http://schema.org/WebPage">
<!-- dpws app version: 1.87.0.20210806091629 -->
<!-- dpws-cs app version: 1.22.0.20211013123121 -->
<head>
	

	
        <title>404</title>
        <meta charset="utf-8"/>
        
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        
        <link rel="apple-touch-icon" sizes="180x180" href="/etc/designs/dpws/common/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/etc/designs/dpws/common/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/etc/designs/dpws/common/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/etc/designs/dpws/common/manifest.json" crossorigin="use-credentials">
        <link rel="mask-icon" href="/etc/designs/dpws/common/favicons/safari-pinned-tab.svg">
        <link rel="shortcut icon" href="/etc/designs/dpws/common/favicons/favicon.ico">
        <meta name="msapplication-config" content="/etc/designs/dpws/common/favicons/browserconfig.xml">
        <meta name="theme-color" content="#ffffff">
        
        <meta name="google-site-verification" content="yM1rZu0ehS2ahAmg0FVNJTJ7gXJt9_Fs8Fxe_VYJA8o"/>
        <meta name="facebook-domain-verification" content="b9dc4sljau0y6zgkltwjv5zggddk2s"/>
        <meta itemprop="title" content="404"/>
        <meta name="twitter:title" content="404"/>
        <meta property="og:title" content="404"/>
        <meta property="og:url" content="https://www.hsbc.co.uk/errors/404/"/>
        <meta property="og:type" content="website"/>
        <meta name="twitter:card" content="summary"/>
        <meta itemprop="image" content="/etc/designs/dpws/common/social/logo/Portrait-736x1128px.jpg"/>
        <meta name="twitter:image" content="/etc/designs/dpws/common/social/logo/Square-1200x1200px.jpg"/>
        <meta property="og:image" content="/etc/designs/dpws/common/social/logo/Square-1200x1200px.jpg"/>
        
        
        
        
<meta name="apple-itunes-app" content="app-id=1220329065, affiliate-data=pt=118152957&ct=M_SB_PWS_HPS_E"/>
<meta name="app-itunes" content="https://itunes.apple.com/app/apple-store/id1220329065?pt=118152957&amp;ct=M_SB_PWS_HPS_E&amp;mt=8 "/>
<meta name="app-google-play" content="https://play.google.com/store/apps/details?id=uk.co.hsbc.hsbcukmobilebanking"/>
<meta name="app-title" content="HSBC UK Mobile Banking app"/>
<meta name="app-desc" content="HSBC"/>
<meta name="app-view-label" content="Learn more"/>
<meta name="app-close-label" content="X"/>
<meta name="app-img" content="/etc/designs/dpws/common/img/mobile_banking.png"/>


	

    
<link rel="stylesheet" href="/etc/designs/dpws/clientlib-default.min.91f7ec1e1f900424d14d513cd9754029.css" type="text/css">









<script> window["adrum-app-key"] = "AD-AAB-AAF-XXU"; 
    window['adrum-start-time'] = new Date().getTime();
    </script>
    <script type="text/javascript" src="/etc/designs/hsbc/appd/clientlib.min.b3ec3a2325eaa4cbc74a2e2f0b755b0f.js"></script>

    



       <script src="https://tags.tiqcdn.com/utag/hsbc/uk-rbwm/prod/utag.sync.js"></script>
        
            

    <script>
    var utag_data={"page_url":"/errors/404/","page_name":"pws:errors : 404","page_language":"en_gb","page_security_level":"0","page_category":"errors","page_subcategory":"404"};
    
        utag_data["page_name"] = window.location.href;
        utag_data["pageType"] = "errorPage";
        utag_data["page_referrer"] = document.referrer;
    
</script>
    <!--[if lte IE 7]>
    <script type="text/javascript">utag_data["browser"]="IE7";</script>
    <![endif]-->
    <!--[if IE 8]>
    <script type="text/javascript">utag_data["browser"]="IE8";</script>
    <![endif]-->



        
        <script type="text/javascript">
            (function(a,b,c,d){
            	a='//tags.tiqcdn.com/utag/hsbc/uk-rbwm/prod/utag.js';
                b=document;c='script';d=b.createElement(c);d.src=a;
                d.type='text/java'+c;d.async=true;
                a=b.getElementsByTagName(c)[0];a.parentNode.insertBefore(d,a)
            })();
        </script>
        









</head>
<body class="page error400Page" data-global-settings="{&#34;cookieDomain&#34;:&#34;.hsbc.co.uk&#34;,&#34;newWindowLinkText&#34;:&#34;This link will open in a new window&#34;,&#34;totalSuggestions&#34;:&#34; &#34;}" data-language-settings="{&#34;texts&#34;:{&#34;loading&#34;:&#34;Loading...&#34;,&#34;errorMessageTitle&#34;:&#34;Oops, something went wrong?&#34;,&#34;errorMessageDetails&#34;:&#34;We are not able to load some page elements. Please refresh the page or come back later.&#34;}}">
<span data-page-path="/content/hsbc/gb/en_gb/errors/404" class="hidden"></span>
<div class="header-wrapper">
	
<span class="hidden generic-modal-setup">
    <script>
        window.modalsConfiguration = {"globalWhitelist":["https://play.google.com/store/apps/details?id\u003duk.co.hsbc.hsbcukmobilebanking","https://itunes.apple.com/app/apple-store/id1220329065?pt\u003d118152957\u0026ct\u003dM_SB_PWS_HPS_E\u0026mt\u003d8 "],"modals":{"/content/hsbc/gb/en_gb/configuration/modals/leaving-hsbc-for-adobe-live-sign-forms":{"modalUrl":"/configuration/modals/leaving-hsbc-for-adobe-live-sign-forms.modal/","whitelist":[],"blacklist":["https://ccouk.eu1.echosign.com/public/esignWidget","https://hsbccovid.consents.online","https://ccouk.eu1.adobesign.com/public/esignWidget","https://hsbccoll.consents.online/"],"triggerOn":"click","showOnce":false,"logoutOnAction":false,"authorizedOnly":false,"anonymousOnly":false,"enabled":true},"/content/hsbc/gb/en_gb/configuration/modals/you-are-leaving-hsbc":{"modalUrl":"/configuration/modals/you-are-leaving-hsbc.modal/","whitelist":["*hsbc.com*","*hsbc.co.uk*","*about.hsbc.co.uk*","*business.hsbc.co.uk*","*business.hsbc.uk*","*financialplanning.hsbc.co.uk*","*hsss.hsbc.co.uk*","*investments.hsbc.co.uk*","*mortgagedocuments.hsbc.co.uk*","*mortgages.hsbc.co.uk*","*personalisedloanquote.hsbc.co.uk*","*security.hsbc.co.uk*","*services.online-banking.hsbc.co.uk*","*stpapplications.hsbc.co.uk*","*dco-ao.hsbc.co.uk*","*hsss2.hsbc.co.uk*","*m.hsbc.co.uk*","*makeaclaim.hsbc.co.uk*","*www.fscs.org.uk*","*https://www.eu430.p2g.netd2.hsbc.com.hk*","*https://itunes.apple.com/app/apple-store/id1220329065?pt\u003d118152957\u0026ct\u003ddigitaldisplay\u0026mt\u003d8*","*https://itunes.apple.com/app/apple-store/id1220329065?pt\u003d118152957\u0026ct\u003dsocial\u0026mt\u003d8*","*https://itunes.apple.com/app/apple-store/id1220329065?pt\u003d118152957\u0026ct\u003dppc\u0026mt\u003d8*","*https://itunes.apple.com/app/apple-store/id1183884067?pt\u003d118152957\u0026ct\u003dddholidays\u0026mt\u003d8*","*https://itunes.apple.com/app/apple-store/id1183884067?pt\u003d118152957\u0026ct\u003dddtreats\u0026mt\u003d8*","*https://itunes.apple.com/app/apple-store/id1183884067?pt\u003d118152957\u0026ct\u003dddhomemade\u0026mt\u003d8*","*https://itunes.apple.com/app/apple-store/id1183884067?pt\u003d118152957\u0026ct\u003dddpiggy\u0026mt\u003d8*","*https://itunes.apple.com/app/apple-store/id1183884067?pt\u003d118152957\u0026ct\u003dddcards\u0026mt\u003d8*","*aem-wk.lp.hsbc.co.uk *","*https://www.hsbc.co.uk/1/2//linklaunch/overdraft-calculator","*https://hsbccovid.consents.online*","*home.uk.hsbc*","*ccouk.eu1.adobesign.com/public/esignWidget*","*ccouk.eu1.echosign.com/public/esignWidget*","https://forms.hsbc.gb/forms/international-account-opening","https://hsbccoll.consents.online/","https://uk.chili.com/promotion"],"blacklist":["http"],"triggerOn":"click","showOnce":false,"logoutOnAction":false,"authorizedOnly":false,"anonymousOnly":false,"enabled":true}}};
    </script>
</span>
	
<div>
    <header class="header grid" role="banner">
        
            <div id="messaging-banner" class="messaging-banner pub">
    
    

    
    

    
    

</div>


            

            
        
        <!-- Old IE7-9 Browser Notification banner-->
<!--[if lte IE 9]><div class="browser-notification"><![endif]-->
<!--[if !IE]> -->
<div class="browser-notification hidden">
<!-- <![endif]-->
    <div class="browser-notification-wrapper">
        <div class="browser-notification-icons left-icon">
            <span class="icon-exclamation"></span>
        </div>
        <div class="browser-notification-text"><p><a href="https://www.microsoft.com/en-gb/download/internet-explorer.aspx" target="_blank" rel="noopener">Our website doesn't support your browser so please upgrade</a>.<br />
</p>


</div>
        <div class="browser-notification-icons right-icon">
            <button class="close-browser-notification">
                <span class="icon icon-close" aria-hidden="true"></span>
                <span class="visuallyhidden"></span>
            </button>
        </div>
    </div>
</div>
        
    <script id="cpiLogoffScript" data-retail-logoff-url="/bin/logout./content/hsbc/gb/en_gb/cpi/log-off-retail" data-advance-logoff-url="/bin/logout./content/hsbc/gb/en_gb/cpi/log-off-advance" data-premier-logoff-url="/bin/logout./content/hsbc/gb/en_gb/cpi/log-off-premier">
    </script>


        <div class="header-wrapper-main">
            <div class="header-nav-wrapper">
                
<div class="header-top-container hide-on-mobile-and-tablet">
    <div class="header-top">
        <div class="row">
            <div class="lg-12">
                <nav aria-label="product line">
                    <ul class="header-top-navigation">
                        <li>
                            <a class="skip-to-content-link" href="#top-of-content">
                                <span class="skip-to-content-link-text">Skip page header and navigation</span>
                            </a>
                        </li>
                        
                            
                            <li class="header-top-navigation-item is-active">
                                <a href="https://www.hsbc.co.uk/" aria-label="Personal currently selected" aria-selected="true">
                                        Personal
                                </a>
                            </li>
                        
                            
                            <li class="header-top-navigation-item ">
                                <a href="http://www.business.hsbc.uk/" aria-selected="false">
                                        Business
                                </a>
                            </li>
                        
                    </ul>
                </nav>
                <div class="header-top-meta">
                    <div class="dropdown-container">
                        <nav aria-label="language">
                            <ul>
                                
                                
                                <li class="header-dropdown header-generic-dropdown">
                                    <span>
                                        <span class="visuallyhidden">Language</span>
                                        English
                                    </span>
                                    
                                    
                                </li>
                                
                                <li class="header-dropdown header-user-wrapper register-button">
                                    
    
    
    
    
    <div class="link-container">
        <a class="A-LNKB-RW-ALL" href="https://www.hsbc.co.uk/register/" data-event-component="topnav" data-event-name="Register">
            
            
    <span class="link">Register</span>&nbsp;<span class="icon icon-chevron-right-small" aria-hidden="true"></span>
    

            
        </a>
    </div>


                                </li>
                                <li class="header-dropdown header-user-wrapper my-accounts-button hidden">
                                    
    
    
    
    
    <div class="link-container">
        <a class="A-LNKB-RW-ALL" href="https://www.hsbc.co.uk/online/dashboard/">
            
            
    <span class="link">Back to my accounts</span>&nbsp;<span class="icon icon-chevron-right-small" aria-hidden="true"></span>
    

            
        </a>
    </div>


                                </li>
                                <li class="header-user-wrapper">
                                    <div class="header-dropdown primary-button" aria-label="Log on options">
                                        
                                        <a class="selected-item login-button only-one-link" href="https://www.hsbc.co.uk/online/dashboard/" tabindex="0" role="button" data-event-component="topnav" data-event-name="Log on">
                                            Log on
                                        </a>
                                        <a class="cpi-masthead-logoff__button-dpws logout-button hidden" href="#cpi" tabindex="0" role="button" data-event-component="topnav" data-event-name="Log off">
                                            Log off
                                        </a>
                                        
                                    </div>
                                </li>
                            </ul>
                        </nav>
                        <div class="page-overlay hidden"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="header-main-container hide-on-mobile-and-tablet">
    <div class="header-main">
        <div class="row wrapper">
            <div class="header-logo lg-2">
                
                <a href="https://www.hsbc.co.uk/">
                    <img src="/content/dam/hsbc/gb/images/logos/hsbc-uk.svg" alt="HSBC UK home page">
                </a>
            </div>
            <nav class="header-main-navigation lg-10" aria-label="main navigation">
                
                <ul class="row">
                    <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-0" class="header-mobile-doormat-0 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-banking hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Banking</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Accounts &amp; services</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-0">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/current-accounts/" data-event-component="topnav" data-event-name="Banking: Current accounts" class="doormat-heading-link">
        <h2 class="doormat-heading">Current accounts</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/premier/day-to-day-banking/bank-account/" aria-label="Premier Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Premier Account">
                    Premier Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/advance/" aria-label="Advance Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Advance Account">
                    Advance Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/bank-account/" aria-label="Bank Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Bank Account">
                    Bank Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/student/" aria-label="Student Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Student Account">
                    Student Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/international-student/" aria-label="International Student Account" data-event-component="topnav" data-event-name="Banking: Current accounts: International student account">
                    International Student Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/children/" aria-label="Children&#39;s Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Childrens Account">
                    Children&#39;s Account
                </a>
            </li>
        
            <li>
                <a href="https://www.business.hsbc.uk/en-gb/everyday-banking/business-accounts/" aria-label="Business accounts" data-event-component="topnav" data-event-name="Banking: Current accounts: Business accounts">
                    Business accounts
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/" aria-label="See all current accounts" data-event-component="topnav" data-event-name="Banking: Current accounts: See all current accounts">
                    See all current accounts
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/savings/" data-event-component="topnav" data-event-name="Banking: Savings accounts" class="doormat-heading-link">
        <h2 class="doormat-heading">Savings accounts</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/online-bonus-saver/" aria-label="Online Bonus Saver" data-event-component="topnav" data-event-name="Banking: Savings: Online Bonus Saver">
                    Online Bonus Saver
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/regular-saver/" aria-label="Regular Savings Account" data-event-component="topnav" data-event-name="Banking: Savings: Regular Savings Account">
                    Regular Savings Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/easy-access-accounts/" aria-label="Easy access savings accounts" data-event-component="topnav" data-event-name="Banking: Savings: easy access savings accounts">
                    Easy access savings accounts
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/fixed-rate/" aria-label="Fixed Rate Savings Account" data-event-component="topnav" data-event-name="Banking: Savings: Fixed Rate Savings Account">
                    Fixed Rate Savings Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/mysavings/" aria-label="Children?s Savings Account" data-event-component="topnav" data-event-name="Banking: Savings: Children?s Savings Account">
                    Children?s Savings Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/isas/" aria-label="ISAs" data-event-component="topnav" data-event-name="Banking: Savings: ISAs">
                    ISAs
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/" aria-label="See all savings accounts" data-event-component="topnav" data-event-name="Banking: Savings: See all savings accounts">
                    See all savings accounts
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/international/" data-event-component="topnav" data-event-name="Banking: International services" class="doormat-heading-link">
        <h2 class="doormat-heading">International services</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/international/using-your-card-abroad/" aria-label="Using your card outside the UK" data-event-component="topnav" data-event-name="Banking: International Services: Using your card outside the UK">
                    Using your card outside the UK
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/travel-money/" aria-label="Travel Money" data-event-component="topnav" data-event-name="Banking: International Services: Travel Money">
                    Travel Money
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/money-transfer/" aria-label="International payments" data-event-component="topnav" data-event-name="Banking: International Services: International payments">
                    International payments
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/currency-account/" aria-label="Currency Account" data-event-component="topnav" data-event-name="Banking: International Services: Currency Account">
                    Currency Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/overseas-account-opening/" aria-label="International Bank Account" data-event-component="topnav" data-event-name="Banking: International Services: International Bank Account">
                    International Bank Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/" aria-label="See all international services" data-event-component="topnav" data-event-name="Banking: International Services: See all international services">
                    See all international services
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already banking with us?</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/existing-customers/" aria-label="Existing customers" data-event-component="topnav" data-event-name="Banking: Already banking with us: Existing customers">
                    Existing customers
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/" aria-label="Manage your account" data-event-component="topnav" data-event-name="Banking: Already banking with us: Manage your account">
                    Manage your account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/mobile/" aria-label="Mobile banking " data-event-component="topnav" data-event-name="Banking: Already banking with us: Mobile banking ">
                    Mobile banking 
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/online-banking/" aria-label="Online banking" data-event-component="topnav" data-event-name="Banking: Already banking with us: Online banking">
                    Online banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/overdrafts/" aria-label="Overdrafts" data-event-component="topnav" data-event-name="Banking: Already banking with us: Overdrafts  ">
                    Overdrafts
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/overdraft-calculator/" aria-label="Overdraft calculator" data-event-component="topnav" data-event-name="Banking: Already banking with us: Overdraft calculator">
                    Overdraft calculator
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                
                    <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-1" class="header-mobile-doormat-1 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-borrowing hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Borrowing</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Short &amp; long-term</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-1">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/credit-cards/" data-event-component="topnav" data-event-name="Borrowing: Credit cards" class="doormat-heading-link">
        <h2 class="doormat-heading">Credit cards</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/balance-transfer-credit-cards/" aria-label="Balance transfer credit cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Balance transfer cards">
                    Balance transfer credit cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/purchase-credit-cards/" aria-label="Purchase cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Purchase cards">
                    Purchase cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/rewards-credit-cards/" aria-label="Rewards cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: rewards cards">
                    Rewards cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/credit-builder-credit-cards/" aria-label="Credit building cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Credit building cards">
                    Credit building cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/premier-credit-cards/" aria-label="Premier cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Premier cards">
                    Premier cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/ways-to-borrow/" aria-label="Ways to borrow">
                    Ways to borrow
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/eligibility-checker/" aria-label="Credit card eligibility checker" data-event-component="topnav" data-event-name="Borrowing: Credit cards: credit card eligibility checker">
                    Credit card eligibility checker
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/products/" aria-label="See all credit cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: See all credit cards">
                    See all credit cards
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/loans/" data-event-component="topnav" data-event-name="Borrowing: Loans" class="doormat-heading-link">
        <h2 class="doormat-heading">Loans</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/personal/" aria-label="Personal Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Personal Loan">
                    Personal Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/premier/" aria-label="Premier Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Premier Loan">
                    Premier Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/car-loan/" aria-label="Car Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Car Loan">
                    Car Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/home-improvements/" aria-label="Home Improvement Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Home Improvement Loan">
                    Home Improvement Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/top-up-loans/" aria-label="Top up your loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Top up your loan">
                    Top up your loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/ways-to-borrow/" aria-label="Ways to borrow">
                    Ways to borrow
                </a>
            </li>
        
            <li>
                <a href="/loans/products/debt-consolidation/" aria-label="Debt Consolidation Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Debt Consolidation Loan">
                    Debt Consolidation Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/" aria-label="See all loans" data-event-component="topnav" data-event-name="Borrowing: Loans: See all loans">
                    See all loans
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/mortgages/" data-event-component="topnav" data-event-name="Borrowing: Mortgages" class="doormat-heading-link">
        <h2 class="doormat-heading">Mortgages</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/existing-customers/switch/" aria-label="Switch your mortgage rate">
                    Switch your mortgage rate
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/move-your-mortgage/" aria-label="Remortgage to HSBC" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Remortgage to HSBC">
                    Remortgage to HSBC
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/first-time-buyers/" aria-label="First-time buyers" data-event-component="topnav" data-event-name="Borrowing: Mortgages: First-time Buyers">
                    First-time buyers
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/how-to-apply/" aria-label="Get a decision in principle" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Get a decision in principle">
                    Get a decision in principle
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/our-rates/" aria-label="Mortgage rates" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Mortgage rates">
                    Mortgage rates
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/calculators/" aria-label="Mortgage calculators" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Calculators">
                    Mortgage calculators
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/application-in-progress/" aria-label="Continue my application">
                    Continue my application
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/95-percent/" aria-label="95% mortgages" data-event-component="topnav" data-event-name="Borrowing: Mortgages: 95% mortgages">
                    95% mortgages
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already borrowing with us?</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/existing-customers/" aria-label="Manage your existing mortgage" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Manage your existing mortgage">
                    Manage your existing mortgage
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/mortgage-payments/" aria-label="Mortgage payment support" data-event-component="topnav" data-event-name="Borrowing: Mortgage payment support">
                    Mortgage payment support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/existing-customers/switch/" aria-label="Switch your HSBC mortgage" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Switch your HSBC mortgage">
                    Switch your HSBC mortgage
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/existing-customers/" aria-label="Manage your credit card" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Manage your credit card">
                    Manage your credit card
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/fees/" aria-label="Credit card fees and rates" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Credit card fees and rates">
                    Credit card fees and rates
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/bank-of-england-base-rate/" aria-label="Base rate information" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Base rate information">
                    Base rate information
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/credit-card-repayment-calculator/" aria-label="Credit card repayment calculator" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Credit card repayment calculator">
                    Credit card repayment calculator
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                
                    <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-2" class="header-mobile-doormat-2 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-investment hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Investing</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Products &amp; planning</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-2">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/investments/" data-event-component="topnav" data-event-name="Investing: Ways to invest" class="doormat-heading-link">
        <h2 class="doormat-heading">Investing</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/new-to-investing/" aria-label="New to investing?" data-event-component="topnav" data-event-name="investing: way to invest: new to investing">
                    New to investing?
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/isas/" aria-label="Stocks &amp; shares ISA" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in an ISA">
                    Stocks &amp; shares ISA
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/funds/" aria-label="Invest in funds" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in funds">
                    Invest in funds
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/sustainable-portfolios" aria-label="Invest in sustainable funds" data-event-component="topnav" data-event-name="investing: way to invest: invest in sustainable funds">
                    Invest in sustainable funds
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/invest-direct" aria-label="Invest in shares" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in shares">
                    Invest in shares
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/" aria-label="See all investments" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in investments products">
                    See all investments
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/investments/advice/" data-event-component="topnav" data-event-name="Investing: Your advice options" class="doormat-heading-link">
        <h2 class="doormat-heading">Advice options</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/advice/my-investment/" aria-label="Online investment advice " data-event-component="topnav" data-event-name="Investing: Your advice options: Online investment advice">
                    Online investment advice 
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/advice/financial-advice" aria-label="Financial advice" data-event-component="topnav" data-event-name="Investing: Your advice options: Financial advice">
                    Financial advice
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/protection-advice/" aria-label="Protection advice" data-event-component="topnav" data-event-name="Investing: Your advice options: Protection advice">
                    Protection advice
                </a>
            </li>
        
    </ul>
</div>

        
    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/retirement/" class="doormat-heading-link">
        <h2 class="doormat-heading">Visualise your retirement</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://retirementcalculator.hsbc.co.uk/" aria-label="Retirement calculator" data-event-component="topnav" data-event-name="Investing: Visualise your retirement: Retirement calculator">
                    Retirement calculator
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/retirement/investing-for-retirement/" aria-label="Investing for retirement" data-event-component="topnav" data-event-name="Investing: Visualise your retirement: Investing for retirement">
                    Investing for retirement
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/wealth/planning/" data-event-component="topnav" data-event-name="Investing: Improve your knowledge " class="doormat-heading-link">
        <h2 class="doormat-heading">Improve your knowledge </h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/financial-action-plan" aria-label="Your financial action plan" data-event-component="topnav" data-event-name="Investing: Invest in yourself: Your financial action plan">
                    Your financial action plan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/articles/what-is-sustainable-investing/" aria-label="What is sustainable investing?" data-event-component="topnav" data-event-name="investing: improve your knowledge: what is sustainable investing">
                    What is sustainable investing?
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/investment-calculator/" aria-label="Investment calculator" data-event-component="topnav" data-event-name="Investing: Invest in yourself: Investment calculator">
                    Investment calculator
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/education-calculator/" aria-label="Children?s education calculator" data-event-component="topnav" data-event-name="investing: improve your knowledge: children&#39;s education calculator">
                    Children?s education calculator
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/insights/" aria-label="Wealth Insights" data-event-component="topnav" data-event-name="Investing: Invest in yourself: HSBC Wealth insights">
                    Wealth Insights
                </a>
            </li>
        
    </ul>
</div>

        
    
        
        
            
            
            
            
            <div class="links-group">
    
    <ul class="doormat-links">
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already investing with us?</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/existing-customers/" aria-label="Existing customers" data-event-component="topnav" data-event-name="Investing: Already investing with us?: Existing customers">
                    Existing customers
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/existing-customers/global-investment-centre/" aria-label="How to buy and sell funds" data-event-component="topnav" data-event-name="Investing: Already investing with us?: How to buy and sell funds">
                    How to buy and sell funds
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/existing-customers/invest-direct/" aria-label="How to buy and sell shares" data-event-component="topnav" data-event-name="Investing: Already investing with us?: How to buy and sell shares">
                    How to buy and sell shares
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/onshore-investment-bond/" aria-label="Onshore Investment Bond" data-event-component="topnav" data-event-name="Investing: Already investing with us?: Onshore Investment Bond">
                    Onshore Investment Bond
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/child-trust-fund/" aria-label="Child Trust Fund" data-event-component="topnav" data-event-name="Investing:Already investing with us?: Child Trust Fund">
                    Child Trust Fund
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                
                    <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-3" class="header-mobile-doormat-3 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-insurance hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Insurance</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Property &amp; family</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-3">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/insurance/" data-event-component="topnav" data-event-name="Insurance: Insurance" class="doormat-heading-link">
        <h2 class="doormat-heading">Insurance</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/select-and-cover/" aria-label="Select and Cover" data-event-component="topnav" data-event-name="Insurance: Insurance: Select and cover">
                    Select and Cover
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/home/" aria-label="Home Insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: Home Insurance">
                    Home Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/contents/" aria-label="Contents Insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: Contents Insurance">
                    Contents Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/travel/" aria-label="Travel Insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: Travel Insurance">
                    Travel Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.business.hsbc.uk/en-gb/protection/insurance/" aria-label="Small Business Insurance" data-event-component="topnav" data-event-name="Banking: Insurance: Small Business Insurance">
                    Small Business Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/" aria-label="See all insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: See all insurance">
                    See all insurance
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Claims</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/select-and-cover/claims/" aria-label="Select and Cover claims" data-event-component="topnav" data-event-name="Insurance: Travel: Select and Cover claims">
                    Select and Cover claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/home/claims/" aria-label="Home Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Home Insurance claims">
                    Home Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/life/claims/" aria-label="Life Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Life Insurance claims">
                    Life Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/travel/claims/" aria-label="Travel Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Travel Insurance claims">
                    Travel Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/aspects/claims/" aria-label="Aspects Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Aspects Insurance claims">
                    Aspects Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/premier-travel/" aria-label="Premier Travel Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Premier Travel Insurance claims">
                    Premier Travel Insurance claims
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/insurance/life/" data-event-component="topnav" data-event-name="Insurance: Life:" class="doormat-heading-link">
        <h2 class="doormat-heading">Life</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/life-cover/" aria-label="Life Cover" data-event-component="topnav" data-event-name="Insurance: Life: Life Cover">
                    Life Cover
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/critical-illness-cover/" aria-label="Critical Illness Cover" data-event-component="topnav" data-event-name="Insurance: Life: Critical Illness Cover">
                    Critical Illness Cover
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/income-protection/" aria-label="Income Protection Insurance" data-event-component="topnav" data-event-name="Insurance: Life: Income Protection Insurance">
                    Income Protection Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/protection-advice/" aria-label="Protection advice" data-event-component="topnav" data-event-name="Insurance: Life: Protection advice">
                    Protection advice
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/life/" aria-label="See all life insurance" data-event-component="topnav" data-event-name="Insurance: Life: See all life insurance products">
                    See all life insurance
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already insured by us? </h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/select-and-cover/existing-customers/" aria-label="Select and Cover support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?: Select and Cover support">
                    Select and Cover support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/home/claims/" aria-label="Home Insurance support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?:  Home Insurance support">
                    Home Insurance support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/life/claims/" aria-label="Life Insurance support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?:  Life Insurance support">
                    Life Insurance support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/premier-travel/" aria-label="Premier Travel support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?:  Premier Travel support">
                    Premier Travel support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/aspects/" aria-label="Aspects Insurance support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?: Aspects Insurance support">
                    Aspects Insurance support
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                
                    <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-4" class="header-mobile-doormat-4 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-health hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Wellbeing</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Financial health &amp; support</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-4">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/financial-fitness/" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness" class="doormat-heading-link">
        <h2 class="doormat-heading">Financial fitness</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/fitness-score/" aria-label="Financial fitness score tool" data-event-component="topnav" data-event-name="Financial fitness score tool">
                    Financial fitness score tool
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/everyday-budgeting/" aria-label="Everyday budgeting" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness Everyday budgeting">
                    Everyday budgeting
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/managing-debt/" aria-label="Managing debt" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Managing debt">
                    Managing debt
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/growing-your-money/" aria-label="Growing your money" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Growing your money">
                    Growing your money
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/" aria-label="Staying safe and secure" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Staying safe and secure">
                    Staying safe and secure
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-education/" aria-label="Learning about money" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Learning about money">
                    Learning about money
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/new-beginnings/" data-event-component="topnav" data-event-name="Wellbeing: New Beginnings" class="doormat-heading-link">
        <h2 class="doormat-heading">New beginnings</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/new-beginnings/expanding-your-family/" aria-label="Expanding your family" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Expanding your family">
                    Expanding your family
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/new-beginnings/getting-married/" aria-label="Getting married" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Getting married">
                    Getting married
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/retirement/" aria-label="Planning for retirement" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Planning for retirement">
                    Planning for retirement
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/first-time-buyers/" aria-label="Buying your first home" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Buying your first home">
                    Buying your first home
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/moving-abroad/" aria-label="Moving abroad" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Moving abroad">
                    Moving abroad
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/students/" aria-label="Going to uni" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Going to uni">
                    Going to uni
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/life-events/" data-event-component="topnav" data-event-name="Wellbeing: Life events" class="doormat-heading-link">
        <h2 class="doormat-heading">Life events</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/bereavement/" aria-label="Bereavement support" data-event-component="topnav" data-event-name="Wellbeing: Life events: Bereavement support">
                    Bereavement support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/assisting-someone-with-their-money/" aria-label="Assisting someone with their money" data-event-component="topnav" data-event-name="Wellbeing: Life events: Assisting someone with their money">
                    Assisting someone with their money
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/separation/" aria-label="Separation" data-event-component="topnav" data-event-name="Wellbeing: Life events: Separation ">
                    Separation
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/unexpected-change/redundancy/" aria-label="Losing your job" data-event-component="topnav" data-event-name="Wellbeing: Life events: Losing your job">
                    Losing your job
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/poa/" aria-label="Power of Attorney" data-event-component="topnav" data-event-name="Wellbeing: Life events: Power of attorney">
                    Power of Attorney
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/accessibility/mental-health-and-support/" aria-label="Mental health and support" data-event-component="topnav" data-event-name="Wellbeing: Life events: Mental health and support">
                    Mental health and support
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/money-worries/" data-event-component="topnav" data-event-name="Wellbeing: Money worries" class="doormat-heading-link">
        <h2 class="doormat-heading">Money worries</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/how-we-can-help/" aria-label="How we can help" data-event-component="topnav" data-event-name="Wellbeing: Money worries: How we can help">
                    How we can help
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/mortgage-payments/" aria-label="Mortgage payment support" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Mortgage payment support">
                    Mortgage payment support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/financial-abuse/" aria-label="Financial and domestic abuse" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Financial and domestic abuse">
                    Financial and domestic abuse
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/managing-your-finances/" aria-label="Managing your finances" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Managing your finances">
                    Managing your finances
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/coronavirus/" aria-label="Coronavirus support" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Coronavirus support">
                    Coronavirus support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/card-support/gambling-restrictions/" aria-label="Support for gambling" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Support for gambling">
                    Support for gambling
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                
                    <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-5" class="header-mobile-doormat-5 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-help hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Help</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Service &amp; security</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-5">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/banking-made-easy/" data-event-component="topnav" data-event-name="Help: Managing your account" class="doormat-heading-link">
        <h2 class="doormat-heading">Managing your account</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/" aria-label="Ways to bank" data-event-component="topnav" data-event-name="Help: Managing your account: Ways to bank">
                    Ways to bank
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/card-support/" aria-label="Card support" data-event-component="topnav" data-event-name="Help: Managing your account: Card support">
                    Card support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/how-to-set-up-a-direct-debit/" aria-label="Set up or cancel a Direct Debit" data-event-component="topnav" data-event-name="Help: Managing your account: Set up or cancel a direct debit">
                    Set up or cancel a Direct Debit
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/how-to-set-up-standing-order/" aria-label="Set up or cancel a standing order" data-event-component="topnav" data-event-name="Help: Managing your account: Set up or cancel a standing order">
                    Set up or cancel a standing order
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/card-support/dispute-transaction/" aria-label="Query a transaction" data-event-component="topnav" data-event-name="Help: Managing your account: Query a transaction">
                    Query a transaction
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/security-centre/" data-event-component="topnav" data-event-name="Help: Fraud and security" class="doormat-heading-link">
        <h2 class="doormat-heading">Fraud and security</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/fraud-guide/" aria-label="Fraud guide" data-event-component="topnav" data-event-name="Help: Fraud and security: Fraud guide">
                    Fraud guide
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/received-a-text/" aria-label="Received a text?" data-event-component="topnav" data-event-name="Help: Fraud and security: Received a text">
                    Received a text?
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/hsbc-safeguard/" aria-label="HSBC Safeguard" data-event-component="topnav" data-event-name="Help: Fraud and security: HSBC Safeguard">
                    HSBC Safeguard
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/secure-key/" aria-label="Secure Key" data-event-component="topnav" data-event-name="Help: Fraud and security: Secure Key">
                    Secure Key
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/digital-security-promise/" aria-label="Our Digital Security Promise" data-event-component="topnav" data-event-name="Help: Fraud and security: Our Digital Security Promise">
                    Our Digital Security Promise
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/banking-made-easy/" data-event-component="topnav" data-event-name="Help: Digital banking" class="doormat-heading-link">
        <h2 class="doormat-heading">Digital banking</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/register/" aria-label="Register for digital banking" data-event-component="topnav" data-event-name="Help: Digital banking: Register for digital banking">
                    Register for digital banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/mobile/" aria-label="Mobile banking" data-event-component="topnav" data-event-name="Help: Digital banking: Mobile banking">
                    Mobile banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/online-banking/" aria-label="Online banking" data-event-component="topnav" data-event-name="Help: Digital banking: Online banking">
                    Online banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/banking-at-home/" aria-label="Banking at home" data-event-component="topnav" data-event-name="Help: Digital banking: Banking at home">
                    Banking at home
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/mobile/cheque-deposit/" aria-label="Mobile cheque deposit" data-event-component="topnav" data-event-name="Help: Digital banking: Mobile cheque deposit">
                    Mobile cheque deposit
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/lost-your-details/" aria-label="Reset your online banking details" data-event-component="topnav" data-event-name="Help: Digital banking: Reset your online banking details">
                    Reset your online banking details
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/" data-event-component="topnav" data-event-name="Help: Help" class="doormat-heading-link">
        <h2 class="doormat-heading">Help</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/" aria-label="Customer support" data-event-component="topnav" data-event-name="Help: Help: Customer support">
                    Customer support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/feedback-and-complaints/" aria-label="Feedback and complaints" data-event-component="topnav" data-event-name="Help: Help: Feedback and complaints">
                    Feedback and complaints
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/coronavirus/" aria-label="Coronavirus support" data-event-component="topnav" data-event-name="Help: Help: Coronavirus support">
                    Coronavirus support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/bank-of-england-base-rate/" aria-label="Bank of England base rate" data-event-component="topnav" data-event-name="Help: Help: Bank of England base rate">
                    Bank of England base rate
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/making-payments/" aria-label="Making payments" data-event-component="topnav" data-event-name="Help: Help: Making payments">
                    Making payments
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/accessibility/" aria-label="Accessibility and disability" data-event-component="topnav" data-event-name="Help: Help: Accessibility and disability">
                    Accessibility and disability
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

                
<div class="header-mobile">
    <div class="header-mobile-top hide-on-desktop">
        <button class="header-sidebar-trigger" aria-label="Open menu" data-aria-label-open-menu="Open menu" data-aria-label-close-menu="Close menu">
            <span class="icon icon-menu" aria-hidden="true"></span>
            <span class="header-sidebar-trigger-text">Menu</span>
        </button>
        <nav id="sidebar" class="header-mobile-sidebar hide-on-desktop">
            <div class="header-mobile-sidebar-content">
                
                <div class="close-submenu-trigger" role="button" tabindex="0" aria-label="Close Submenu">
                    <span class="icon icon-chevron-left" aria-hidden="true"></span>
                </div>
                <ul class="header-mobile-doormat" role="menubar">
                    
                        <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-0" class="header-mobile-doormat-0 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-banking hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Banking</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Accounts &amp; services</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-0">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/current-accounts/" data-event-component="topnav" data-event-name="Banking: Current accounts" class="doormat-heading-link">
        <h2 class="doormat-heading">Current accounts</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/premier/day-to-day-banking/bank-account/" aria-label="Premier Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Premier Account">
                    Premier Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/advance/" aria-label="Advance Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Advance Account">
                    Advance Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/bank-account/" aria-label="Bank Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Bank Account">
                    Bank Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/student/" aria-label="Student Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Student Account">
                    Student Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/international-student/" aria-label="International Student Account" data-event-component="topnav" data-event-name="Banking: Current accounts: International student account">
                    International Student Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/children/" aria-label="Children&#39;s Account" data-event-component="topnav" data-event-name="Banking: Current accounts: Childrens Account">
                    Children&#39;s Account
                </a>
            </li>
        
            <li>
                <a href="https://www.business.hsbc.uk/en-gb/everyday-banking/business-accounts/" aria-label="Business accounts" data-event-component="topnav" data-event-name="Banking: Current accounts: Business accounts">
                    Business accounts
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/" aria-label="See all current accounts" data-event-component="topnav" data-event-name="Banking: Current accounts: See all current accounts">
                    See all current accounts
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/savings/" data-event-component="topnav" data-event-name="Banking: Savings accounts" class="doormat-heading-link">
        <h2 class="doormat-heading">Savings accounts</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/online-bonus-saver/" aria-label="Online Bonus Saver" data-event-component="topnav" data-event-name="Banking: Savings: Online Bonus Saver">
                    Online Bonus Saver
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/regular-saver/" aria-label="Regular Savings Account" data-event-component="topnav" data-event-name="Banking: Savings: Regular Savings Account">
                    Regular Savings Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/easy-access-accounts/" aria-label="Easy access savings accounts" data-event-component="topnav" data-event-name="Banking: Savings: easy access savings accounts">
                    Easy access savings accounts
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/fixed-rate/" aria-label="Fixed Rate Savings Account" data-event-component="topnav" data-event-name="Banking: Savings: Fixed Rate Savings Account">
                    Fixed Rate Savings Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/mysavings/" aria-label="Children?s Savings Account" data-event-component="topnav" data-event-name="Banking: Savings: Children?s Savings Account">
                    Children?s Savings Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/isas/" aria-label="ISAs" data-event-component="topnav" data-event-name="Banking: Savings: ISAs">
                    ISAs
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/savings/products/" aria-label="See all savings accounts" data-event-component="topnav" data-event-name="Banking: Savings: See all savings accounts">
                    See all savings accounts
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/international/" data-event-component="topnav" data-event-name="Banking: International services" class="doormat-heading-link">
        <h2 class="doormat-heading">International services</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/international/using-your-card-abroad/" aria-label="Using your card outside the UK" data-event-component="topnav" data-event-name="Banking: International Services: Using your card outside the UK">
                    Using your card outside the UK
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/travel-money/" aria-label="Travel Money" data-event-component="topnav" data-event-name="Banking: International Services: Travel Money">
                    Travel Money
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/money-transfer/" aria-label="International payments" data-event-component="topnav" data-event-name="Banking: International Services: International payments">
                    International payments
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/currency-account/" aria-label="Currency Account" data-event-component="topnav" data-event-name="Banking: International Services: Currency Account">
                    Currency Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/overseas-account-opening/" aria-label="International Bank Account" data-event-component="topnav" data-event-name="Banking: International Services: International Bank Account">
                    International Bank Account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/" aria-label="See all international services" data-event-component="topnav" data-event-name="Banking: International Services: See all international services">
                    See all international services
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already banking with us?</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/existing-customers/" aria-label="Existing customers" data-event-component="topnav" data-event-name="Banking: Already banking with us: Existing customers">
                    Existing customers
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/" aria-label="Manage your account" data-event-component="topnav" data-event-name="Banking: Already banking with us: Manage your account">
                    Manage your account
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/mobile/" aria-label="Mobile banking " data-event-component="topnav" data-event-name="Banking: Already banking with us: Mobile banking ">
                    Mobile banking 
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/online-banking/" aria-label="Online banking" data-event-component="topnav" data-event-name="Banking: Already banking with us: Online banking">
                    Online banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/overdrafts/" aria-label="Overdrafts" data-event-component="topnav" data-event-name="Banking: Already banking with us: Overdrafts  ">
                    Overdrafts
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/products/overdraft-calculator/" aria-label="Overdraft calculator" data-event-component="topnav" data-event-name="Banking: Already banking with us: Overdraft calculator">
                    Overdraft calculator
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                    
                        <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-1" class="header-mobile-doormat-1 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-borrowing hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Borrowing</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Short &amp; long-term</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-1">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/credit-cards/" data-event-component="topnav" data-event-name="Borrowing: Credit cards" class="doormat-heading-link">
        <h2 class="doormat-heading">Credit cards</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/balance-transfer-credit-cards/" aria-label="Balance transfer credit cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Balance transfer cards">
                    Balance transfer credit cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/purchase-credit-cards/" aria-label="Purchase cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Purchase cards">
                    Purchase cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/rewards-credit-cards/" aria-label="Rewards cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: rewards cards">
                    Rewards cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/credit-builder-credit-cards/" aria-label="Credit building cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Credit building cards">
                    Credit building cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/premier-credit-cards/" aria-label="Premier cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: Premier cards">
                    Premier cards
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/ways-to-borrow/" aria-label="Ways to borrow">
                    Ways to borrow
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/eligibility-checker/" aria-label="Credit card eligibility checker" data-event-component="topnav" data-event-name="Borrowing: Credit cards: credit card eligibility checker">
                    Credit card eligibility checker
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/products/" aria-label="See all credit cards" data-event-component="topnav" data-event-name="Borrowing: Credit cards: See all credit cards">
                    See all credit cards
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/loans/" data-event-component="topnav" data-event-name="Borrowing: Loans" class="doormat-heading-link">
        <h2 class="doormat-heading">Loans</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/personal/" aria-label="Personal Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Personal Loan">
                    Personal Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/premier/" aria-label="Premier Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Premier Loan">
                    Premier Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/car-loan/" aria-label="Car Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Car Loan">
                    Car Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/home-improvements/" aria-label="Home Improvement Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Home Improvement Loan">
                    Home Improvement Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/products/top-up-loans/" aria-label="Top up your loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Top up your loan">
                    Top up your loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/ways-to-borrow/" aria-label="Ways to borrow">
                    Ways to borrow
                </a>
            </li>
        
            <li>
                <a href="/loans/products/debt-consolidation/" aria-label="Debt Consolidation Loan" data-event-component="topnav" data-event-name="Borrowing: Loans: Debt Consolidation Loan">
                    Debt Consolidation Loan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/loans/" aria-label="See all loans" data-event-component="topnav" data-event-name="Borrowing: Loans: See all loans">
                    See all loans
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/mortgages/" data-event-component="topnav" data-event-name="Borrowing: Mortgages" class="doormat-heading-link">
        <h2 class="doormat-heading">Mortgages</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/existing-customers/switch/" aria-label="Switch your mortgage rate">
                    Switch your mortgage rate
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/move-your-mortgage/" aria-label="Remortgage to HSBC" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Remortgage to HSBC">
                    Remortgage to HSBC
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/first-time-buyers/" aria-label="First-time buyers" data-event-component="topnav" data-event-name="Borrowing: Mortgages: First-time Buyers">
                    First-time buyers
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/how-to-apply/" aria-label="Get a decision in principle" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Get a decision in principle">
                    Get a decision in principle
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/our-rates/" aria-label="Mortgage rates" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Mortgage rates">
                    Mortgage rates
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/calculators/" aria-label="Mortgage calculators" data-event-component="topnav" data-event-name="Borrowing: Mortgages: Calculators">
                    Mortgage calculators
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/application-in-progress/" aria-label="Continue my application">
                    Continue my application
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/95-percent/" aria-label="95% mortgages" data-event-component="topnav" data-event-name="Borrowing: Mortgages: 95% mortgages">
                    95% mortgages
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already borrowing with us?</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/existing-customers/" aria-label="Manage your existing mortgage" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Manage your existing mortgage">
                    Manage your existing mortgage
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/mortgage-payments/" aria-label="Mortgage payment support" data-event-component="topnav" data-event-name="Borrowing: Mortgage payment support">
                    Mortgage payment support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/existing-customers/switch/" aria-label="Switch your HSBC mortgage" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Switch your HSBC mortgage">
                    Switch your HSBC mortgage
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/existing-customers/" aria-label="Manage your credit card" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Manage your credit card">
                    Manage your credit card
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/fees/" aria-label="Credit card fees and rates" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Credit card fees and rates">
                    Credit card fees and rates
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/bank-of-england-base-rate/" aria-label="Base rate information" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Base rate information">
                    Base rate information
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/credit-cards/credit-card-repayment-calculator/" aria-label="Credit card repayment calculator" data-event-component="topnav" data-event-name="Borrowing: Already borrowing with us: Credit card repayment calculator">
                    Credit card repayment calculator
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                    
                        <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-2" class="header-mobile-doormat-2 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-investment hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Investing</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Products &amp; planning</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-2">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/investments/" data-event-component="topnav" data-event-name="Investing: Ways to invest" class="doormat-heading-link">
        <h2 class="doormat-heading">Investing</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/new-to-investing/" aria-label="New to investing?" data-event-component="topnav" data-event-name="investing: way to invest: new to investing">
                    New to investing?
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/isas/" aria-label="Stocks &amp; shares ISA" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in an ISA">
                    Stocks &amp; shares ISA
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/funds/" aria-label="Invest in funds" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in funds">
                    Invest in funds
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/sustainable-portfolios" aria-label="Invest in sustainable funds" data-event-component="topnav" data-event-name="investing: way to invest: invest in sustainable funds">
                    Invest in sustainable funds
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/invest-direct" aria-label="Invest in shares" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in shares">
                    Invest in shares
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/" aria-label="See all investments" data-event-component="topnav" data-event-name="Investing: Ways to invest: Invest in investments products">
                    See all investments
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/investments/advice/" data-event-component="topnav" data-event-name="Investing: Your advice options" class="doormat-heading-link">
        <h2 class="doormat-heading">Advice options</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/advice/my-investment/" aria-label="Online investment advice " data-event-component="topnav" data-event-name="Investing: Your advice options: Online investment advice">
                    Online investment advice 
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/advice/financial-advice" aria-label="Financial advice" data-event-component="topnav" data-event-name="Investing: Your advice options: Financial advice">
                    Financial advice
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/protection-advice/" aria-label="Protection advice" data-event-component="topnav" data-event-name="Investing: Your advice options: Protection advice">
                    Protection advice
                </a>
            </li>
        
    </ul>
</div>

        
    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/retirement/" class="doormat-heading-link">
        <h2 class="doormat-heading">Visualise your retirement</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://retirementcalculator.hsbc.co.uk/" aria-label="Retirement calculator" data-event-component="topnav" data-event-name="Investing: Visualise your retirement: Retirement calculator">
                    Retirement calculator
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/retirement/investing-for-retirement/" aria-label="Investing for retirement" data-event-component="topnav" data-event-name="Investing: Visualise your retirement: Investing for retirement">
                    Investing for retirement
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/wealth/planning/" data-event-component="topnav" data-event-name="Investing: Improve your knowledge " class="doormat-heading-link">
        <h2 class="doormat-heading">Improve your knowledge </h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/financial-action-plan" aria-label="Your financial action plan" data-event-component="topnav" data-event-name="Investing: Invest in yourself: Your financial action plan">
                    Your financial action plan
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/articles/what-is-sustainable-investing/" aria-label="What is sustainable investing?" data-event-component="topnav" data-event-name="investing: improve your knowledge: what is sustainable investing">
                    What is sustainable investing?
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/investment-calculator/" aria-label="Investment calculator" data-event-component="topnav" data-event-name="Investing: Invest in yourself: Investment calculator">
                    Investment calculator
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/education-calculator/" aria-label="Children?s education calculator" data-event-component="topnav" data-event-name="investing: improve your knowledge: children&#39;s education calculator">
                    Children?s education calculator
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/wealth/insights/" aria-label="Wealth Insights" data-event-component="topnav" data-event-name="Investing: Invest in yourself: HSBC Wealth insights">
                    Wealth Insights
                </a>
            </li>
        
    </ul>
</div>

        
    
        
        
            
            
            
            
            <div class="links-group">
    
    <ul class="doormat-links">
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already investing with us?</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/existing-customers/" aria-label="Existing customers" data-event-component="topnav" data-event-name="Investing: Already investing with us?: Existing customers">
                    Existing customers
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/existing-customers/global-investment-centre/" aria-label="How to buy and sell funds" data-event-component="topnav" data-event-name="Investing: Already investing with us?: How to buy and sell funds">
                    How to buy and sell funds
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/existing-customers/invest-direct/" aria-label="How to buy and sell shares" data-event-component="topnav" data-event-name="Investing: Already investing with us?: How to buy and sell shares">
                    How to buy and sell shares
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/onshore-investment-bond/" aria-label="Onshore Investment Bond" data-event-component="topnav" data-event-name="Investing: Already investing with us?: Onshore Investment Bond">
                    Onshore Investment Bond
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/investments/products/child-trust-fund/" aria-label="Child Trust Fund" data-event-component="topnav" data-event-name="Investing:Already investing with us?: Child Trust Fund">
                    Child Trust Fund
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                    
                        <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-3" class="header-mobile-doormat-3 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-insurance hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Insurance</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Property &amp; family</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-3">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/insurance/" data-event-component="topnav" data-event-name="Insurance: Insurance" class="doormat-heading-link">
        <h2 class="doormat-heading">Insurance</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/select-and-cover/" aria-label="Select and Cover" data-event-component="topnav" data-event-name="Insurance: Insurance: Select and cover">
                    Select and Cover
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/home/" aria-label="Home Insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: Home Insurance">
                    Home Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/contents/" aria-label="Contents Insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: Contents Insurance">
                    Contents Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/travel/" aria-label="Travel Insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: Travel Insurance">
                    Travel Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.business.hsbc.uk/en-gb/protection/insurance/" aria-label="Small Business Insurance" data-event-component="topnav" data-event-name="Banking: Insurance: Small Business Insurance">
                    Small Business Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/" aria-label="See all insurance" data-event-component="topnav" data-event-name="Insurance: Insurance: See all insurance">
                    See all insurance
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Claims</h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/select-and-cover/claims/" aria-label="Select and Cover claims" data-event-component="topnav" data-event-name="Insurance: Travel: Select and Cover claims">
                    Select and Cover claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/home/claims/" aria-label="Home Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Home Insurance claims">
                    Home Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/life/claims/" aria-label="Life Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Life Insurance claims">
                    Life Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/travel/claims/" aria-label="Travel Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Travel Insurance claims">
                    Travel Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/aspects/claims/" aria-label="Aspects Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Aspects Insurance claims">
                    Aspects Insurance claims
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/premier-travel/" aria-label="Premier Travel Insurance claims" data-event-component="topnav" data-event-name="Insurance: Travel: Premier Travel Insurance claims">
                    Premier Travel Insurance claims
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/insurance/life/" data-event-component="topnav" data-event-name="Insurance: Life:" class="doormat-heading-link">
        <h2 class="doormat-heading">Life</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/life-cover/" aria-label="Life Cover" data-event-component="topnav" data-event-name="Insurance: Life: Life Cover">
                    Life Cover
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/critical-illness-cover/" aria-label="Critical Illness Cover" data-event-component="topnav" data-event-name="Insurance: Life: Critical Illness Cover">
                    Critical Illness Cover
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/income-protection/" aria-label="Income Protection Insurance" data-event-component="topnav" data-event-name="Insurance: Life: Income Protection Insurance">
                    Income Protection Insurance
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/protection-advice/" aria-label="Protection advice" data-event-component="topnav" data-event-name="Insurance: Life: Protection advice">
                    Protection advice
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/life/" aria-label="See all life insurance" data-event-component="topnav" data-event-name="Insurance: Life: See all life insurance products">
                    See all life insurance
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    
        <h2 class="doormat-heading">Already insured by us? </h2>
    
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/select-and-cover/existing-customers/" aria-label="Select and Cover support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?: Select and Cover support">
                    Select and Cover support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/home/claims/" aria-label="Home Insurance support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?:  Home Insurance support">
                    Home Insurance support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/life/claims/" aria-label="Life Insurance support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?:  Life Insurance support">
                    Life Insurance support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/premier-travel/" aria-label="Premier Travel support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?:  Premier Travel support">
                    Premier Travel support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/insurance/products/aspects/" aria-label="Aspects Insurance support" data-event-component="topnav" data-event-name="Insurance: Already insured by us?: Aspects Insurance support">
                    Aspects Insurance support
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                    
                        <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-4" class="header-mobile-doormat-4 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-health hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Wellbeing</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Financial health &amp; support</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-4">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/financial-fitness/" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness" class="doormat-heading-link">
        <h2 class="doormat-heading">Financial fitness</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/fitness-score/" aria-label="Financial fitness score tool" data-event-component="topnav" data-event-name="Financial fitness score tool">
                    Financial fitness score tool
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/everyday-budgeting/" aria-label="Everyday budgeting" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness Everyday budgeting">
                    Everyday budgeting
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/managing-debt/" aria-label="Managing debt" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Managing debt">
                    Managing debt
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-fitness/growing-your-money/" aria-label="Growing your money" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Growing your money">
                    Growing your money
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/" aria-label="Staying safe and secure" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Staying safe and secure">
                    Staying safe and secure
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/financial-education/" aria-label="Learning about money" data-event-component="topnav" data-event-name="Wellbeing: Financial fitness: Learning about money">
                    Learning about money
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/new-beginnings/" data-event-component="topnav" data-event-name="Wellbeing: New Beginnings" class="doormat-heading-link">
        <h2 class="doormat-heading">New beginnings</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/new-beginnings/expanding-your-family/" aria-label="Expanding your family" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Expanding your family">
                    Expanding your family
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/new-beginnings/getting-married/" aria-label="Getting married" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Getting married">
                    Getting married
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/retirement/" aria-label="Planning for retirement" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Planning for retirement">
                    Planning for retirement
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/mortgages/first-time-buyers/" aria-label="Buying your first home" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Buying your first home">
                    Buying your first home
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/international/moving-abroad/" aria-label="Moving abroad" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Moving abroad">
                    Moving abroad
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/students/" aria-label="Going to uni" data-event-component="topnav" data-event-name="Wellbeing: New beginnings: Going to uni">
                    Going to uni
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/life-events/" data-event-component="topnav" data-event-name="Wellbeing: Life events" class="doormat-heading-link">
        <h2 class="doormat-heading">Life events</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/bereavement/" aria-label="Bereavement support" data-event-component="topnav" data-event-name="Wellbeing: Life events: Bereavement support">
                    Bereavement support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/assisting-someone-with-their-money/" aria-label="Assisting someone with their money" data-event-component="topnav" data-event-name="Wellbeing: Life events: Assisting someone with their money">
                    Assisting someone with their money
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/separation/" aria-label="Separation" data-event-component="topnav" data-event-name="Wellbeing: Life events: Separation ">
                    Separation
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/unexpected-change/redundancy/" aria-label="Losing your job" data-event-component="topnav" data-event-name="Wellbeing: Life events: Losing your job">
                    Losing your job
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/life-events/poa/" aria-label="Power of Attorney" data-event-component="topnav" data-event-name="Wellbeing: Life events: Power of attorney">
                    Power of Attorney
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/accessibility/mental-health-and-support/" aria-label="Mental health and support" data-event-component="topnav" data-event-name="Wellbeing: Life events: Mental health and support">
                    Mental health and support
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/money-worries/" data-event-component="topnav" data-event-name="Wellbeing: Money worries" class="doormat-heading-link">
        <h2 class="doormat-heading">Money worries</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/how-we-can-help/" aria-label="How we can help" data-event-component="topnav" data-event-name="Wellbeing: Money worries: How we can help">
                    How we can help
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/mortgage-payments/" aria-label="Mortgage payment support" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Mortgage payment support">
                    Mortgage payment support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/financial-abuse/" aria-label="Financial and domestic abuse" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Financial and domestic abuse">
                    Financial and domestic abuse
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/money-worries/managing-your-finances/" aria-label="Managing your finances" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Managing your finances">
                    Managing your finances
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/coronavirus/" aria-label="Coronavirus support" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Coronavirus support">
                    Coronavirus support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/card-support/gambling-restrictions/" aria-label="Support for gambling" data-event-component="topnav" data-event-name="Wellbeing: Money worries: Support for gambling">
                    Support for gambling
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                    
                        <li class="header-main-navigation-item" tabindex="0">
    
    <div data-target="header-doormat-5" class="header-mobile-doormat-5 header-doormat-mobile-title sidebar-submenu-trigger">
        <span class="icon icon-help hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-title">Help</span>
        <span class="icon icon-chevron-right hide-on-desktop" aria-hidden="true"></span>
        <span class="header-main-navigation-subtitle">Service &amp; security</span>
    </div>
    <div aria-hidden="true" class="doormat-menu" data-source="header-doormat-5">
        <div class="doormat-container row">
            <div class="doormat-main sm-12 lg-9">
                <div class="row">
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/banking-made-easy/" data-event-component="topnav" data-event-name="Help: Managing your account" class="doormat-heading-link">
        <h2 class="doormat-heading">Managing your account</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/" aria-label="Ways to bank" data-event-component="topnav" data-event-name="Help: Managing your account: Ways to bank">
                    Ways to bank
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/card-support/" aria-label="Card support" data-event-component="topnav" data-event-name="Help: Managing your account: Card support">
                    Card support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/how-to-set-up-a-direct-debit/" aria-label="Set up or cancel a Direct Debit" data-event-component="topnav" data-event-name="Help: Managing your account: Set up or cancel a direct debit">
                    Set up or cancel a Direct Debit
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/how-to-set-up-standing-order/" aria-label="Set up or cancel a standing order" data-event-component="topnav" data-event-name="Help: Managing your account: Set up or cancel a standing order">
                    Set up or cancel a standing order
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/card-support/dispute-transaction/" aria-label="Query a transaction" data-event-component="topnav" data-event-name="Help: Managing your account: Query a transaction">
                    Query a transaction
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/security-centre/" data-event-component="topnav" data-event-name="Help: Fraud and security" class="doormat-heading-link">
        <h2 class="doormat-heading">Fraud and security</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/fraud-guide/" aria-label="Fraud guide" data-event-component="topnav" data-event-name="Help: Fraud and security: Fraud guide">
                    Fraud guide
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/received-a-text/" aria-label="Received a text?" data-event-component="topnav" data-event-name="Help: Fraud and security: Received a text">
                    Received a text?
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/hsbc-safeguard/" aria-label="HSBC Safeguard" data-event-component="topnav" data-event-name="Help: Fraud and security: HSBC Safeguard">
                    HSBC Safeguard
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/secure-key/" aria-label="Secure Key" data-event-component="topnav" data-event-name="Help: Fraud and security: Secure Key">
                    Secure Key
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/digital-security-promise/" aria-label="Our Digital Security Promise" data-event-component="topnav" data-event-name="Help: Fraud and security: Our Digital Security Promise">
                    Our Digital Security Promise
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                    <div class="doormat-main-column sm-12 lg-4">
                        <div class="doormat-column-content">



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/banking-made-easy/" data-event-component="topnav" data-event-name="Help: Digital banking" class="doormat-heading-link">
        <h2 class="doormat-heading">Digital banking</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/register/" aria-label="Register for digital banking" data-event-component="topnav" data-event-name="Help: Digital banking: Register for digital banking">
                    Register for digital banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/mobile/" aria-label="Mobile banking" data-event-component="topnav" data-event-name="Help: Digital banking: Mobile banking">
                    Mobile banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/online-banking/" aria-label="Online banking" data-event-component="topnav" data-event-name="Help: Digital banking: Online banking">
                    Online banking
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/current-accounts/banking-at-home/" aria-label="Banking at home" data-event-component="topnav" data-event-name="Help: Digital banking: Banking at home">
                    Banking at home
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/ways-to-bank/mobile/cheque-deposit/" aria-label="Mobile cheque deposit" data-event-component="topnav" data-event-name="Help: Digital banking: Mobile cheque deposit">
                    Mobile cheque deposit
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/security-centre/lost-your-details/" aria-label="Reset your online banking details" data-event-component="topnav" data-event-name="Help: Digital banking: Reset your online banking details">
                    Reset your online banking details
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                    </div>
                </div>
            </div>
            <div class="doormat-highlight sm-12 lg-3">
                <div class="doormat-highlight-menu">
                    <div>



    
        
        
            
            
            
            
            <div class="links-group">
    <a href="https://www.hsbc.co.uk/help/" data-event-component="topnav" data-event-name="Help: Help" class="doormat-heading-link">
        <h2 class="doormat-heading">Help</h2>
    </a>
    <ul class="doormat-links">
        
            <li>
                <a href="https://www.hsbc.co.uk/help/" aria-label="Customer support" data-event-component="topnav" data-event-name="Help: Help: Customer support">
                    Customer support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/feedback-and-complaints/" aria-label="Feedback and complaints" data-event-component="topnav" data-event-name="Help: Help: Feedback and complaints">
                    Feedback and complaints
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/coronavirus/" aria-label="Coronavirus support" data-event-component="topnav" data-event-name="Help: Help: Coronavirus support">
                    Coronavirus support
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/bank-of-england-base-rate/" aria-label="Bank of England base rate" data-event-component="topnav" data-event-name="Help: Help: Bank of England base rate">
                    Bank of England base rate
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/help/banking-made-easy/making-payments/" aria-label="Making payments" data-event-component="topnav" data-event-name="Help: Help: Making payments">
                    Making payments
                </a>
            </li>
        
            <li>
                <a href="https://www.hsbc.co.uk/accessibility/" aria-label="Accessibility and disability" data-event-component="topnav" data-event-name="Help: Help: Accessibility and disability">
                    Accessibility and disability
                </a>
            </li>
        
    </ul>
</div>

        
    

</div>
                </div>
            </div>
        </div>
    </div>
</li>
                    
                    
                    
                    
                        <li class="header-mobile-selected-item" tabindex="0" role="menuitem">
                            <span class="visuallyhidden">Language</span>
                            <span class="icon icon-settings" aria-hidden="true"></span>
                            English
                        </li>
                        
                    
                </ul>
                <div class="sidebar-submenu-wrapper" data-source="sidebar-submenu-language">
                    <p class="sidebar-submenu-label">Language</p>
                    <ul class="locale-management">
                        <li class="is-active">
                            
                            <a class="sidebar-submenu-link" href="#" lang="en">
                                <span class="visuallyhidden">Selected</span>
                                English
                                <span class="icon icon-agree" aria-hidden="true"></span>
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="header-mobile-sidebar-footer header-dropdown">
                    <ul class="header-mobile-business-links">
                        <li>
                            <a class="header-mobile-business-item register-button" href="https://www.hsbc.co.uk/register/" data-event-component="topnav" data-event-name="Register">
                                Register
                                <span class="icon icon-chevron-right" aria-hidden="true"></span>
                            </a>
                        </li>
                        <li>
                            <a class="header-mobile-business-item my-accounts-button hidden" href="https://www.hsbc.co.uk/online/dashboard/">
                                Back to my accounts
                                <span class="icon icon-chevron-right" aria-hidden="true"></span>
                            </a>
                        </li>
                        
                            <li>
                                <a class="header-mobile-business-item" href="http://www.business.hsbc.uk/">
                                    Business
                                    <span class="icon icon-chevron-right" aria-hidden="true"></span>
                                </a>
                            </li>
                        
                    </ul>
                </div>
                <div class="close-submenu-trigger hidden" role="button" tabindex="0" aria-label="Close Submenu">
                    <span class="icon icon-chevron-left" aria-hidden="true"></span>
                </div>
                <button class="visuallyhidden sidebar-hidden-close-button">Close menu</button>
            </div>
        </nav>
        <div class="header-mobile-overlay"></div>
        <div class="header-mobile-logo">
            
            <a href="https://www.hsbc.co.uk/">
                <img src="/content/dam/hsbc/gb/images/logos/hsbc-uk.svg" alt="HSBC UK home page">
            </a>
        </div>
        <div class="primary-button header-login-button header-dropdown">
            
            <a class="selected-item login-button only-one-link" href="https://www.hsbc.co.uk/online/dashboard/" tabindex="0" role="button">
                Log on
            </a>
            <a class="cpi-masthead-logoff__button-dpws logout-button hidden" href="#cpi" tabindex="0" role="button" data-event-component="topnav" data-event-name="Log off">
                Log off
            </a>
            
        </div>
    </div>
</div>
            </div>
        </div>
    </header>
</div>
<span id="top-of-content" class="top-of-content visuallyhidden" tabindex="-1">Top of main content</span>


</div>

    
    
    <div class="background-image">
        <div class='image image-data' data-src='url("")'></div>
    </div>

<div class="grid">
    <div class="row">
    <div class="sm-12"><div>
    <div class="A-ERRORCONT-RW-ALL sm-12 md-6 error-content" aria-live="assertive">
        <h3 class="title">
            <span class="title-text">Page not found (404)</span>
        </h3>
        <p class="description">We are sorry, that page can?t be found. The page may have been moved or deleted.

Please try finding the new page from the homepage navigation.</p>
        <span class="buttons">
            <a href="https://www.hsbc.co.uk/index" class="continue">
                <span>Go to homepage</span>
                
            </a>
            
        </span>
    </div>
</div></div>
</div>

</div>


<div class="socialMediaFooter grid ">
    
        <div class="row social-row ">
            
    <span class="A-DIVHL-RW-ALL"></span>

            <div class="sm-12 lg-9">
                
    
    
    
    
    <div class="link-container">
        <a class="A-LNKC22L-RW-ALL" href="https://www.hsbc.co.uk/help/" rel="nofollow" data-event-component="text link" data-event-name="Customer support">
            
    <h2 class="link link-header">
        Customer support
    </h2>&nbsp;<span class="icon icon-chevron-right-small" aria-hidden="true"></span>
    

            
            
        </a>
    </div>


                
    
    <div class="A-PAR16R-RW-ALL">It?s easy to answer your query online. Visit our Help page to find out how.</div>

            </div>
            <div class="sm-12 lg-3">
                <div class="right-column">
                    <span class="social-link">
                        <a class="social-image social-icon-facebook" href="https://www.facebook.com/hsbcuk" rel="noopener noreferrer" data-event-component="other" data-event-name="Facebook Icon" target="_blank">
                            <span class="visuallyhidden">Follow HSBC UK on Facebook This link will open in a new window</span>
                        </a>
                    </span>
                
                    <span class="social-link">
                        <a class="social-image social-icon-twitter" href="https://twitter.com/HSBC_UK" rel="noopener noreferrer" data-event-component="other" data-event-name="Twitter icon" target="_blank">
                            <span class="visuallyhidden">Follow HSBC UK on Twitter This link will open in a new window</span>
                        </a>
                    </span>
                
                    <span class="social-link">
                        <a class="social-image social-icon-youtube" href="https://www.youtube.com/user/hsbcuk" rel="noopener noreferrer" data-event-component="other" data-event-name="YouTube logo" target="_blank">
                            <span class="visuallyhidden">Follow HSBC UK on YouTube This link will open in a new window</span>
                        </a>
                    </span>
                </div>
            </div>
        </div>
    
</div>
<footer class="footer">
<ul class="header-mobile-footer-item-wrapper" role="menu">
    <li class="header-mobile-footer-item hide-on-desktop header-main-navigation-item" role="menuitem">
        <div class="header-doormat-mobile-title" tabindex="0">
            <span class="icon icon-circle-info" aria-hidden="true"></span>
            <span class="header-mobile-footer-title">About HSBC</span>
            <span class="icon icon-chevron-right" aria-hidden="true"></span>
        </div>
    </li>
</ul>
<div class="footer-main">
    <div class="grid">
        <div class="row wrapper">
            <nav aria-label="Footer navigation">
                <ul class="footer-large">
                    <li class="footer-large-item lg-3">
                        <div class="footer-large-title">
                            <i class="icon icon-phone" aria-hidden="true"></i>
                            <h2 class="footer-section-title">Help &amp; support</h2>
                        </div>
                        <a href="https://www.hsbc.co.uk/help/" data-event-component="footer" data-event-name="Got a question? We&#39;re here to help you">
                            <span class="visuallyhidden">Contact HSBC</span>
                            Got a question? We&#39;re here to help you&nbsp;<i class="icon icon-chevron-right" aria-hidden="true"></i>
                        </a>
                    </li>
                    <li class="footer-large-item lg-3">
                        <div class="footer-large-title">
                            <i class="icon icon-location" aria-hidden="true"></i>
                            <h2 class="footer-section-title">Branch finder</h2>
                        </div>
                        <a href="https://www.hsbc.co.uk/branch-finder/" data-event-component="footer" data-event-name="Find your nearest branch">
                            
                            Find your nearest branch&nbsp;<i class="icon icon-chevron-right" aria-hidden="true"></i>
                        </a>
                    </li>
                    <li class="footer-large-item lg-3">
                        <div class="footer-large-title">
                            <i class="icon icon-circle-info" aria-hidden="true"></i>
                            <h2 class="footer-section-title">Our service performance</h2>
                        </div>
                        <a href="https://www.hsbc.co.uk/service-status/" data-event-component="footer" data-event-name="View our service status to see how we&#39;re doing">
                            
                            View our service status to see how we&#39;re doing&nbsp;<i class="icon icon-chevron-right" aria-hidden="true"></i>
                        </a>
                    </li>
                    <li class="footer-large-item lg-3">
                        <div class="footer-large-title">
                            <i class="icon icon-global" aria-hidden="true"></i>
                            <h2 class="footer-section-title">About HSBC</h2>
                        </div>
                        <a href="http://www.about.hsbc.co.uk/" data-event-component="footer" data-event-name="Careers, media, investor and corporate information">
                            
                            Careers, media, investor and corporate information&nbsp;<i class="icon icon-chevron-right" aria-hidden="true"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<div class="footer-bottom">
    <div class="grid">
        <div class="row wrapper">
            <nav class="lg-7" aria-label="Footer navigation">
                <ul class="footer-supplementary clearfix">
                    
                        <li class="footer-supplementary-item">
                            <a href="https://www.hsbc.co.uk/legal/">Legal</a>
                        </li>
                    
                        <li class="footer-supplementary-item">
                            <a href="https://www.hsbc.co.uk/privacy-notice/" rel="nofollow">Privacy notice</a>
                        </li>
                    
                        <li class="footer-supplementary-item">
                            <a href="https://www.hsbc.co.uk/cookie-notice/" rel="nofollow">Cookie notice</a>
                        </li>
                    
                        <li class="footer-supplementary-item">
                            <a href="https://www.hsbc.co.uk/accessibility/">Accessibility</a>
                        </li>
                    
                        <li class="footer-supplementary-item">
                            <a href="https://www.hsbc.com/who-we-are/esg-and-responsible-business/modern-slavery-act/">Stopping modern slavery</a>
                        </li>
                    
                    
                </ul>
            </nav>
            
    
    <div class="footer-legal-regulatory sm-12 lg-5 text"><p>� <a href="http://www.hsbc.com/" target="_blank" rel="noopener">HSBC Group</a>� | �� Copyright HSBC Group 2002-2022. All rights reserved</p>

<p><a href="https://www.hsbc.co.uk/site-terms/#anchorc">This website is designed for use in the United Kingdom.</a></p>


</div>

        </div>
    </div>
</div>
</footer>



<script type="text/javascript" src="/etc/designs/dpws/clientlib-jquery.5ea5c4f95742f26a1d6b25eb830feb0c.js"></script>


    
    
<script type="text/javascript" src="/etc/designs/hsbc/cpi/clientlib-site/v2_2_0.min.25e7676b14f56aa25050f77c6b594232.js"></script>



    
    
<script type="text/javascript" src="/etc/designs/hsbc/cpi-masthead/clientlib-site/v2_2_0.min.d391cf12edbe9cb0aa6a5cd650eb0567.js"></script>



    
    
<script type="text/javascript" src="/etc/designs/dpws/clientlib-all.min.72b73cbe882c7b5dbbe17fce78aaeff6.js"></script>






<div class="cloudservice appd"><!-- This is blank file acting as a renderer for appd cloudservice --></div>
<div class="cloudservice ttm"><!-- This is blank file acting as a renderer for ttm cloudservice --></div>




<div id="virtual-assistant" class="vainline" style="display: none;">
    <script src="//www.askus.hsbc.co.uk/counter-service/embedp2/va.js"></script>
</div>
</body>
</html>
