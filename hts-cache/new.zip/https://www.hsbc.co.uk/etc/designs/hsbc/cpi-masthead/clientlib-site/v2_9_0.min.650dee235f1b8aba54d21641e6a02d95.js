(function(){var e=document.querySelector(".cpi-skip-to-main-content");
var d;
function b(){document.getElementById("cpiMainContent").focus()
}function c(){d=cpiUtils.eventHandler.addEvent(e,"click",b)
}function a(){if(d&&Object.keys(d).length>0){cpiUtils.eventHandler.removeEvent(d);
d=null
}}cpiUtils.eventHandler.addEvent(e,"focus",c);
cpiUtils.eventHandler.addEvent(e,"blur",a)
})();
(function(){var j=new RegExp("^Enter$");
var i=new RegExp("^Escape$|^Esc$");
var R=new RegExp("^ $|^Spacebar$");
var aa=new RegExp("^ $|^Tab$");
var ao=document.querySelector(".cpi-masthead-navigation");
var u=document.querySelector(".cpi-menubar");
var d=document.querySelector(".cpi-masthead-logo");
var ad=document.querySelectorAll(".cpi-notifications, .cpi-masthead-logoff__button, .cpi-switcher__button");
var c=null;
var E=759;
var ap=document.querySelector(".cpi-hamburger-button");
var A=document.querySelector(".cpi-main-header");
var F=document.querySelectorAll(".cpi-hamburger-menu-button--close-doormat");
var T=document.querySelectorAll(".cpi-hamburger-menu-button--cancel-doormat");
var al=document.querySelector(".cpi-hamburger-menu-button--cancel-main-menu");
var M=document.querySelector(".cpi-wrapper__journey");
var r=document.querySelector(".cpi-main-footer");
var K=null;
var aj={activeMenubarItem:null,savedMenubarItem:null,doormatLinks:null,focusedDoormatItem:null};
var G={group:function(){},groupEnd:function(){},log:function(){}};
function y(aw){G.group("_eventOutsideMenu");
G.groupEnd();
return !u.contains(aw.target)
}function B(aw){var ax=document.querySelector(".cpi-modal-wrapper");
G.group("_eventOutsideModal");
G.groupEnd();
return !ax.contains(aw.target)
}function m(){G.group("_focusDoormatItem");
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
G.log("menuState.focusedDoormatItem",aj.focusedDoormatItem);
if(aj.focusedDoormatItem&&aj.activeMenubarItem.parentNode.contains(aj.focusedDoormatItem)){G.log("focusing","yes");
aj.focusedDoormatItem.focus()
}G.groupEnd()
}function C(){G.group("_isHamburgerMenuActive");
G.groupEnd();
return window.innerWidth<=E
}function e(){return aj.activeMenubarItem.getAttribute("href")==="#"
}function q(){G.group("_showHamburgerDoormatTitle");
aj.activeMenubarItem.classList.add("cpi-menubar--hide-from-screenreader");
aj.activeMenubarItem.nextElementSibling.classList.remove("cpi-hidden-content");
aj.activeMenubarItem.nextElementSibling.classList.remove("cpi-menubar--hide-from-screenreader");
aj.activeMenubarItem.nextElementSibling.classList.add("cpi-menubar__menu-item--active");
G.groupEnd()
}function ak(){G.group("_hideHamburgerDoormatMenubarItem");
aj.activeMenubarItem.classList.remove("cpi-menubar--hide-from-screenreader");
aj.activeMenubarItem.nextElementSibling.classList.add("cpi-hidden-content");
aj.activeMenubarItem.nextElementSibling.classList.add("cpi-menubar--hide-from-screenreader");
aj.activeMenubarItem.nextElementSibling.classList.remove("cpi-menubar__menu-item--active");
G.groupEnd()
}function o(){G.group("_hideHamburgerMenu");
r.classList.remove("cpi-main-footer--hamburger-expanded");
A.classList.remove("cpi-main-header--hamburger-vp");
M.classList.remove("cpi-hide-block");
ap.setAttribute("aria-expanded","false");
ap.focus();
G.groupEnd()
}function ar(){if(e()){aj.activeMenubarItem.tabIndex=-1
}else{aj.activeMenubarItem.parentNode.classList.remove("cpi-menubar__menu-item-wrapper--active");
aj.activeMenubarItem.classList.remove("cpi-menubar__menu-item--active");
o()
}}function z(){G.group("resizeEventHandler");
if(aj.activeMenubarItem){if(C()){ar()
}else{ak();
aj.activeMenubarItem.tabIndex=0
}}G.groupEnd()
}function ai(){var aw;
G.group("_setExpandedDoormatForHamburger");
aw=cpiUtils.closest(aj.activeMenubarItem.parentElement,"li").querySelector(".cpi-hamburger-menu-button--close-doormat");
aj.activeMenubarItem=cpiUtils.closest(aj.activeMenubarItem.parentElement,".cpi-menubar__menu-item-wrapper").querySelector(".cpi-menubar__menu-item");
aj.activeMenubarItem.removeAttribute("aria-expanded");
aj.activeMenubarItem.removeAttribute("aria-haspopup");
aj.activeMenubarItem.tabIndex=-1;
aw.focus();
G.groupEnd()
}function P(){G.group("_setExpandedDoormatForMenubar");
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
if(e()){aj.activeMenubarItem.setAttribute("aria-expanded","true")
}G.groupEnd()
}function x(){G.group("_setExpandedDoormat");
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
A.classList.add("cpi-main-header--hamburger-vp");
r.classList.add("cpi-main-footer--hamburger-expanded");
if(e()){A.classList.add("cpi-main-header--expanded-doormat")
}K=cpiUtils.eventHandler.addEvent(window,"resize",z);
aj.activeMenubarItem.parentNode.classList.add("cpi-menubar__menu-item-wrapper--active");
if(C()){ai();
q()
}else{aj.activeMenubarItem.classList.add("cpi-menubar__menu-item--active");
P()
}m();
G.groupEnd()
}function ac(){G.group("_removeActiveMenubarItemForHamburger");
aj.activeMenubarItem=cpiUtils.closest(aj.activeMenubarItem.parentElement,".cpi-menubar__menu-item-wrapper").querySelector(".cpi-menubar__menu-item");
aj.activeMenubarItem.parentNode.classList.remove("cpi-menubar__menu-item-wrapper--active");
aj.activeMenubarItem.setAttribute("aria-expanded","false");
aj.activeMenubarItem.setAttribute("aria-haspopup","true");
if(C()){ak()
}else{aj.activeMenubarItem.classList.remove("cpi-menubar__menu-item--active")
}if(e()){aj.activeMenubarItem.parentNode.querySelector(".cpi-menubar__menu-item").focus()
}aj.activeMenubarItem.tabIndex=0;
G.groupEnd()
}function au(){G.group("_activeMenubarItem");
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
aj.activeMenubarItem.classList.remove("cpi-menubar__menu-item--active");
if(C()){ac()
}else{aj.activeMenubarItem.parentNode.classList.remove("cpi-menubar__menu-item-wrapper--active");
aj.activeMenubarItem.setAttribute("aria-expanded","false")
}if(K){cpiUtils.eventHandler.removeEvent(K);
K=null
}G.groupEnd()
}function ag(){G.group("_removeActiveMenubarItem");
if(!C()){A.classList.remove("cpi-main-header--hamburger-vp");
r.classList.remove("cpi-main-footer--hamburger-expanded");
M.classList.remove("cpi-hide-block")
}A.classList.remove("cpi-main-header--expanded-doormat");
if(aj.activeMenubarItem){au()
}aj.activeMenubarItem=null;
G.groupEnd()
}function V(){G.group("_resetDoormatFocus");
aj.focusedDoormatItem=null;
G.groupEnd()
}function I(){G.group("_removeDoormatTabbing");
if(aj.doormatLinks){cpiUtils.forEach(aj.doormatLinks,function(aw,ax){ax.tabIndex=-1
});
aj.doormatLinks=null
}G.groupEnd()
}function av(){G.group("_addDoormatTabbing");
I();
aj.doormatLinks=aj.activeMenubarItem.parentNode.querySelectorAll(".cpi-doormat__menu-item");
cpiUtils.forEach(aj.doormatLinks,function(aw,ax){ax.tabIndex=0
});
G.groupEnd()
}function b(aw){G.group("_setActiveMenubarItem");
G.log("element",aw);
if(aj.activeMenubarItem!==aw){if(aj.activeMenubarItem){ag();
I()
}aj.activeMenubarItem=aw
}else{I()
}G.groupEnd()
}function aq(){G.group("_removeGlobalEventListners");
if(c){c.forEach(function(aw){cpiUtils.eventHandler.removeEvent(aw)
})
}c=null;
G.groupEnd()
}function h(){G.group("getActiveMenubarItem");
G.groupEnd();
return aj.activeMenubarItem
}function Z(aw){G.group("expandDoormatNoTabbing");
b(aw);
if(aj.focusedDoormatItem){aj.focusedDoormatItem=null
}x();
G.groupEnd()
}function v(aw){G.group("expandDoormatWithTabbing");
b(aw);
if(aj.focusedDoormatItem){av()
}x();
G.groupEnd()
}function g(){G.group("expandSavedMenubarItem");
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
G.log("menuState.savedMenubarItem",aj.savedMenubarItem);
if(aj.activeMenubarItem){ag()
}if(aj.savedMenubarItem){aj.activeMenubarItem=aj.savedMenubarItem;
av();
x()
}else{aj.activeMenubarItem=null
}G.groupEnd()
}function a(){G.group("hasSavedMenubarItem");
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
G.log("menuState.savedMenubarItem",aj.savedMenubarItem);
G.log("returns",!!(aj.savedMenubarItem&&aj.activeMenubarItem!==aj.savedMenubarItem));
G.groupEnd();
return !!aj.savedMenubarItem
}function U(){G.group("setSavedMenubarItem");
G.log("menuState.savedMenubarItem",aj.savedMenubarItem);
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
if(aj.savedMenubarItem!==aj.activeMenubarItem){aj.savedMenubarItem=aj.activeMenubarItem
}G.log("menuState.savedMenubarItem",aj.savedMenubarItem);
G.groupEnd()
}function H(aw){G.group("setActiveDoormatItem");
aj.focusedDoormatItem=aw?aw:document.activeElement;
G.log("setActiveDoormatItem",aj.focusedDoormatItem);
G.groupEnd()
}function af(){G.group("setFocusToFirstDoormatItem");
av();
G.log("menuState.doormatLinks[0]",aj.doormatLinks[0]);
aj.focusedDoormatItem=aj.doormatLinks[0];
G.log("menuState.focusedDoormatItem",aj.focusedDoormatItem);
m();
G.groupEnd()
}function an(){G.group("menubarHasFocus");
G.log("menuState.focusedDoormatItem",aj.focusedDoormatItem);
G.log("document.activeElement",document.activeElement);
G.log("returns",document.activeElement!==aj.focusedDoormatItem&&u.contains(document.activeElement));
G.groupEnd();
return document.activeElement!==aj.focusedDoormatItem&&u.contains(document.activeElement)
}function O(){G.group("doormatHasFocus");
G.log("menuState.focusedDoormatItem",aj.focusedDoormatItem);
G.log("returns",!!aj.focusedDoormatItem);
G.groupEnd();
return !!aj.focusedDoormatItem
}function k(){G.group("resetMenuState");
aq();
I();
ag();
V();
G.groupEnd()
}function w(){G.group("addGlobalListeners");
if(!c){c=[cpiUtils.eventHandler.addEvent(document,"keyup",J),cpiUtils.eventHandler.addEvent(document,"click",L)]
}G.groupEnd()
}function p(aw){G.group("getKeyFromEvent");
G.log("key",aw.key||String.fromCharCode(aw.keyCode));
G.groupEnd();
return aw.key||String.fromCharCode(aw.keyCode)
}function ah(){G.group("mouseenterEventHandler");
if(!C()){w()
}G.groupEnd()
}function t(){G.group("_expandMenubarItems");
if(O()&&a()){g()
}else{if(an()){v(document.activeElement)
}else{k()
}}G.groupEnd()
}function f(aw){G.group("mouseleaveEventHandler");
if(!C()){G.log("event.target",aw.target);
t()
}G.groupEnd()
}function W(aw){G.group("_hamburgerNavigationOnEscape");
if(aw.target.classList.contains("cpi-menubar__menu-item")||aw.target.classList.contains("cpi-hamburger-menu-button--cancel-main-menu")){o()
}else{ag()
}G.groupEnd()
}function Y(ax){var aw;
G.group("navigationKeyupEventHandler");
aw=p(ax);
if(C()&&i.test(aw)){W(ax)
}G.groupEnd()
}function S(ax){var aw;
G.group("menubarItemClickEventHandler");
aw=cpiUtils.closest(ax.target,"a");
if(C()){setTimeout(function(){Z(aw);
w();
av()
},100)
}else{U();
af();
ax.preventDefault()
}G.groupEnd()
}function Q(ax){var aw;
G.group("menubarItemKeyupEventHandler");
aw=p(ax);
if(C()){if(R.test(aw)){S(ax)
}}G.groupEnd()
}function s(ax){var aw=cpiUtils.closest(ax.target,"a");
if(!C()&&aw!==h()){G.group("menubarItemMousemoveEventHandler");
G.log("targetMenubarItem",aw);
G.log("getActiveMenubarItem()",h());
v(aw);
G.groupEnd()
}}function X(aw){G.group("menubarItemFocusEventHandler");
if(!C()){G.log("event.target",aw.target);
G.log("menuState.activeMenubarItem",aj.activeMenubarItem);
Z(aw.target);
w()
}G.groupEnd()
}function ab(aw){G.group("keyupMenubarEventHandler");
if(j.test(aw)||R.test(aw)){G.group("keyupMenubarEventHandler");
af()
}G.groupEnd()
}function D(aw,ax){G.group("keyupDoormatEventHandler");
if(aa.test(aw)&&ax.className==="cpi-doormat__menu-item"){H()
}G.groupEnd()
}function N(aw,ax){G.group("_checkHamburgerAndMenubarState");
if(!C()&&aj.activeMenubarItem===ax){ab(aw)
}G.groupEnd()
}function am(ax){var aw;
G.group("keyupEventHandler");
aw=p(ax);
if(aj.activeMenubarItem&&u.contains(ax.target)){D(aw,ax.target);
N(aw,ax.target)
}G.groupEnd()
}function J(aw){G.group("globalKeyupEventHandler");
if(!C()&&y(aw)&&B(aw)&&!O()){k()
}G.groupEnd()
}function L(aw){G.group("globalClickEventHandler");
if(!C()&&y(aw)&&B(aw)){k()
}G.groupEnd()
}function at(){G.group("hamburgerButtonClickHandler");
r.classList.add("cpi-main-footer--hamburger-expanded");
A.classList.add("cpi-main-header--hamburger-vp");
M.classList.add("cpi-hide-block");
ap.setAttribute("aria-expanded","true");
al.focus();
G.groupEnd()
}function n(){G.group("hamburgerCancelButtonClickHandler");
o();
G.groupEnd()
}function l(){G.group("doormatCancelButtonsClickHandler");
ag();
o();
G.groupEnd()
}function ae(){G.group("doormatCloseButtonClickEventHandler");
ag();
G.groupEnd()
}if(u){cpiUtils.forEach(u.querySelectorAll(".cpi-menubar__menu-item"),function(aw,ax){cpiUtils.eventHandler.addEvent(ax,"click",S);
cpiUtils.eventHandler.addEvent(ax,"keyup",Q);
cpiUtils.eventHandler.addEvent(ax,"focus",X);
cpiUtils.eventHandler.addEvent(ax,"mousemove",s)
});
cpiUtils.eventHandler.addEvent(ao,"mouseenter",ah);
cpiUtils.eventHandler.addEvent(ao,"mouseleave",f);
cpiUtils.eventHandler.addEvent(ao,"keyup",Y);
cpiUtils.eventHandler.addEvent(u,"keyup",am);
cpiUtils.eventHandler.addEvent(d,"focus",k);
cpiUtils.eventHandler.addEvent(ap,"click",at);
cpiUtils.eventHandler.addEvent(al,"click",n);
cpiUtils.forEach(T,function(aw,ax){cpiUtils.eventHandler.addEvent(ax,"click",l)
});
cpiUtils.forEach(ad,function(aw,ax){cpiUtils.eventHandler.addEvent(ax,"focus",k)
});
cpiUtils.forEach(F,function(aw,ax){cpiUtils.eventHandler.addEvent(ax,"click",ae)
})
}})();
(function(){var c=document.getElementById("cpiAPIConfigScript");
var a=document.querySelector(".cpi-notifications__badge");
var f=document.querySelectorAll(".cpi-notifications__accessible");
var d=null;
function h(k,l){var j=null;
cpiUtils.forEach(f,function(m,n){if(n.getAttribute("data-notification-type")===k){n.setAttribute("aria-hidden",false)
}else{n.setAttribute("aria-hidden",true)
}if(n.getAttribute("data-notification-type")==="many"){j=n.innerHTML;
n.innerHTML=cpiUtils.templateReplace(j,{notificationsCount:l})
}})
}function e(j){if(j>1){h("many",j)
}else{if(j===1){h("one",j)
}else{h("zero")
}}}function b(j){if(j!==0){a.setAttribute("data-cpi-badge",j);
a.classList.add("cpi-notifications__badge--visible")
}else{a.setAttribute("data-cpi-badge","");
a.classList.remove("cpi-notifications__badge--visible")
}}function i(m){var k=JSON.parse(m);
var l=k.responseInfo.reasons[0];
var n=k.messagesStatistics;
var j;
if(l.code==="000"&&l.type==="SUCCESS"){j=parseInt(n.unreadCount,10);
b(j);
e(j)
}else{b("!");
h("error")
}}function g(){b("!");
h("error")
}if(c){document.addEventListener("DOMContentLoaded",function(){d=c.getAttribute("data-notifications-url");
if(a&&f){cpiUtils.minimalAjax(d,i,g)
}})
}})();
(function(){var b=document.querySelector(".cpi-masthead-logoff__button");
function a(){cpiUtils.logoffUser()
}if(b){cpiUtils.eventHandler.addEvent(b,"click",function(c){cpiUtils.navigationHandler(c,a)
})
}})();
(function(){document.addEventListener("DOMContentLoaded",function(){var a=document.querySelectorAll(".cpi-masthead-logo, .cpi-menubar, .cpi-notifications, .cpi-hamburger-legal, .cpi-hamburger-social-links");
cpiUtils.forEach(a,function(b,c){cpiUtils.eventHandler.addEvent(c,"click",cpiUtils.navigationHandler)
})
})
})();
(function(){var n=document.querySelectorAll("div[data-cpi-switcher]");
var h=false;
var l=null;
var r=null;
var q=null;
function s(x){return x.querySelector("div[data-cpi-switcher-content]")
}function u(y){var x=y.querySelector(".cpi-switcher__button-icon");
if(x.classList.contains("cpi-icon-chevron-up-small")){x.classList.remove("cpi-icon-chevron-up-small");
x.classList.add("cpi-icon-chevron-down-small")
}else{x.classList.remove("cpi-icon-chevron-down-small");
x.classList.add("cpi-icon-chevron-up-small")
}}function w(z,y,x){y.classList.toggle("cpi-switcher--show");
x.setAttribute("aria-expanded",false);
u(z)
}function c(x,y){return x.getAttribute("data-cpi-switcher")===y.currentTarget.getAttribute("data-cpi-switcher")
}function e(x){return Array.prototype.slice.call(n).filter(function(y){return c(y,x)
})[0]
}function p(x){return x&&x.classList.contains("cpi-switcher--show")
}function m(){if(q){q.forEach(function(x){cpiUtils.eventHandler.removeEvent(x)
})
}q=null
}function o(){cpiUtils.forEach(n,function(x,z){var A=s(z);
var y=z.querySelector(".cpi-switcher__button");
if(p(A)){w(z,A,y)
}});
if(!h){m()
}}function f(z,y){var x=z.querySelector(".cpi-switcher__button");
l=z;
y.classList.toggle("cpi-switcher--show");
x.setAttribute("aria-expanded",true);
u(z)
}function a(x){var y=false;
cpiUtils.forEach(n,function(z,A){if(A.contains(x.target)){y=true
}});
return y
}function k(){var x=false;
cpiUtils.forEach(n,function(y,z){var A=s(z);
if(A.classList.contains("cpi-switcher--show")){l=z;
x=true
}});
return x
}function b(y){var z=document.querySelector(".cpi-menubar");
var x=z.contains(y.target);
if(x){if(k()){h=true;
r=document.activeElement;
o()
}}else{if(h){h=false;
f(l,s(l));
r.focus()
}}}function i(x){if(!a(x)){o()
}}function j(x){if(l&&!l.contains(x.target)){o()
}}function v(){q=[cpiUtils.eventHandler.addEvent(document,"keyup",j),cpiUtils.eventHandler.addEvent(document,"mousemove",b),cpiUtils.eventHandler.addEvent(document,"click",i)]
}function t(x){return Array.prototype.slice.call(n).filter(function(y){return !c(y,x)
})
}function d(){var x=t(event);
cpiUtils.forEach(x,function(y,A){var B=s(A);
var z=A.querySelector(".cpi-switcher__button");
if(B.classList.contains("cpi-switcher--show")){w(A,B,z)
}})
}function g(A){var z=e(A);
var y=s(z);
var x=z.querySelector(".cpi-switcher__button");
v();
d();
l=z;
y.classList.toggle("cpi-switcher--show");
if(p(y)){x.setAttribute("aria-expanded",true)
}else{x.setAttribute("aria-expanded",false);
if(!h){m()
}}u(z)
}if(n){cpiUtils.forEach(n,function(x,y){cpiUtils.eventHandler.addEvent(y,"click",g)
})
}})();
(function(){var j=document.getElementById("cpiAPIConfigScript");
var q=null;
var p=".cpi-modal-dialog__close-icon";
function m(u,v,s,t){u=v.description.filter(function(w){return w.countryCode?s===w.countryCode&&t===w.languageCode:w.languageCode===t
});
return u
}function d(t,s,v){var u=[];
t.forEach(function(y){var w={};
var x=[];
w.entityCode=y.entityCode;
w.countryCode=y.countryCode;
w.applicationName=y.applicationName;
w.englishCountryName=y.description[0].countryName;
x=m(x,y,s,v);
x=x.length?x:m(x,y,s,"en");
if(x.length){w.localeCountryCode=x[0].countryCode;
w.localeCountryName=x[0].countryName;
w.localelanguageCode=x[0].languageCode
}u.push(w)
});
return u
}function r(s){s.sort(function(u,t){var w=u.localeCountryName.toUpperCase();
var v=t.localeCountryName.toUpperCase();
if(w<v){return -1
}if(w>v){return 1
}return 0
})
}function b(){var s=document.getElementById("gvSwitcherWarningMessage");
s.classList.remove("cpi-switcher__list-element--hidden")
}function f(){var s=document.getElementById("gvSwitcherErrorMessage");
var t=document.getElementById("gvSwitcherLink");
s.classList.remove("cpi-switcher__list-element--hidden");
t.classList.add("cpi-switcher__list-element--hidden")
}function e(){return document.querySelector('[data-cpi-switcher="gvSwitcher"]')
}function h(A){var v=JSON.parse(A);
var u=[];
var B=j.getAttribute("data-header-locale");
var z=v;
var t=B.split("_");
var C=t[0];
var x=t[1];
var w=0;
var s=null;
var y=document.querySelector("div[data-cpi-switcher-element-prefix]");
if(z.length){u=d(z,x,C);
r(u);
q=e();
s=q.querySelector(".cpi-switcher__unordered-list");
u.forEach(function(E){var G=cpiUtils.dom.createCPIElement("li");
var I=cpiUtils.dom.createCPIElement("a",{href:"#","data-cpi-gv":E.entityCode,"class":"cpi-switcher__list-element cpi-switcher__list-element--link"});
var H=document.createTextNode(E.localeCountryName);
var F=cpiUtils.dom.createCPIElement("span",{"class":"cpi-hidden-content cpi-switcher__accessibility"});
var D=document.createTextNode(y.getAttribute("data-cpi-switcher-element-prefix"));
F.appendChild(D);
I.appendChild(F);
I.appendChild(H);
G.appendChild(I);
s.insertBefore(G,s.children[1+w]);
w++
})
}else{b()
}}function n(){f()
}function g(){e().firstElementChild.firstElementChild.focus()
}function l(){var t=document.getElementById("cpi-modal-service-error");
var s;
if(t){s=t.querySelector(p);
cpiUtils.modal.show(t,null,s,{},{},g,{},g)
}}function o(t){var u=document.createElement("form");
var s=document.createElement("input");
s.setAttribute("type","hidden");
s.setAttribute("name","SSO_TOKEN_ID");
s.setAttribute("value",t.artifactId);
u.appendChild(s);
u.setAttribute("method","POST");
u.setAttribute("action",t.launchURL);
u.setAttribute("target","_blank");
document.body.appendChild(u);
u.submit();
document.body.removeChild(u)
}function i(t){var s=JSON.parse(t);
o(s);
cpiUtils.spinner.stopModalSpinner()
}function k(){l();
cpiUtils.spinner.stopModalSpinner()
}function c(u){var t={};
var s=null;
s=j.getAttribute("data-gv-sso-token-url");
if(s){cpiUtils.spinner.startModalSpinner();
t.destEntityCode=u;
cpiUtils.modal.hide(document.getElementById("cpi-modal-redirect-country"));
cpiUtils.minimalAjax(s,i,k,{method:"POST",body:JSON.stringify(t),additionalHeaders:{"Content-Type":"application/json; charset=UTF-8"}})
}}function a(u){var t=document.getElementById("cpi-modal-redirect-country");
var s;
var v=document.querySelector("[data-cpi-redirect-country-modal-title]");
document.querySelector("[data-cpi-redirect-country-modal-title]").innerText=cpiUtils.templateReplace(v.getAttribute("data-cpi-redirect-country-modal-title"),{redirectionCountry:u.target.childNodes[1].data});
if(t){s=t.querySelector(p);
cpiUtils.modal.show(t,null,s,{},{},c.bind(null,u.target.getAttribute("data-cpi-gv")),g,g)
}}if(j){document.addEventListener("DOMContentLoaded",function(){var s=null;
var t=document.getElementsByClassName("cpi-masthead-user-menu--gv-switcher-wrapper").length;
s=j.getAttribute("data-gv-country-list-url");
if(s&&t){cpiUtils.minimalAjax(s,h,n)
}})
}q=e();
cpiUtils.eventHandler.addEvent(q,"click",function(s){if(s.target.classList.contains("cpi-switcher__list-element")){a(s)
}})
})();