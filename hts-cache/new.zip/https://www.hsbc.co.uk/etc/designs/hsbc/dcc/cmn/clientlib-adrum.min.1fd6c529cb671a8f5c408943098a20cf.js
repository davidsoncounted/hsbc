(function(){new function(){if(!window.ADRUM&&!0!==window["adrum-disable"]){var g=window.ADRUM={},x=window.console,B=x&&"function"==typeof x.log?x:{log:function(){}};
window["adrum-start-time"]=window["adrum-start-time"]||(new Date).getTime();
var v=this&&this.Zg||function(){var a=Object.Sj||{__proto__:[]} instanceof Array&&function(a,k){a.__proto__=k
}||function(a,k){for(var e in k){k.hasOwnProperty(e)&&(a[e]=k[e])
}};
return function(b,k){function e(){this.constructor=b
}a(b,k);
b.prototype=null===k?Object.create(k):(e.prototype=k.prototype,new e)
}
}();
(function(a){(function(a){a.setUpMonitors=function(){for(var a=[],b=0;
b<arguments.length;
b++){a[b]=arguments[b]
}for(b=0;
b<a.length;
b++){var d=a[b];
d&&d.setUp()
}}
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){function k(a){return b.B.slice.apply(a,b.B.slice.call(arguments,1))
}function e(a,h){return d(b.B.setTimeout.apply)?b.B.setTimeout.apply(window,arguments):b.B.setTimeout(a,h)
}function d(a){return"undefined"!==typeof a&&null!==a
}function h(a){return"object"==typeof a&&!b.isArray(a)&&null!==a
}function n(a){return"function"==typeof a||!1
}function p(a){return"string"==typeof a
}function l(a,d){for(var p in d){var n=d[p];
if(t(d,p)){var e=a[p];
h(n)&&h(e)?l(e,n):b.isArray(e)&&b.isArray(n)?a[p]=e.concat(n):a[p]=n
}}return a
}function t(a,b){return Object.prototype.hasOwnProperty.call(a,b)&&d(a[b])
}function s(a){return p(a)?a.replace(/^\s*/,"").replace(/\s*$/,""):a
}function r(){return(new Date).getTime()
}function m(a,d){var b=Array.prototype[a];
return b?g(b):q(a,d)
}function g(a){return function(d){return a.apply(d,b.B.slice.call(arguments,1))
}
}function q(a,b){return function(h,p){if(!d(h)){throw new TypeError(a+" called on null or undefined")
}if(!n(p)){throw new TypeError(p+" is not a function")
}return b.apply(null,arguments)
}
}function A(a,d,b){var h=Object(a),p=h.length>>>0,n=0;
if(3>arguments.length){for(;
n<p&&!(n in h);
){n++
}if(n>=p){throw new TypeError("Reduce of empty array with no initial value")
}b=h[n++]
}for(;
n<p;
n++){n in h&&(b=d(b,h[n],n,h))
}return b
}function u(a,d,h){return b.reduce(a,function(a,b,p,n){a[p]=d.call(h,b,p,n);
return a
},Array(a.length>>>0))
}function C(a,d,h){return b.reduce(a,function(a,b,p,n){d.call(h,b,p,n)&&a.push(b);
return a
},[])
}function w(a,d,b){a=Object(a);
for(var h=a.length>>>0,p=0;
p<h;
p++){if(p in a&&d.call(b,a[p],p,a)){return !0
}}return !1
}function z(a,d,h){return !b.some(a,function(a){return !d.call(h,a)
})
}function D(a,d,h){b.reduce(a,function(a,b,p,n){d.call(h,b,p,n)
},void 0)
}b.B={isArray:Array.isArray,toString:Object.prototype.toString,slice:Array.prototype.slice,setTimeout:window.setTimeout,setInterval:window.setInterval,assign:Object.assign};
b.Va=k;
b.oSTO=e;
b.isDefined=d;
b.isArray=n(b.B.isArray)&&n(b.B.isArray.bind)?b.B.isArray.bind(Array):function(a){return b.B.toString.call(a)===b.B.toString.call([])
};
b.isObject=h;
b.isFunction=n;
b.isString=p;
b.isNumber=function(a){return"number"==typeof a
};
b.isBoolean=function(a){return"boolean"==typeof a
};
b.max=function(a,d){return Math.max(isNaN(a)?Number.NEGATIVE_INFINITY:a,isNaN(d)?Number.NEGATIVE_INFINITY:d)
};
b.pc=e;
b.ul=function(a,d){e(a,d||10000)
};
b.addEventListener=function(d,b,h,p){function n(){try{return h.apply(this,k(arguments))
}catch(p){a.exception(p,"M1",b,d,p)
}}void 0===p&&(p=!1);
a.isDebug&&a.log("M0",b,d);
n.ba=!0;
d.addEventListener?d.addEventListener(b,n,p):d.attachEvent&&d.attachEvent("on"+b,n)
};
b.loadScriptAsync=function(d){var b=document.createElement("script");
b.type="text/javascript";
b.async=!0;
b.src=d;
var h=document.getElementsByTagName("script")[0];
h?(h.parentNode.insertBefore(b,h),a.log("M2",d)):a.log("M3",d)
};
b.mergeJSON=l;
b.hasOwnPropertyDefined=t;
b.Rd=function(a,d){if(b.isFunction(Object.getPrototypeOf)){for(;
b.isDefined(a)&&!t(a,d);
){a=Object.getPrototypeOf(a)
}}return a
};
b.uk=function(a){return d(a)?b.isArray(a)?a:[a]:[]
};
b.yl=function(a,d){return null!=a&&a.slice(0,d.length)==d
};
b.generateGUID=function(a){return d(a)&&n(a.getRandomValues)&&function(){function d(a){a=a.toString(16);
return"0000".substr(a.length)+a
}var b=new Uint16Array(8);
a.getRandomValues(b);
return d(b[0])+d(b[1])+"_"+d(b[2])+"_"+d(b[3])+"_"+d(b[4])+"_"+d(b[5])+d(b[6])+d(b[7])
}
}(window.crypto||window.msCrypto)||function(){return"xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx".replace(/[xy]/g,function(a){var d=16*Math.random()|0;
return("x"==a?d:d&3|8).toString(16)
})
};
b.tryExtractingErrorStack=function(a){return a?(a=a.stack)&&"string"===typeof a?a:null:null
};
b.trim=s;
b.sj=function(a){var d={},b,h;
if(!a){return d
}var p=a.split("\n");
for(h=0;
h<p.length;
h++){var n=p[h];
b=n.indexOf(":");
a=s(n.substr(0,b)).toLowerCase();
b=s(n.substr(b+1));
a&&(d[a]=d[a]?d[a]+(", "+b):b)
}return d
};
b.tryPeriodically=function(a,d,b,h){function p(){if(d()){b&&b()
}else{var l=a(++n);
0<l?e(p,l):h&&h()
}}var n=0;
p()
};
b.wd=function(a){return a.charAt(0).toUpperCase()+a.slice(1)
};
b.Ie=function(a){for(var d=[],b=1;
b<arguments.length;
b++){d[b-1]=arguments[b]
}return function(){for(var b=[],h=0;
h<arguments.length;
h++){b[h]=arguments[h]
}return a.apply(this,d.concat(b))
}
};
b.fl=function(){return d(performance)&&d(performance.now)
};
b.now=r;
b.Hd=function(){var a=window.performance||window.mozPerformance||window.msPerformance||window.webkitPerformance,a=b.isObject(a)&&b.isObject(a.timing)&&b.isNumber(a.timing.navigationStart)?a.timing.navigationStart:window["adrum-start-time"];
d(a)||(a=r());
return a
};
b.Sk=A;
b.reduce=m("reduce",A);
b.Rk=u;
b.map=m("map",u);
b.Pk=C;
b.filter=m("filter",C);
b.Tk=w;
b.some=m("some",w);
b.Ok=z;
b.every=m("every",z);
b.Qk=D;
b.forEach=m("forEach",D);
b.Fh=function(a){return b.filter(a,d)
};
b.vh=function(a){return[].concat.apply([],a)
}
})(a.utils||(a.utils={}))
})(g||(g={}));
(function(a){var b=a.conf||(a.conf={});
b.userConf=window["adrum-config"]||{};
b.useHTTPSAlways=!0===b.userConf.useHTTPSAlways;
b.modernBrowserFeaturesAvailable=a.utils.isDefined(window.addEventListener)&&a.utils.isDefined(window.EventTarget)&&a.utils.isDefined(window.EventTarget.prototype.addEventListener)&&a.utils.isDefined(Array.prototype.forEach);
b.spa2=b.userConf.spa&&b.userConf.spa.spa2&&(!0===b.userConf.spa.spa2||a.utils.isObject(b.userConf.spa.spa2));
b.beaconUrlHttp=a.utils.isDefined(b.userConf.beaconUrlHttp)?b.userConf.beaconUrlHttp:"http://col.eum-appdynamics.com";
b.beaconUrlHttps=a.utils.isDefined(b.userConf.beaconUrlHttps)?b.userConf.beaconUrlHttps:"https://col.eum-appdynamics.com";
b.corsEndpointPath="/eumcollector/beacons/browser"+(b.spa2?"/v2":"/v1");
b.imageEndpointPath="/eumcollector/adrum.gif?";
b.appKey=b.userConf.appKey||window["adrum-app-key"]||"APP_KEY_NOT_SET";
a=b.useHTTPSAlways||"https:"===document.location.protocol;
var k=b.userConf.adrumExtUrlHttp||"http://cdn.appdynamics.com",e=b.userConf.adrumExtUrlHttps||"https://cdn.appdynamics.com";
b.adrumExtUrl=(a?e:k)+"/adrum-ext.64575a4f0ccc435ef3de4778c280c647.js";
b.adrumXdUrl=e+"/adrum-xd.64575a4f0ccc435ef3de4778c280c647.html";
b.agentVer="4.5.1.1066";
b.sendImageBeacon=b.userConf.beacon&&b.userConf.beacon.sendImageBeacon||window["adrum-send-image-beacon"];
window["adrum-geo-resolver-url"]?(k=window["adrum-geo-resolver-url"],e=k.indexOf("://"),-1!=e&&(k=k.substring(e+3)),k=(a?"https://":"http://")+k):(k=b.userConf.geoResolverUrlHttps||"",e=b.userConf.geoResolverUrlHttp||"",k=a?k:e);
b.geoResolverUrl=k;
b.useStrictDomainCookies=!0===window["adrum-use-strict-domain-cookies"];
b.vg=10
})(g||(g={}));
(function(a){function b(d,b,h,p){d=a.conf.beaconUrlHttps+"/eumcollector/error.gif?version=1&appKey="+h+"&msg="+encodeURIComponent(d.substring(0,500));
p&&(d+="&stack=",d+=encodeURIComponent(p.substring(0,1500-d.length)));
return d
}function k(d,h){2<=g||(document.createElement("img").src=b(d,0,a.conf.appKey,h),g++)
}function e(a){return 0<=a.location.search.indexOf("ADRUM_debug=true")||0<=a.cookie.search(/(^|;)\s*ADRUM_debug=true/)
}function d(d){a.isDebug&&r.push(p(arguments).join(" | "))
}function h(a){m.push(p(arguments).join(" | "))
}function n(a){var b=p(arguments).join(" | ");
d(b);
k(b,null)
}var p=a.utils.Va,l=a.utils.reduce,t=a.utils.isDefined;
a.iDR=e;
var s;
(function(a){a[a.API_ERROR=0]="API_ERROR";
a[a.API_ERROR_INVALID_PARAMS=1]="API_ERROR_INVALID_PARAMS";
a[a.API_ERROR_INVALID_CONFIG=2]="API_ERROR_INVALID_CONFIG";
a[a.API_WARNING=3]="API_WARNING";
a[a.API_WARNING_INEFFECTIVE_CONFIG=4]="API_WARNING_INEFFECTIVE_CONFIG"
})(s=a.J||(a.J={}));
a.Na=["JS Agent API Error:","JS Agent API Error Invalid Parameters: ","JS Agent API Error Invalid Configs: ","JS Agent API Warning:","JS Agent API Warning Ineffective Config:"];
a.sa=" a constructor is called as a function. Don't forget keyword new.";
a.isDebug=e(document);
a.apiMessageConsoleOut=t(a.conf.userConf)&&t(a.conf.userConf.log)&&!0===a.conf.userConf.log.apiMessageConsoleOut?!0:!1;
var r=[],m=[];
a.logMessages=r;
a.apiMessages=m;
a.log=d;
a.ll=h;
a.error=n;
a.reportAPIMessage=function(d,b,p,n){var l=a.yj.apply(this,arguments);
h(l);
a.apiMessageConsoleOut&&B.log(l);
return l
};
a.exception=function(){if(!(1>arguments.length)){var b=p(arguments),h=a.utils.tryExtractingErrorStack(b[0]),b=b.slice(1).join(" | ");
d(b);
k(b,h)
}};
a.assert=function(a){for(var d=1;
d<arguments.length;
d++){}var b=p(arguments);
a||(d=b[1],(b=b.slice(2))&&0<b.length?n("M4",d,b):n("M5",d))
};
a.dumpLog=a.isDebug?function(){return l(r,function(a,d){return a+d.replace(/\<br\/\>/g,"\n\t")+"\n"
},"")
}:function(){};
a.yj=function(d,b,h,p){var n="",n="",l=(new window.Error).stack,e,l=a.utils.isString(l)?l.substring(5):l+"";
t(e)||(e=a.utils.map(p,function(a){return null===a?"null":void 0==a?"undefined":""===a?"''":a
}));
switch(d){case s.W:case s.Dk:n=a.Na[d];
n=t(h)?""+n+b+"\n in "+h+"("+e.join(", ")+")\n"+l:""+n+b+"\n"+l;
break;
case s.Kc:n=a.Na[d];
n=""+n+b+"\nin "+h+"("+e.join(", ")+")\n"+l;
break;
case s.Kf:case s.Lf:n=a.Na[d];
n=""+n+b+", but "+h+"="+e.join(", ")+"\n"+l;
break;
default:n=a.Na[s.W],n=""+n+b+"\nin "+h+"("+e.join(", ")+")\n"+l
}return n
};
a.cIEBU=b;
var g=0;
d("M6")
})(g||(g={}));
(function(a){var b=function(){function a(d){this.max=d;
this.Cb=0
}a.prototype.wi=function(){this.ab()||this.Cb++
};
a.prototype.ab=function(){return this.Cb>=this.max
};
a.prototype.reset=function(){this.Cb=0
};
return a
}(),k=function(){function e(){this.Ta=[];
this.uc=new b(e.Gg);
this.Zb=new b(e.zg)
}e.prototype.submit=function(d){this.push(d)&&a.initEXTDone&&this.processQ()
};
e.prototype.processQ=function(){for(var d=this.Ih(),b=0;
b<d.length;
b++){var n=d[b];
"function"===typeof a.commands[n[0]]?(a.isDebug&&a.log("M7",n[0],n.slice(1).join(", ")),a.commands[n[0]].apply(a,n.slice(1))):a.error("M8",n[0])
}};
e.prototype.Ri=function(a){return"reportXhr"===a||"reportPageError"===a
};
e.prototype.push=function(d){var b=d[0],n=this.Ri(b),p=n?this.uc:this.Zb;
if(p.ab()){return a.log("M9",n?"spontaneous":"non spontaneous",b),!1
}this.Ta.push(d);
p.wi();
return !0
};
e.prototype.Ih=function(){var a=this.Ta;
this.reset();
return a
};
e.prototype.size=function(){return this.Ta.length
};
e.prototype.reset=function(){this.Ta=[];
this.uc.reset();
this.Zb.reset()
};
e.prototype.isSpontaneousQueueDead=function(){return this.uc.ab()
};
e.prototype.isNonSpontaneousQueueDead=function(){return this.Zb.ab()
};
return e
}();
k.Gg=100;
k.zg=100;
a.CommandExecutor=k
})(g||(g={}));
(function(a){a.q=new a.CommandExecutor;
a.command=function(b){for(var k=1;
k<arguments.length;
k++){}a.isDebug&&a.log("M10",b,Array.prototype.slice.call(arguments).slice(1).join(", "));
a.q.submit(Array.prototype.slice.call(arguments))
}
})(g||(g={}));
(function(a){(function(a){var k=function(){function a(){this.status={}
}a.prototype.setUp=function(){};
a.prototype.set=function(a,b){this.status[a]=b
};
return a
}();
a.Rc=k
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){var k=a.utils.Va;
window.ADRUM.aop=b;
b.support=function(a){return !a||"apply" in a
};
b.around=function(e,d,h,n,p){a.assert(b.support(e),"M11");
e=e||function(){};
return function(){a.isDebug&&a.log("M12",n,k(arguments).join(", "));
var b=k(arguments),t;
try{d&&(t=d.apply(this,b))
}catch(s){a.exception(s,"M13",n,s)
}a.assert(!t||a.utils.isArray(t));
var r=void 0;
try{r=e.apply(this,t||b)
}catch(m){throw p&&p(m),m
}finally{try{h&&h.apply(this,b)
}catch(g){a.exception(g,"M14",n,g)
}}return r
}
};
b.before=function(a,d,h){return b.around(a,d,null,h)
};
b.after=function(a,d,h){return b.around(a,null,d,h)
}
})(a.aop||(a.aop={}))
})(g||(g={}));
(function(a){a=a.EventType||(a.EventType={});
a[a.PageView=0]="PageView";
a[a.Ajax=2]="Ajax";
a[a.VPageView=3]="VPageView";
a[a.Error=4]="Error";
a[a.IFRAME=1]="IFRAME";
a[a.ABSTRACT=100]="ABSTRACT";
a[a.ADRUM_XHR=101]="ADRUM_XHR";
a[a.NG_VIRTUAL_PAGE=102]="NG_VIRTUAL_PAGE"
})(g||(g={}));
(function(a){var b=a.events||(a.events={});
b.G={};
b.G[a.EventType.ABSTRACT]={guid:"string",url:"string",parentGUID:"string",parentUrl:"string",parentType:"number",timestamp:"number"};
b.G[a.EventType.VPageView]={resTiming:"object"};
b.G[a.EventType.NG_VIRTUAL_PAGE]={digestCount:"number"};
b.G[a.EventType.Ajax]={method:"string",parentPhase:"string",parentPhaseId:"number",error:"object",parameter:"object",xhrStatus:"number"};
b.G[a.EventType.ADRUM_XHR]={allResponseHeaders:"string"};
b.G[a.EventType.Error]={msg:"string",line:"number",stack:"string"}
})(g||(g={}));
(function(a){var b=function(){function a(){this.S={}
}a.prototype.mark=function(a,b){k.mark.apply(this,arguments)
};
a.prototype.getTiming=function(a){return(a=this.getEntryByName(a))&&a.startTime
};
a.prototype.measure=function(a,b,n){k.measure.apply(this,arguments)
};
a.prototype.getEntryByName=function(a){return k.getEntryByName.call(this,a)
};
return a
}();
b.Bb=function(a){return k.Bb(a)
};
a.PerformanceTracker=b;
var k;
(function(b){var d=a.utils.hasOwnPropertyDefined,h=window.performance||window.mozPerformance||window.msPerformance||window.webkitPerformance,n=a.utils.isObject(h)&&a.utils.isObject(h.timing)&&a.utils.isNumber(h.timing.navigationStart)?h.timing.navigationStart:window["adrum-start-time"],p=a.utils.now;
b.mark=function(b,d){this.S[b]={name:b,entryType:"mark",startTime:a.utils.isDefined(d)?d:p(),duration:0}
};
b.measure=function(b,h,e){d(this.S,h)&&d(this.S,e)?this.S[b]={name:b,entryType:"measure",startTime:h?this.S[h].startTime:n,duration:(e?this.S[e].startTime:p())-(h?this.S[h].startTime:n)}:a.error("M15",d(this.S,h)?e:h)
};
b.getEntryByName=function(a){return this.S[a]||null
};
b.Bb=function(a){return a+n
}
})(k||(k={}))
})(g||(g={}));
(function(a){(function(b){function k(b,d){b=b||{};
for(var p in b){d[p]=function(){var d=p,n=b[p];
return function(b){var h="_"+d,p=this[h];
if(a.utils.isDefined(b)){if(typeof b===n){this[h]=b
}else{throw h="wrong type of "+d+" value, "+typeof b+" passed in but should be a "+n+".",a.reportAPIMessage(a.J.Kc,h,"ADRUM.report",Array.prototype.slice.call(arguments)),TypeError(h)
}}return p
}
}()
}}function e(a){var b={},d;
for(d in a){var l=a[d];
b[l.start]=!0;
b[l.end]=!0
}return b
}var d=function(){function b(d){this.perf=new a.PerformanceTracker;
"Object"===this.constructor.name&&a.reportAPIMessage(a.J.W,a.sa);
this.timestamp(a.utils.now());
this.guid(a.utils.generateGUID());
this.url(document.URL);
this.jb(d)
}b.prototype.type=function(){return a.EventType.ABSTRACT
};
b.prototype.jb=function(b){if(a.utils.isObject(b)){for(var d in b){var h=this[d]||this["mark"+a.utils.wd(d)];
h&&a.utils.isFunction(h)&&h.call(this,b[d])
}}};
b.xb=function(a,b,d){return{guid:function(){return a
},url:function(){return b
},type:function(){return d
}}
};
b.prototype.ji=function(){return b.xb(this.parentGUID(),this.parentUrl(),this.parentType())
};
b.prototype.parent=function(b){var d=this.ji();
a.utils.isDefined(b)&&(a.utils.isFunction(b.guid)&&a.utils.isFunction(b.url)&&a.utils.isFunction(b.type)?(this.parentGUID(b.guid()),this.parentUrl(b.url()),this.parentType(b.type())):a.reportAPIMessage(a.J.W,"object is not a valid EventIdentifier","EventTracker.parent",Array.prototype.slice.call(arguments)));
return d
};
return b
}();
b.EventTracker=d;
b.la=k;
b.sd=function(b,d){b=b||{};
var p=e(b),l;
for(l in p){p=a.utils.wd(l),d["mark"+p]=a.utils.Ie(function(a,b){this.perf.mark(a,b)
},l),d["get"+p]=a.utils.Ie(function(a){return this.perf.getTiming(a)
},l)
}};
k(b.G[a.EventType.ABSTRACT],d.prototype)
})(a.events||(a.events={}))
})(g||(g={}));
(function(a){(function(b){var k=function(b){function d(h){h=b.call(this,h)||this;
h.constructor!=d&&a.reportAPIMessage(a.J.W,a.sa,"ADRUM.events.Error",[]);
return h
}v(d,b);
d.prototype.type=function(){return a.EventType.Error
};
return d
}(b.EventTracker);
b.Error=k;
b.la(b.G[a.EventType.Error],k.prototype)
})(a.events||(a.events={}))
})(g||(g={}));
(function(a){(function(b){var k=function(b){function d(){return null!==b&&b.apply(this,arguments)||this
}v(d,b);
d.prototype.setUp=function(){var d=this;
b.prototype.setUp.call(this);
a.listenForErrors=function(){d.pe()
};
this.pe()
};
d.prototype.Ej=function(){d.Jb=0
};
d.prototype.Ve=function(b,n,p,l){d.Jb>=a.conf.vg?a.log("M16"):(l=a.utils.tryExtractingErrorStack(l),a.command("reportPageError",new a.events.Error(a.utils.mergeJSON({msg:b+"",url:a.utils.isString(n)?n:void 0,line:a.utils.isNumber(p)?p:void 0,stack:l},this.status))),d.Jb++,d.hadErrors=!0)
};
d.prototype.pe=function(){var b=this;
a.aop.support(window.onerror)?(window.onerror=a.aop.around(window.onerror,function(a,p,l,e,k){d.Xb||(b.Ve(a,p,l,k),d.Xb=!0)
},function(){d.Xb=!1
},"onerror"),a.log("M17")):a.log("M18")
};
return d
}(b.Rc);
k.Xb=!1;
k.Jb=0;
k.hadErrors=!1;
b.ErrorMonitor=k;
b.ma=new b.ErrorMonitor
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){var k=function(){function b(){this.ec=this.navTiming=this.resTiming=null
}b.prototype.setUp=function(){b.perf=window.performance||window.mozPerformance||window.msPerformance||window.webkitPerformance;
a.utils.isObject(b.perf)&&a.utils.isObject(b.perf.timing)||(b.perf=void 0);
this.setResourceTimingBufferSize();
this.Qj()
};
b.prototype.setResourceTimingBufferSize=function(){var d=b.perf,h=a.conf.userConf&&a.conf.userConf.resTiming&&a.conf.userConf.resTiming.bufSize;
!a.utils.isNumber(h)||0>=h?a.log("M19"):d&&a.utils.isFunction(d.setResourceTimingBufferSize)?d.setResourceTimingBufferSize(h):a.log("M20")
};
b.prototype.Qj=function(){var d=b.perf;
a.utils.isDefined(d)&&a.utils.isFunction(d.clearResourceTimings)&&(this.ec=d.clearResourceTimings.bind(d))
};
b.prototype.xh=function(){var d=b.perf;
if(d=d&&d.timing){if(d.navigationStart&&d.navigationStart<=d.loadEventEnd){var h={},n;
for(n in d){var p=d[n];
"number"===typeof p&&(h[n]=p)
}this.navTiming=h
}else{a.log("M22")
}}else{a.log("M21")
}};
b.prototype.da=function(){this.resTiming=this.Z()
};
b.prototype.Z=function(){var d=b.perf,h=[];
d&&d.getEntriesByType&&(d=d.getEntriesByType("resource"))&&d.length&&0<d.length&&d.unshift&&(h=d);
0==h.length&&a.log("M23");
return h
};
b.prototype.clearResourceTimings=function(){a.utils.isFunction(this.ec)&&this.ec()
};
return b
}();
k.perf=null;
b.PerformanceMonitor=k;
b.perfMonitor=new b.PerformanceMonitor
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){var k=function(e){function d(){var a=e.call(this)||this;
a.resourceBuffer=[];
a.basePageResourceBuffer=[];
a.Zc=500;
a.tb=150;
a.Hj=3000;
return a
}v(d,e);
d.prototype.setUp=function(){e.prototype.setUp.call(this);
a.utils.isDefined(b.PerformanceMonitor.perf)&&a.utils.isFunction(b.PerformanceMonitor.perf.getEntriesByType)?a.utils.isFunction(b.PerformanceMonitor.perf.addEventListener)?b.PerformanceMonitor.perf.addEventListener("resourcetimingbufferfull",this.da.bind(this)):"onresourcetimingbufferfull" in b.PerformanceMonitor.perf?a.utils.isFunction(b.PerformanceMonitor.perf.dc)?b.PerformanceMonitor.perf.dc=a.aop.around(b.PerformanceMonitor.perf.dc,this.da.bind(this)):b.PerformanceMonitor.perf.dc=this.da.bind(this):a.utils.B.setInterval.call(window,this.Gj.bind(this),this.Hj):a.log("M24");
this.Vj();
this.Ij()
};
d.prototype.Vj=function(){var d=a.conf.userConf&&a.conf.userConf.resTiming&&a.conf.userConf.resTiming.bufSize;
a.utils.isDefined(b.PerformanceMonitor.perf)&&a.utils.isFunction(b.PerformanceMonitor.perf.setResourceTimingBufferSize)&&a.utils.isNumber(d)&&0<d&&(this.tb=d)
};
d.prototype.Ij=function(){var d=b.PerformanceMonitor.perf;
a.utils.isDefined(d)&&(a.utils.isFunction(d.setResourceTimingBufferSize)&&(d.setResourceTimingBufferSize=a.aop.around(d.setResourceTimingBufferSize,function(){a.utils.isDefined(arguments)&&a.utils.isDefined(arguments[0])&&(this.tb=arguments[0])
}.bind(this))),a.utils.isFunction(d.clearResourceTimings)&&(d.clearResourceTimings=a.aop.around(d.clearResourceTimings,function(){this.da()
}.bind(this))))
};
d.prototype.wh=function(){this.basePageResourceBuffer=this.Z()
};
d.prototype.da=function(){this.resourceBuffer=this.Z()
};
d.prototype.Gj=function(){e.prototype.Z.call(this).length>=this.tb&&this.da()
};
d.prototype.Z=function(){var b=e.prototype.Z.call(this);
if(this.resourceBuffer.length+b.length>this.Zc){return a.log("M25"),this.resourceBuffer.concat(b.slice(0,this.Zc-this.resourceBuffer.length))
}e.prototype.clearResourceTimings.call(this);
return this.resourceBuffer.concat(b)
};
d.prototype.li=function(b,d){return a.utils.filter(this.resourceBuffer,function(a){return b+a.startTime>=d
})
};
d.prototype.mi=function(a,b){this.resourceBuffer=this.resourceBuffer.concat(e.prototype.Z.call(this));
var d=this.li(a,b);
e.prototype.clearResourceTimings.call(this);
this.resourceBuffer=[];
return d
};
return d
}(b.PerformanceMonitor);
b.ResourceMonitor=k;
b.resourceMonitor=new b.ResourceMonitor
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){var k=function(){function e(){this.Eb=5000;
this.Fa=a.conf.userConf&&a.conf.userConf.navComplete&&a.conf.userConf.navComplete.maxResourceQuietTime?a.conf.userConf.navComplete.maxResourceQuietTime:this.Eb
}e.prototype.Tj=function(){this.Ca(Element.prototype,"innerHTML",this.Oe.bind(this));
this.Ca(HTMLElement.prototype,"innerHTML",this.Oe.bind(this));
this.Ca(HTMLImageElement.prototype,"src",this.Ga.bind(this));
this.Ca(HTMLScriptElement.prototype,"src",this.Ga.bind(this));
this.Ca(HTMLLinkElement.prototype,"href",this.Ga.bind(this));
this.zi();
this.Ub("append");
this.Ub("appendChild");
this.Ub("insertBefore")
};
e.prototype.setUp=function(a){this.$b=this.g=0;
this.na=a;
this.U=this.A=!1;
this.Ce={};
this.Ee={};
this.De={}
};
e.prototype.start=function(a){this.setUp(a);
this.U=!0
};
e.prototype.reset=function(){this.A=!1;
this.g=0;
this.U=!1
};
e.prototype.Ca=function(a,b,n){this.pj(a,b,Object.getOwnPropertyDescriptor(a,b),n)
};
e.prototype.pj=function(b,h,n,p){if(a.utils.isDefined(n)&&a.utils.isDefined(n.set)){var l=this;
Object.defineProperty(b,h,{set:function(a){var b;
try{b=n.set.apply(this,arguments)
}catch(d){throw d
}finally{p.call(l,this)
}return b
}})
}};
e.prototype.Ga=function(a){this.U&&this.ub(a)
};
e.prototype.zi=function(){var b=Element.prototype,h=this;
a.utils.isDefined(b.setAttribute)&&(b.setAttribute=a.aop.around(b.setAttribute,null,function(){h.Ga.call(h,this)
}))
};
e.prototype.Ub=function(b){var h=Element.prototype,n=this;
a.utils.isDefined(h[b])&&(h[b]=a.aop.around(h[b],null,function(){0<arguments.length&&n.Ga.call(n,arguments[0])
}))
};
e.prototype.Oe=function(b){this.U&&a.utils.isDefined(b)&&a.utils.isDefined(b.childNodes)&&(this.ub(b),this.sf(b.childNodes))
};
e.prototype.sf=function(a){for(var b=0;
b<a.length;
b++){var n=a[b];
this.ub(n);
this.sf(n.childNodes)
}};
e.prototype.ub=function(b){if(/SCRIPT|IMG|LINK/.test(b.nodeName)){var h=b.attributes.getNamedItem("src")||b.attributes.getNamedItem("href");
this.Ii(b)&&a.utils.isDefined(h)&&(h=h.value,!a.utils.isDefined(this.Ce[h])&&0<h.length&&(this.g+=1,a.utils.addEventListener(b,"load",this.qe.bind(this),!1),a.utils.addEventListener(b,"error",this.Ba.bind(this),!1),this.Ce[h]=!0))
}};
e.prototype.Ii=function(b){return"LINK"===b.nodeName?(b=b.attributes.getNamedItem("rel"),a.utils.isDefined(b)?0<=b.value.indexOf("stylesheet"):!0):!0
};
e.prototype.qe=function(d){var h=this.Zd(d.target);
!a.utils.isDefined(this.Ee[h])&&0<this.g&&(this.g-=1,this.Ee[h]=!0);
this.na=a.utils.now();
this.$b+=1;
1==this.$b&&(b.w.lf(),this.A=!0);
this.Ue(d.target)
};
e.prototype.Ba=function(b){var h=this.Zd(b.target);
a.utils.isDefined(this.De[h])||(this.g-=1,this.De[h]=!0);
this.Ue(b.target)
};
e.prototype.jh=function(){return 0<this.g&&this.A
};
e.prototype.Zd=function(a){var b="";
a instanceof HTMLScriptElement?b=a.src:a instanceof HTMLImageElement?b=a.src:a instanceof HTMLLinkElement&&(b=a.href);
return b
};
e.prototype.Rb=function(a){return 0==this.g&&this.A&&a-this.na>=this.Fa?(this.reset(),this.na):-1
};
e.prototype.Ue=function(a){a.removeEventListener("load",this.qe,!1);
a.removeEventListener("error",this.Ba,!1)
};
return e
}();
b.Wf=k
})(a.h||(a.h={}))
})(g||(g={}));
(function(a){(function(b){var k=function(){function e(){this.Eb=3000;
this.Fa=a.conf.userConf&&a.conf.userConf.navComplete&&a.conf.userConf.navComplete.maxXhrQuietTime?a.conf.userConf.navComplete.maxXhrQuietTime:this.Eb
}e.prototype.setUp=function(a){this.ac=this.g=0;
this.oa=a;
this.U=this.A=!1;
this.Ff={};
this.Jc={}
};
e.prototype.start=function(a){this.setUp(a);
this.U=!0
};
e.prototype.dh=function(b){!a.utils.isDefined(this.Ff[b])&&this.U&&(this.g+=1,this.Ff[b]=!0)
};
e.prototype.ld=function(d){this.U&&0<this.g&&(a.utils.isDefined(this.Jc)&&!a.utils.isDefined(this.Jc[d])&&(this.oa=a.utils.now(),this.g-=1,this.Jc[d]=!0),this.ac+=1,1==this.ac&&(b.w.lf(),this.A=!0))
};
e.prototype.Rb=function(a){return 0==this.g&&this.A&&a-this.oa>=this.Fa?(this.reset(),this.oa):-1
};
e.prototype.kh=function(){return 0<this.g&&this.A
};
e.prototype.reset=function(){this.A=!1;
this.g=0;
this.U=!1
};
return e
}();
b.Yg=k
})(a.h||(a.h={}))
})(g||(g={}));
var c=g.utils.Va,f=g.utils.isFunction;
(function(a){var b=a.utils.generateGUID,k=function(){return function(d,h){this.start=a.utils.now();
this.parent=d;
this.nb=h;
this.guid=b()
}
}();
a.Oc=k;
var e=function(){function b(){}b.bl=function(){return b.events
};
b.Pe=function(a,n,p,l){var e;
b.hc(n);
try{f(a)&&(e=a.apply(p,l))
}catch(k){throw k
}finally{b.qa()
}return e
};
b.qb=function(h,n,p){if(!a.utils.isDefined(n)||n.ba){return n
}var l;
p||(l=b.Ya());
return function(a){var p=b.Dd(h,a,l);
return b.Pe(n,p,this,arguments)
}
};
b.Dd=function(b,d,p){p?a.log("M26",b,p.nb.action):a.log("M27",b);
a.utils.isDefined(d)?(d=a.Qc.Zi(d.target||d.srcElement),d.action=b):d=new a.za(b);
return new k(p,d)
};
b.yk=function(h,n){if(!a.utils.isDefined(n)||n.ba){return n
}var p=b.Ya(),l=new a.za(h);
new k(p,l);
return function(){var l=new a.za(h),l=new k(p,l);
return b.Pe(n,l,this,arguments)
}
};
b.Dl=function(a,n){return function(){var p=n.apply(this,arguments);
b.ud(a);
return p
}
};
b.Ya=function(){return 0<b.events.length?b.events[b.events.length-1]:null
};
b.hc=function(a){b.events.push(a)
};
b.qa=function(){b.events.pop()
};
b.zb=function(b,d){var p=b,l=1,e="";
if(!a.utils.isDefined(p)){return null
}for(;
a.utils.isDefined(p.parent);
){e=" -> "+p.nb.action+e,p=p.parent,l+=1
}var k=a.utils.now();
a.utils.isDefined(p.nb)&&(e=p.nb.action+e+" -> "+d);
a.log("M28",e);
a.log("M29",p.start,l);
a.log("M30",k-p.start);
return p
};
b.ud=function(a){return b.zb(b.Ya(),a)
};
b.Ci=function(a){if(f(a)){return a
}var b=""+a;
return function(){eval(b)
}
};
b.setUp=function(){b.events=[];
var h=a.utils.B;
[{He:h.setTimeout,Pd:"setTimeout"},{He:h.setInterval,Pd:"setInterval"}].forEach(function(h){var p=h.He,l=h.Pd,e;
try{p.call(window),a.error("M31",l),e=l
}catch(k){e=k.message
}window[l]=function(a){var h=c(arguments);
if(1>h.length){throw TypeError(e)
}var n=b.yk(l,b.Ci(a));
h[0]=n;
return p.apply(window,h)
}
})
};
return b
}();
e.events=[];
a.k=e
})(g||(g={}));
(function(a){var b=window.addEventListener,k=a.utils.isDefined(window.EventTarget)?window.EventTarget.prototype.addEventListener:function(){},e=a.utils.isDefined(window.EventTarget)?window.EventTarget.prototype.removeEventListener:function(){},d=function(){return function(a,b,d,h,e,k,m,g){this.action=a||"";
this.dg=b||"";
this.className=d||"";
this.tagName=h||"";
this.name=e||"";
this.text=k||"";
this.src=m;
this.item=g
}
}();
a.za=d;
var h=function(){function h(){}h.setUp=function(){Array.prototype.push.apply(h.Fb,[]);
h.vk();
a.utils.isDefined(window.EventTarget)?(h.wk(),h.xk()):h.bh();
h.he("onload");
h.he("onerror")
};
h.ql=function(){return[]
};
h.Sd=function(b,d){var e="";
if(a.utils.isDefined(b)){if("string"===typeof b.textContent){e=a.utils.isDefined(String.prototype.trim)?b.textContent.trim():b.textContent,e=a.utils.isDefined(d)?e.substring(0,d):e
}else{for(b=b.firstChild;
a.utils.isDefined(b)&&!(e+=h.Sd(b,d),a.utils.isDefined(d)&&e.length>=d);
b=b.nextSibling){}}}return e
};
h.Zi=function(b){var l=b.id||"",e=b.className||"",k="",r=new d;
b===document?(k="document",r.text="#document"):b===window?(k="window",r.text="#window"):b instanceof XMLHttpRequest?(k="xhr",r.src=a.utils.isObject(b._adrumAjaxT)?b._adrumAjaxT.url():""):b instanceof WebSocket?(k="websocket",r.src=b.url):b instanceof HTMLScriptElement?(k="script",r.src=b.src):b instanceof HTMLAnchorElement?(k="a",r.text=b.text||""):b instanceof HTMLButtonElement?(k="button",r.name=b.name):b instanceof HTMLDivElement?k="div":b instanceof HTMLImageElement?(k="img",r.src=b.src,r.text=b.title||""):b instanceof HTMLLIElement?(k="li",r.item=b.value):b instanceof HTMLUListElement?k="ul":b instanceof HTMLFormElement?k="form":b instanceof HTMLFrameElement?(k="frame",r.src=b.src):b instanceof HTMLInputElement?(k=b.type||"input",r.text=b.value,r.name=b.name):b instanceof HTMLTableElement?k="table":b instanceof HTMLTableCaptionElement?k="tcap":b instanceof HTMLTableCellElement?k="td":b instanceof HTMLTableRowElement?k="tr":(k=a.utils.isDefined(b.tagName)?b.tagName:"",a.log("M32",k));
r.dg=l;
r.className=e;
r.tagName=k;
b instanceof Node&&(r.text=r.text||h.Sd(b,30)||"");
a.utils.isString(r.text)&&(r.text=a.utils.isDefined(String.prototype.trim)?r.text.trim():r.text,r.text=r.text.substring(0,30));
return r
};
h.vk=function(){a.utils.forEach(h.Fb,function(d){b(d,function(b){b=b.target||b.srcElement;
(b===document||b===window||b instanceof XMLHttpRequest||b instanceof HTMLElement)&&null!=b&&b["on"+d]&&(b["on"+d]=a.k.qb(d,b["on"+d],!0),b["on"+d].ba=!0)
},!0)
})
};
h.bh=function(){a.utils.forEach(h.Fb,function(d){b(d,function(b){b=a.k.Dd(d,b,null);
a.k.hc(b)
},!0);
b(d,function(){a.k.qa()
},!1)
})
};
h.wf=function(b){var d=!1;
a.utils.isBoolean(b)?d=b:a.utils.isObject(b)&&a.utils.isDefined(b.capture)&&(d=!!b.capture);
return d
};
h.df=function(b,d,h,n){if(!a.utils.isDefined(b.P)||!a.utils.isDefined(b.P[d])||!a.utils.isDefined(h)){return -1
}b=b.P[d];
for(d=0;
d<b.length;
d++){if(b[d][0]==h&&b[d][1]==n){return d
}}return -1
};
h.ge=function(b,d,h,n,e){a.utils.isDefined(b)&&a.utils.isDefined(e)&&(a.utils.isDefined(b.P)||(b.P={}),a.utils.isDefined(b.P[d])||(b.P[d]=[]),b.P[d].push([h,n,e]))
};
h.Bj=function(a,b,d){if(-1<d){var h=a.P[b];
delete h[d];
h.splice(d,1);
0==h.length&&delete a.P[b]
}};
h.wk=function(){EventTarget.prototype.addEventListener=function(b,d,e){if(d&&d.ba){return k.call(this,b,d,e)
}var g=h.wf(e);
if(!(-1<h.df(this,b,d,g))){var r=d;
switch(b){case"click":case"dblclick":case"auxclick":case"mousedown":case"mouseup":case"drop":case"keyup":case"keydown":case"keypress":case"contextmenu":case"pageChanged":case"scroll":case"open":case"message":case"close":r=a.k.qb(b,d,!0);
h.ge(this,b,d,g,r);
break;
case"load":case"error":r=a.k.qb(b,d,!1),h.ge(this,b,d,g,r)
}k.call(this,b,r,e)
}}
};
h.xk=function(){EventTarget.prototype.removeEventListener=function(a,b,d){if(b&&b.ba){return e.call(this,a,b,d)
}var k=h.wf(d),k=h.df(this,a,b,k);
0<=k?(e.call(this,a,this.P[a][k][2],d),h.Bj(this,a,k)):e.call(this,a,b,d)
}
};
h.he=function(b){var d=HTMLElement.prototype,h=Object.getOwnPropertyDescriptor(d,b);
a.utils.isDefined(h)&&a.utils.isDefined(h.set)&&Object.defineProperty(d,b,{set:function(d){var e=d;
a.utils.isDefined(d)&&(e=a.k.qb(b,d,!1));
var n;
try{n=h.set.call(this,e)
}catch(l){throw l
}return n
}})
};
return h
}();
h.Fb="click dblclick mousedown mouseup change scroll select submit keydown keypress keyup load unload".split(" ");
a.Qc=h
})(g||(g={}));
(function(a){(function(b){var k=a.utils.isObject,e=a.utils.map,d=a.utils.filter,h=a.utils.uk,n=a.utils.isDefined,p=a.utils.isString,l=a.utils.Fh,t=a.utils.vh,g=a.utils.isFunction;
b.xe=function(a,b){for(var d=!1,h=0;
h<b.length;
h++){var e=b[h];
if(e&&e.test(a)){d=!0;
break
}}return d
};
b.Wb=function(a,d,h){var e=!1;
if(d&&h){for(var p=0;
p<h.length;
p++){var l=h[p];
if(!(n(l.method)&&a!==l.method||n(l.urls)&&!b.xe(d,l.urls))){e=!0;
break
}}}return e
};
b.ob=function(a,p){for(var n=[],k=2;
k<arguments.length;
k++){n[k-2]=arguments[k]
}return l(e(d(t(e(l(n),function(a){return h(a[p])
})),b.Ki(p)),a))
};
b.Ec=function(a){var d=b.di(a);
a=b.Td(a);
return d||a
};
b.di=function(b){var d=b.method;
if(n(d)){if(p(d)){return b
}a.error("M33")
}};
b.pk=function(a){var d=b.Td(a);
return b.zj(a)&&d
};
b.zj=function(b){if(g(b.getFromBody)){return b
}a.error("M34")
};
b.Ki=function(b){return function(d){return k(d)||a.reportAPIMessage(a.J.Kf,"Filter object must be an object","xhr."+b,[d])
}
};
b.Bh=function(b){for(var d=[],h=0;
h<b.length;
h++){var e=b[h].pattern;
if("string"===typeof e){try{d.push(new RegExp(e))
}catch(p){a.exception(p,"M35")
}}else{a.error("M36")
}}return d
};
b.Td=function(a){var d=a.urls;
if(d&&0<d.length&&(a.urls=b.Bh(d),0<a.urls.length)){return a
}}
})(a.utils||(a.utils={}))
})(g||(g={}));
(function(a){(function(b){b.parseURI=function(a){var b=String(a).replace(/^\s+|\s+$/g,"").match(/^([^:\/?#]+:)?(?:\/\/(?:([^:@\/?#]*)(?::([^:@\/?#]*))?@)?(([^:\/?#]*)(?::(\d*))?))?([^?#]*)(\?[^#]*)?(#[\s\S]*)?/);
a=b&&null!=a.match(b[1]+"//");
return b&&{href:b[0]||"",protocol:b[1]||"",slash:a?"//":"",username:b[2]||"",password:b[3]||"",host:b[4]||"",hostname:b[5]||"",port:b[6]||"",pathname:b[7]||"",search:b[8]||"",hash:b[9]||""}
};
b.absolutizeURI=function(a,e){function d(a){var b=[];
a.replace(/^(\.\.?(\/|$))+/,"").replace(/\/(\.(\/|$))+/g,"/").replace(/\/\.\.$/,"/../").replace(/\/?[^\/]*/g,function(a){"/.."===a?b.pop():b.push(a)
});
return b.join("").replace(/^\//,"/"===a.charAt(0)?"/":"")
}var h,n,p,l,t,g,r,m;
m=e?b.parseURI(e):{};
r=a?b.parseURI(a):{};
m.protocol?(h=m.protocol,n=m.slash,p=m.username,l=m.password,t=m.host,g=d(m.pathname),r=m.search):m.host?(h=r.protocol,n=r.slash,p=m.username,l=m.password,t=m.host,g=d(m.pathname),r=m.search):(h=r.protocol,n=r.slash,p=r.username,l=r.password,t=r.host,m.pathname?("/"===m.pathname.charAt(0)?g=d(m.pathname):(g=r.pathname?r.pathname.slice(0,r.pathname.lastIndexOf("/")+1)+m.pathname:n?"/"+m.pathname:m.pathname,g=d(g)),r=m.search):(g=d(r.pathname),r=m.search||r.search));
return h+n+(p?p+(l?":"+l:"")+"@":"")+t+g+r+(m.hash?m.hash:"")
};
b.getFullyQualifiedUrl=function(k){try{var e,d=document.location.href,h;
a:{for(var n=document.getElementsByTagName("base"),p=0;
p<n.length;
p++){var l=n[p].href;
if(l){h=l;
break a
}}h=void 0
}e=h?b.absolutizeURI(d,h):d;
return b.absolutizeURI(e,k)
}catch(t){return a.exception(t,"M37",k,e),k
}}
})(a.utils||(a.utils={}))
})(g||(g={}));
(function(a){var b=function(){function b(){this.mb=[];
this.gb(b.vb,0)
}b.prototype.hj=function(a){this.gb(b.md,a)
};
b.prototype.jj=function(a){this.gb(b.td,a)
};
b.prototype.ij=function(a){this.gb(b.od,a)
};
b.prototype.gb=function(a,b){this.mb.push({gj:(new Date).getTime(),fj:b,Je:a});
this.Ch=a
};
b.prototype.getPhaseName=function(){return this.Ch
};
b.prototype.getPhaseID=function(a){for(var d=0;
d<b.rd.length;
d++){if(b.rd[d]===a){return d
}}return null
};
b.prototype.getPhaseCallbackTime=function(a){for(var b=this.mb,h=0;
h<b.length;
h++){if(b[h].Je===a){return b[h].gj
}}return null
};
b.prototype.findPhaseAtNominalTime=function(e){a.assert(0<=e);
for(var d=this.mb,h=d.length-1;
0<=h;
h--){if(e>=d[h].fj){return d[h].Je
}}a.error("M38",e,a.utils.dumpObject(d));
return b.vb
};
return b
}();
b.vb="AFTER_FIRST_BYTE";
b.md="AFTER_DOM_INTERACTIVE";
b.td="AT_ONLOAD";
b.od="AFTER_ONLOAD";
b.rd=[b.vb,b.md,b.td,b.od];
a.PageLifecycleTracker=b;
a.lifecycle=new b;
a.lifecycle=a.lifecycle
})(g||(g={}));
(function(a){a=a.events||(a.events={});
a=a.b||(a.b={});
a.navigationStart="navigationStart";
a.domainLookupStart="domainLookupStart";
a.domainLookupEnd="domainLookupEnd";
a.connectStart="connectStart";
a.secureConnectionStart="secureConnectionStart";
a.connectEnd="connectEnd";
a.requestStart="requestStart";
a.responseStart="responseStart";
a.responseEnd="responseEnd";
a.domContentLoadedEventStart="domContentLoadedEventStart";
a.loadEventEnd="loadEventEnd";
a.ef="sendTime";
a.Nd="firstByteTime";
a.$e="respAvailTime";
a.af="respProcTime";
a.Fc="viewChangeStart";
a.yf="viewChangeEnd";
a.Gc="viewDOMLoaded";
a.Ef="xhrRequestsCompleted";
a.Bl="viewFragmentsLoaded";
a.Cl="viewResourcesLoaded";
a.Hc="virtualPageStart";
a.rk="virtualPageEnd"
})(g||(g={}));
(function(a){var b=a.events||(a.events={});
b.metricSpec={};
b.metricSpec[a.EventType.PageView]={Nh:{start:b.b.navigationStart,end:b.b.loadEventEnd,name:"PLT"},Uh:{start:b.b.navigationStart,end:b.b.responseStart,name:"FBT"},wl:{start:b.b.navigationStart,end:b.b.requestStart,name:"SCT"},xl:{start:b.b.secureConnectionStart,end:b.b.connectEnd,name:"SHT"},Zk:{start:b.b.domainLookupStart,end:b.b.domainLookupEnd,name:"DLT"},Al:{start:b.b.connectStart,end:b.b.connectEnd,name:"TCP"},tl:{start:b.b.requestStart,end:b.b.responseStart,name:"RAT"},al:{start:b.b.responseStart,end:b.b.loadEventEnd,name:"FET"},dl:{start:b.b.responseStart,end:b.b.domContentLoadedEventStart,name:"DRT"},cl:{start:b.b.responseStart,end:b.b.responseEnd,name:"DDT"},Xk:{start:b.b.responseEnd,end:b.b.domContentLoadedEventStart,name:"DPT"},sl:{start:b.b.domContentLoadedEventStart,end:b.b.loadEventEnd,name:"PRT"},Yk:{start:b.b.navigationStart,end:b.b.domContentLoadedEventStart,name:"DOM"}};
b.metricSpec[a.EventType.Ajax]={Uh:{start:b.b.ef,end:b.b.Nd,name:"FBT"},Nk:{start:b.b.Nd,end:b.b.$e,name:"DDT"},Mk:{start:b.b.$e,end:b.b.af,name:"DPT"},Nh:{start:b.b.ef,end:b.b.af,name:"PLT"}};
b.metricSpec[a.EventType.VPageView]={kl:{start:b.b.Hc,end:b.b.rk,name:"PLT"},Vk:{start:b.b.Fc,end:b.b.yf,name:"DDT"},hl:{start:b.b.Fc,end:b.b.Gc,name:"DRT"},Fk:{start:b.b.yf,end:b.b.Gc,name:"DPT"},Gk:{start:b.b.Fc,end:b.b.Gc,name:"DOM"},rl:{start:"viewChangeEnd",end:"xhrRequestsCompleted",name:null},il:{start:"viewChangeEnd",end:"viewPartialsLoaded",name:null},gl:{start:"viewPartialsLoaded",end:"viewFragmentsLoaded",name:null},jl:{start:"viewPartialsLoaded",end:"viewResourcesLoaded",name:null}};
b.metricSpec[a.EventType.NG_VIRTUAL_PAGE]=b.metricSpec[a.EventType.VPageView]
})(g||(g={}));
(function(a){(function(b){var k=function(e){function d(h){h=e.call(this,h)||this;
h.constructor!=d&&h.constructor!=b.AdrumAjax&&a.reportAPIMessage(a.J.W,a.sa,"ADRUM.events.Ajax",[]);
return h
}v(d,e);
d.prototype.type=function(){return a.EventType.Ajax
};
return d
}(b.EventTracker);
b.Ajax=k;
b.la(b.G[a.EventType.Ajax],k.prototype);
b.sd(b.metricSpec[a.EventType.Ajax],k.prototype)
})(a.events||(a.events={}))
})(g||(g={}));
(function(a){(function(b){var k=function(b){function d(a){return b.call(this,a)||this
}v(d,b);
d.prototype.type=function(){return a.EventType.Ajax
};
return d
}(b.Ajax);
b.AdrumAjax=k;
b.la(b.G[a.EventType.ADRUM_XHR],k.prototype)
})(a.events||(a.events={}))
})(g||(g={}));
(function(a){(function(b){var k=a.utils.isObject,e=a.utils.map,d=a.utils.reduce,h=a.utils.filter,n=a.utils.isDefined,p=a.utils.isString,l=a.utils.mergeJSON,t=a.utils.Va,g=a.utils.now,r=a.utils.pc,m=function(m){function q(){var b=m.call(this)||this;
b.conf=null;
b.yc=!1;
b.wb=0;
if(!0===window["adrum-xhr-disable"]){return a.log("M39"),b
}if(!window.XMLHttpRequest){return a.log("M40"),b
}b.conf={exclude:[{urls:[{pattern:a.conf.beaconUrlHttp+a.conf.corsEndpointPath},{pattern:a.conf.beaconUrlHttps+a.conf.corsEndpointPath}]}],include:[],maxPerPageView:q.Pc};
q.Ne(b.conf,a.conf.userConf&&a.conf.userConf.xhr);
b.l=window.XMLHttpRequest.prototype;
if(!b.l){return a.log("M41"),b
}if(!("open" in b.l&&"send" in b.l)){return a.log("M42"),b
}b.yc=a.aop.support(b.l.open)&&a.aop.support(b.l.send);
b.yc||a.log("M43");
return b
}v(q,m);
q.Ne=function(b,d){var h=q.Pc;
if(d){var p=d.maxPerPageView;
a.utils.isNumber(p)&&0<p?h=p:a.reportAPIMessage(a.J.Lf,"value is not valid; don't limit xhr","xhr.maxPerPageView",[p])
}b.maxPerPageView=h;
b.exclude=a.utils.ob(a.utils.Ec,"exclude",b,d);
b.include=a.utils.ob(a.utils.Ec,"include",b,d);
b.parameter=a.utils.ob(a.utils.pk,"parameter",d)
};
q.jf=function(b,d,h){var p=d&&d.include;
d=d&&d.exclude;
return n(p)&&0<p.length&&!a.utils.Wb(h,b,p)||n(d)&&0<d.length&&a.utils.Wb(h,b,d)
};
q.Ba=function(b){var d=b.message||b.description,h=b.fileName||b.filename,n=b.lineNumber;
p(b.description)&&0<=b.description.indexOf("Access is denied.")&&(d+=": maybe you have CORS XHR error in IE");
a.monitor.ma.Ve(d,h,n,b)
};
q.prototype.setUp=function(){if(this.yc){a.log("M44");
a.xhrConstructor=window.XMLHttpRequest;
a.xhrOpen=this.xhrOpen=this.l.open;
a.xhrSend=this.xhrSend=this.l.send;
var b=this;
this.l.open=a.aop.around(this.l.open,function(){q.Oi(this)&&(4===this.readyState?(a.log("M45"),q.Oh(this._adrumAjaxT),delete this.kd,q.reportXhr(this,this._adrumAjaxT)):a.log("M46",this._adrumAjaxT.url()));
var d=1<=arguments.length?String(arguments[0]):"",h=2<=arguments.length?String(arguments[1]):"",h=a.utils.getFullyQualifiedUrl(h);
b.wb>=b.conf.maxPerPageView||q.jf(h,b.conf,d)||(this._adrumAjaxT=new a.events.AdrumAjax(l({method:d,url:h},b.status)))
},null,"XHR.open",q.Ba);
this.l.send=a.aop.around(this.l.send,function(h){var p=this,n=this._adrumAjaxT,e=!1;
if(n&&!(++b.wb>b.conf.maxPerPageView)){var l=a.utils.now(),k=n.getSendTime();
a.assert(null===k,"M47");
n.timestamp(l);
n.markSendTime(k||l);
n.parentPhase(a.lifecycle.getPhaseName());
a.conf.spa2&&(p.Sa=new a.Oc(a.k.Ya(),new a.za("XHR.send")));
q.Pi(n.url())?p.setRequestHeader("ADRUM","isAjax:true"):a.log("M48",document.location.href,n.url());
h=q.ii(n.url(),b.conf.parameter,h);
n.parameter(h);
var g=0,t=function(){if(4==p.readyState){e?a.log("M49"):(a.log("M50"),b.pb(p))
}else{var h=null;
try{h=p.onreadystatechange
}catch(n){if(e){a.log("M51",n);
return
}a.log("M52",n);
b.pb(p);
return
}g++;
h?a.aop.support(h)?(p.onreadystatechange=q.Fd(h,"XHR.onReadyStateChange"),a.log("M53",g)):d||(a.log("M54"),b.pb(p)):g<q.Wg?r(t):e?a.log("M55"):(a.log("M56"),b.pb(p))
}};
if(d){a.log("M57");
try{b.Ak.call(p,"readystatechange",q.Gh),e=!0
}catch(m){a.error("M58",m)
}}t()
}},function(){if(a.conf.spa2){var b=this._adrumAjaxT;
b&&a.h.w.I.dh(b.url())
}},"XHR.send",q.Ba);
var d="addEventListener" in this.l&&"removeEventListener" in this.l&&a.aop.support(this.l.addEventListener)&&a.aop.support(this.l.removeEventListener);
if(d){var h=a.utils.Rd(this.l,"addEventListener");
this.Ak=h.addEventListener;
h.addEventListener=a.aop.around(h.addEventListener,function(b,d,h){if(n(d)&&(d.ba=!0,this instanceof XMLHttpRequest&&/^(load|error|readystatechange)$/.test(b)&&d)){var p=q.mk(d);
if(p){var e=t(arguments);
e[1]=p;
a.log("M59");
return e
}a.log("M60",b,d)
}},null,"XHR.addEventListener");
h=a.utils.Rd(this.l,"removeEventListener");
this.Ck=h.removeEventListener;
h.removeEventListener=a.aop.around(h.removeEventListener,function(d,h,p){if(this instanceof XMLHttpRequest&&this._adrumAjaxT){var n=t(arguments);
h.__adrumInterceptor?(n[1]=h.__adrumInterceptor,a.log("M61"),b.Ck.apply(this,n)):a.log("M62")
}},null,"XHR.removeEventListener")
}else{a.log("M63")
}a.log("M64")
}};
q.prototype.nc=function(){this.wb=0
};
q.Te=function(a){q.T[a]=[];
delete q.T[a]
};
q.jc=function(b,d){if(n(d.Sa)){var h=a.k.zb(d.Sa).guid;
q.uf(d,b);
n(q.T[h])||(q.T[h]=[]);
-1==q.T[h].indexOf(b)&&q.T[h].push(b)
}else{a.log("~AnySPA: error in putInParentEventWaitingQueue() as xhr._xhrEvent is undefined.")
}};
q.aj=function(b,d){var h=q.T[d];
n(h)&&(h.forEach(function(d){d.parent(b);
a.command("reportXhr",d);
a.k.qa()
}),q.Te(d))
};
q.Cj=function(){for(var b in q.T){q.T[b].forEach(function(b){a.command("reportXhr",b);
a.k.qa()
}),q.Te(b)
}};
q.tj=function(a,b,d){return(b||a)===(d||a)
};
q.Pi=function(a){var b=document.createElement("a");
b.href=a;
a=document.location;
var d=a.protocol;
return b.protocol===d&&b.hostname===a.hostname&&q.tj(q.Eh[d],b.port,a.port)
};
q.ii=function(b,p,n){if(p&&(p=h(e(h(p,function(d){return a.utils.xe(b,d.urls)
}),function(a){return a.getFromBody(n)
}),k),0<p.length)){return d(p,l,{})
}};
q.Qb=function(b){var d=b._adrumAjaxT;
if(d){var h=a.utils.now();
2==b.readyState?d.markFirstByteTime(d.getFirstByteTime()||h):4==b.readyState&&(d.markRespAvailTime(d.getRespAvailTime()||h),d.markFirstByteTime(d.getFirstByteTime()||h),a.conf.spa2&&(b=new a.Oc(b.Sa,new a.za("XHR.load")),a.k.hc(b)))
}};
q.$d=function(b){var d=b._adrumAjaxT;
if(d&&4==b.readyState){var h=g(),p=d.getRespProcTime();
d.markRespAvailTime(d.getRespAvailTime()||h);
h>p&&d.markRespProcTime(h);
a.conf.spa2?q.yh(b,d):q.qc(b,d)
}};
q.Fd=function(a,b){return q.Bk(a,function(){q.Qb(this)
},function(){q.$d(this)
},b)
};
q.Gh=function(){q.Qb(this);
q.$d(this)
};
q.Oi=function(a){return n(a._adrumAjaxT)&&p(a._adrumAjaxT._url)
};
q.Oh=function(b){var d=a.utils.now();
b.markRespAvailTime(b.getRespAvailTime()||d);
b.markFirstByteTime(b.getFirstByteTime()||d);
b.markRespProcTime(b.getRespProcTime()||d)
};
q.qc=function(a,b){var d={};
a.kd=d;
delete a._adrumAjaxT;
r(function(){a.kd===d&&q.reportXhr(a,b)
})
};
q.yh=function(d,h){var p=a.k.zb(d.Sa);
n(b.AnySpaMonitor.vp)&&!b.AnySpaMonitor.fa&&b.AnySpaMonitor.vp.Ab==p?(h.parent(b.AnySpaMonitor.vp),q.qc(d,h),a.k.qa()):(n(b.AnySpaMonitor.vp)&&!b.AnySpaMonitor.fa&&h.parent(b.AnySpaMonitor.vp),q.jc(h,d),a.utils.oSTO(q.Cj,q.cd));
delete d._adrumAjaxT;
a.h.w.I.ld(h.url())
};
q.uf=function(a,b){var d=a.status,h;
b.xhrStatus(d);
b.allResponseHeaders(a.getAllResponseHeaders());
if(400<=d){try{p(a.responseText)&&(h=a.responseText)
}catch(n){p(a.responseType)&&(h=a.responseType)
}b.error({status:d,msg:h})
}};
q.reportXhr=function(b,d){q.uf(b,d);
a.command("reportXhr",d)
};
q.prototype.pb=function(b){if(b._adrumAjaxT){var d=a.utils.now()+30000,h=function(){q.Qb(b);
var p=b._adrumAjaxT;
if(p){var n=a.utils.now();
4==b.readyState?(a.assert(null===p.getRespProcTime(),"M65"),p.markRespProcTime(p.getRespProcTime()||n),a.log("M66"),q.qc(b,p),a.conf.spa2&&(a.k.qa(),a.h.w.I.ld(p.url()))):n<d?a.utils.oSTO(h,q.cd):(delete b._adrumAjaxT,a.log("M67"))
}};
h()
}};
q.Bk=function(b,d,h,p){var n=b;
b&&"object"===typeof b&&"toString" in b&&"[xpconnect wrapped nsIDOMEventListener]"===b.toString()&&"handleEvent" in b&&(n=function(){b.handleEvent.apply(this,t(arguments))
});
return a.aop.around(n,d,h,p)
};
q.mk=function(b){if(b.__adrumInterceptor){return b.__adrumInterceptor
}if(a.aop.support(b)){var d=q.Fd(b,"XHR.invokeEventListener");
return b.__adrumInterceptor=d
}};
return q
}(b.Rc);
m.Wg=5;
m.Vf=50;
m.Pc=50;
m.cd=2000;
m.T={};
m.Eh={"http:":"80","https:":"443"};
b.XHRMonitor=m;
b.xhrMonitor=new b.XHRMonitor
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){var k=function(e){function d(b){b=e.call(this,b)||this;
b.perf=new a.PerformanceTracker;
a.monitor.xhrMonitor.nc();
b.Gd=!1;
return b
}v(d,e);
d.prototype.type=function(){return a.EventType.VPageView
};
d.prototype.Mb=function(){return b.EventTracker.xb(this.guid(),this.url(),this.type())
};
d.prototype.vc=function(){var b=this.Mb();
a.monitor.ma.set("parent",b);
a.log("M68",b.guid(),b.url())
};
d.prototype.startCorrelatingXhrs=function(){a.log("M69");
a.utils.isDefined(this.Ab)&&!a.monitor.AnySpaMonitor.fa&&a.monitor.XHRMonitor.aj(this,this.Ab.guid)
};
d.prototype.start=function(){this.startCorrelatingXhrs();
this.vc()
};
return d
}(b.EventTracker);
b.AnySpaVPageView=k;
b.la(b.G[a.EventType.VPageView],k.prototype)
})(a.events||(a.events={}))
})(g||(g={}));
(function(a){a.report=function(b){a.utils.isObject(b)&&a.utils.isFunction(b.type)?-1==[a.EventType.PageView,a.EventType.Ajax,a.EventType.VPageView,a.EventType.Error].indexOf(b.type())?a.reportAPIMessage(a.J.W,b.type()+"is not a valid external event type","ADRUM.report",Array.prototype.slice.call(arguments)):a.conf.spa2&&a.EventType.VPageView==b.type()?a.log("M70"):a.utils.pc(function(){a.command("reportEvent",b)
}):a.reportAPIMessage(a.J.Kc,"","ADRUM.report",Array.prototype.slice.call(arguments))
};
a.markVirtualPageBegin=function(b,k){a.conf.spa2&&(this.Sb=a.utils.isDefined(k)?k:!0,a.log("M71",document.URL),a.monitor.AnySpaMonitor.kb(document.URL,b,!0),a.monitor.AnySpaMonitor.tc(document.URL))
};
a.markVirtualPageEnd=function(){a.conf.spa2&&this.Sb&&(a.log("M72",a.monitor.AnySpaMonitor.V),a.monitor.AnySpaMonitor.ue(a.monitor.AnySpaMonitor.vp.startTime,a.utils.now()),this.Sb=!1)
}
})(g||(g={}));
(function(a){(function(b){var k=a.utils.isDefined,e=function(){function d(){}d.prototype.setUp=function(){var h=!1;
d.ke=!1;
d.lh=a.utils.Hd();
a.k.setUp();
a.Qc.setUp();
b.resourceMonitor.setUp();
a.h.w.setUp(a.utils.now());
d.V=document.URL;
d.conf={exclude:[]};
a.utils.isDefined(window.history)&&a.utils.isFunction(window.history.pushState)&&(h=!0,window.history.pushState=a.aop.around(window.history.pushState,function(){b.DOMEventsMonitor.Ea&&(a.log("M73"),d.kb(document.URL))
},function(){b.DOMEventsMonitor.Ea&&(a.log("M74"),d.tc(document.URL));
d.V=document.URL
},"historyPushState"));
d.conf.exclude=a.utils.ob(a.utils.Ec,"exclude",d.conf,a.conf.userConf&&a.conf.userConf.spa&&a.conf.userConf.spa.spa2&&a.utils.isObject(a.conf.userConf.spa.spa2)&&a.conf.userConf.spa.spa2.vp);
if(a.utils.isDefined(window.addEventListener)){var h=!0,n=function(h){d.ke=!0;
var n=document.URL;
a.log("M75",h);
b.DOMEventsMonitor.Ea&&(d.kb(d.V),d.wc(n));
d.V=n
};
n.ba=!0;
window.addEventListener("popstate",n)
}a.utils.isDefined(window.addEventListener)&&(h=!0,n=function(){if(!d.ke){var h=document.URL;
a.log("M76",d.V,h);
b.DOMEventsMonitor.Ea&&(d.kb(d.V),d.tc(h));
d.V=h
}},n.ba=!0,window.addEventListener("hashchange",n));
h||a.log("M77")
};
d.kb=function(a,b,p){d.Nj();
d.fa=!1;
d.Ed(a,b,p)
};
d.tc=function(a){d.wc(a);
d.V=a
};
d.zh=function(){d.fa=!0;
d.Ed(d.V);
d.wc()
};
d.Nj=function(){if(!d.fa&&a.utils.isDefined(d.vp)&&!d.vp.We){var b=d.ai(a.h.w.A);
d.ue(d.vp.startTime,b)
}};
d.ai=function(b){var n=a.utils.now();
b?(n=d.bi(a.h.w.Da),a.h.w.reset()):n=d.vp.timestamp();
return n
};
d.Xj=function(b,n){if(d.vp.Gd){return !1
}var p=n&&n.exclude;
return k(p)&&0<p.length&&a.utils.Wb(void 0,b,p)
};
d.bi=function(b){var d=a.utils.now();
b?a.h.w.L.jh()||a.h.w.I.kh()||(d=a.utils.max(a.h.w.L.na,a.h.w.I.oa)):d=a.h.w.startTime;
return d
};
d.ue=function(a,b){d.ve(a,b);
d.te(a);
d.report()
};
d.Ed=function(b,n,p){d.reset();
d.vp=new a.events.AnySpaVPageView;
d.vp.startUrl=b;
a.utils.isDefined(n)&&(d.vp.userPageName=n);
a.utils.isBoolean(p)&&(d.vp.Gd=p);
b=a.k.ud();
d.vp.startTime=d.fa?a.utils.Hd():a.utils.isDefined(b)?b.start:a.utils.now();
d.vp.Ab=b
};
d.wc=function(b){a.utils.isDefined(b)&&d.vp.url(b);
d.vp.start();
a.Sb||a.h.w.start(a.utils.now())
};
d.ve=function(b,n){a.utils.isDefined(d.vp)&&(a.utils.isDefined(n)?d.vp.timestamp(n):d.vp.timestamp(b))
};
d.te=function(h){a.utils.isDefined(d.vp)&&d.vp.resTiming(b.resourceMonitor.mi(d.lh,h))
};
d.report=function(){if(a.utils.isDefined(d.vp)){if(d.Xj(d.vp.url(),d.conf)){a.log("M79",d.vp.url())
}else{a.log("M80");
var h=d.vp;
h.We?a.log("M81"):(h.parent(b.DOMEventsMonitor.currentBasePage),a.command("call",function(){a.reporter.reportEvent(h)
}),h.We=!0)
}}else{a.log("M78")
}};
d.reset=function(){d.vp=null
};
return d
}();
e.conf=null;
b.AnySpaMonitor=e;
b.ih=new b.AnySpaMonitor
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){var k=function(){function e(){this.L=new b.Wf;
this.I=new b.Yg;
this.dj=3000;
this.maxInactiveTime=a.conf.userConf&&a.conf.userConf.navComplete&&a.conf.userConf.navComplete.maxInactiveTime?a.conf.userConf.navComplete.maxInactiveTime:Math.max(this.L.Fa,this.I.Fa)+this.dj;
this.Me=1000
}e.prototype.setUp=function(a){this.currentTime=this.startTime=a;
this.A=this.Da=!1;
this.L.setUp(a);
this.I.setUp(a)
};
e.prototype.start=function(a){this.setUp(a);
this.A=!0;
this.L.start(a);
this.I.start(a);
this.yd();
this.ak()
};
e.prototype.ak=function(){this.rf=a.utils.B.setInterval.call(window,function(){this.currentTime=a.utils.now();
var b=a.utils.max(this.L.na,this.I.oa);
this.currentTime-b>=this.maxInactiveTime&&(this.navComplete(this.Da?this.currentTime:b),this.reset())
}.bind(this),this.Me)
};
e.prototype.lf=function(){this.Da||(this.Zj(),this.Da=!0)
};
e.prototype.yd=function(){a.utils.isDefined(this.Qe)&&clearInterval(this.Qe);
a.utils.isDefined(this.rf)&&clearInterval(this.rf)
};
e.prototype.reset=function(){this.yd();
this.A=this.Da=!1;
this.L.reset();
this.I.reset()
};
e.prototype.navComplete=function(b){var h=a.utils.isDefined(a.monitor.AnySpaMonitor.vp&&a.monitor.AnySpaMonitor.vp.startTime)?a.monitor.AnySpaMonitor.vp.startTime:this.startTime;
a.log("M82",b-h);
a.monitor.AnySpaMonitor.ve(h,b);
a.monitor.AnySpaMonitor.fa||(a.monitor.AnySpaMonitor.te(h),a.monitor.AnySpaMonitor.report())
};
e.prototype.Zj=function(){this.Qe=a.utils.B.setInterval.call(window,function(){this.currentTime=a.utils.now();
var b=this.L.Rb(this.currentTime);
0<=b&&a.log("M83",b-this.startTime);
b=this.I.Rb(this.currentTime);
0<=b&&a.log("M84",b-this.startTime);
this.I.A||this.L.A||(this.navComplete(a.utils.max(this.I.oa,this.L.na)),this.reset())
}.bind(this),this.Me)
};
return e
}();
b.Ig=k;
b.w=new b.Ig
})(a.h||(a.h={}))
})(g||(g={}));
(function(a){(function(b){var k=function(b){function d(){return null!==b&&b.apply(this,arguments)||this
}v(d,b);
d.prototype.type=function(){return a.EventType.PageView
};
return d
}(b.EventTracker);
b.PageView=k
})(a.events||(a.events={}))
})(g||(g={}));
(function(a){(function(b){var k=a.utils.now,e=function(){function d(){}d.prototype.setUp=function(){var b=document.readyState;
if("loading"===b){a.log("M85"),d.Uj(),d.hf()
}else{var n={timeStamp:k()};
d.ua(n);
"interactive"===b?(a.log("M86"),d.hf()):(a.log("M87"),d.Ha(n),d.Ge(n))
}};
d.hf=function(){a.utils.addEventListener(window,"load",d.Ha);
a.utils.addEventListener(window,"load",d.Ge)
};
d.Ge=function(h){d.currentBasePage=new a.events.PageView;
a.lifecycle.jj(h&&h.timeStamp);
a.utils.pc(function(){var h=k();
a.lifecycle.ij(h);
a.command("mark","onload",h);
d.Ea=!0;
b.PerformanceMonitor.perf&&b.perfMonitor.xh();
a.conf.spa2?b.resourceMonitor.wh():b.perfMonitor.da();
a.command("reportOnload",d.currentBasePage);
a.conf.spa2&&(a.h.w.L.Tj(),b.AnySpaMonitor.zh());
a.utils.loadScriptAsync(a.conf.adrumExtUrl)
});
a.log("M88")
};
d.Uj=function(){if(a.utils.isFunction(document.addEventListener)){document.addEventListener("DOMContentLoaded",d.ua,!1)
}else{if(a.utils.isObject(document.attachEvent)){document.attachEvent("onreadystatechange",d.ua);
var b=null;
try{b=null===window.frameElement?document.documentElement:null
}catch(n){}null!=b&&b.doScroll&&function l(){if(!d.isReady){try{b.doScroll("left")
}catch(n){a.utils.oSTO(l,10);
return
}d.Ha()
}}()
}else{a.exception("M89")
}}a.log("M90")
};
d.Ha=function(b){d.we||(a.lifecycle.hj(b&&b.timeStamp),a.command("mark","onready",k()),d.we=!0)
};
d.ua=function(a){document.addEventListener?(document.removeEventListener("DOMContentLoaded",d.ua,!1),d.Ha(a)):"complete"===document.readyState&&(document.detachEvent("onreadystatechange",d.ua),d.Ha(a))
};
return d
}();
e.isReady=!1;
e.we=!1;
e.Ea=!1;
b.DOMEventsMonitor=e;
b.domEventsMonitor=new b.DOMEventsMonitor
})(a.monitor||(a.monitor={}))
})(g||(g={}));
(function(a){(function(b){function k(a,b){var d=[],e=/^\s*(ADRUM_BT\w*)=(.*)\s*$/i.exec(a);
if(e){var k=e[1],e=e[2].replace(/^"|"$/g,""),e=decodeURIComponent(e).split("|"),g=e[0].split(":");
if("R"===g[0]&&Number(g[1])===b){for(h(k),k=1;
k<e.length;
k++){d.push(e[k])
}}}return d
}function e(a,b){var d=/^\s*(ADRUM_(\d+)_(\d+)_(\d+))=(.*)\s*$/i.exec(a);
if(d){var e=d[1],k=d[4],g=d[5];
if(Number(d[3])===b){return h(e),{index:Number(k),value:g}
}}return null
}function d(b){var d=/^\s*ADRUM=s=([\d]+)&r=(.*)\s*/.exec(b);
if(d){a.log("M93",b);
if(3===d.length){return h("ADRUM"),{startTime:Number(d[1]),startPage:d[2]}
}a.error("M94",b);
return null
}}function h(b){a.log("M92",b);
var d=new Date;
d.setTime(d.getTime()-1000);
document.cookie=b+"=;Expires="+d.toUTCString()
}b.startTimeCookie=null;
b.cookieMetadataChunks=null;
b.Jd=function(h,p){a.log("M91");
for(var l=p?p.length:0,g=[],s=h.split(";"),r=0;
r<s.length;
r++){var m=s[r],y=e(m,l);
y?g.push(y):(m=d(m),null!=m&&(b.startTimeCookie=m))
}Array.prototype.sort.call(g,function(a,b){return a.index-b.index
});
m=[];
for(r=0;
r<g.length;
r++){m.push(g[r].value)
}for(r=0;
r<s.length;
r++){(g=k(s[r],l))&&0<g.length&&(m=m.concat(g))
}b.cookieMetadataChunks=m
};
a.correlation.eck=b.Jd
})(a.correlation||(a.correlation={}))
})(g||(g={}));
(function(a){"APP_KEY_NOT_SET"===a.conf.appKey&&B.log("AppDynamics EUM cloud application key missing. Please specify window['adrum-app-key']");
a.correlation.Jd(document.cookie,document.referrer);
a.command("mark","firstbyte",window["adrum-start-time"]);
a.conf.spa2&&a.conf.modernBrowserFeaturesAvailable?a.monitor.setUpMonitors(a.monitor.ma,a.monitor.domEventsMonitor,a.monitor.perfMonitor,a.monitor.xhrMonitor,a.monitor.ih):a.monitor.setUpMonitors(a.monitor.ma,a.monitor.domEventsMonitor,a.monitor.perfMonitor,a.monitor.xhrMonitor)
})(g||(g={}));
(function(a){a=a.ng||(a.ng={});
a=a.c||(a.c={});
a.re="locationChangeStart";
a.Yi="locationChangeSuccess";
a.bf="routeChangeStart";
a.cf="routeChangeSuccess";
a.mf="stateChangeStart";
a.nf="stateChangeSuccess";
a.zf="viewContentLoaded";
a.ti="includeContentRequested";
a.si="includeContentLoaded";
a.Id="digest";
a.nl="outstandingRequestsComplete";
a.vd="beforeNgXhrRequested";
a.nd="afterNgXhrRequested";
a.ml="ngXhrLoaded";
a.Ad="$$completeOutstandingRequest"
})(g||(g={}));
(function(a){(function(b){function k(a,d,p,e,k,g){if(d){try{return d.apply(a,[p,e,k].concat(g))
}catch(r){return a.error(p,e,k,g,b.Error.gg,"M95",r)
}}}function e(a,d){return function(){var p=this.current,e=d[p]||d[b.Qa]||p,g=Array.prototype.slice.call(arguments);
if(this.th(a)){return this.error(a,p,e,g,b.Error.hg,"event "+a+"M96"+this.current)
}if(!1===k(this,this["onbefore"+a],a,p,e,g)){return b.Pa.Lc
}e===b.Qa&&(e=p);
if(p===e){return k(this,this["onafter"+a]||this["on"+a],a,p,e,g),b.Pa.Hg
}var s=this;
this.transition=function(){s.transition=null;
s.current=e;
k(s,s["onenter"+e]||s["on"+e],a,p,e,g);
k(s,s["onafter"+a]||s["on"+a],a,p,e,g);
return b.Pa.Qg
};
if(!1===k(this,this["onleave"+p],a,p,e,g)){return this.transition=null,b.Pa.Lc
}if(this.transition){return this.transition()
}}
}var d=a.utils.hasOwnPropertyDefined;
b.VERSION="2.3.5";
b.Pa={Qg:1,Hg:2,Lc:3,Ik:4};
b.Error={hg:100,Jk:200,gg:300};
b.Qa="*";
b.create=function(a,n){function p(a){var d=a.from instanceof Array?a.from:a.from?[a.from]:[b.Qa];
m[a.name]=m[a.name]||{};
for(var h=0;
h<d.length;
h++){y[d[h]]=y[d[h]]||[],y[d[h]].push(a.name),m[a.name][d[h]]=a.to||d[h]
}}var k="string"==typeof a.initial?{state:a.initial}:a.initial,g=n||a.target||{},s=a.events||[],r=a.callbacks||{},m={},y={};
k&&(k.event=k.event||"startup",p({name:k.event,from:"none",to:k.state}));
for(var q=0;
q<s.length;
q++){p(s[q])
}for(var A in m){d(m,A)&&(g[A]=e(A,m[A]))
}for(A in r){d(r,A)&&(g[A]=r[A])
}g.current="none";
g.el=function(a){return a instanceof Array?0<=a.indexOf(this.current):this.current===a
};
g.sh=function(a){return !this.transition&&(d(m[a],this.current)||d(m[a],b.Qa))
};
g.th=function(a){return !this.sh(a)
};
g.mb=function(){return y[this.current]
};
g.error=a.error||function(a,b,d,h,p,e,n){throw n||e
};
if(k&&!k.defer){g[k.event]()
}return g
}
})(a.fd||(a.fd={}))
})(g||(g={}));
(function(a){(function(b){var k=function(e){function d(b){b=e.call(this,b)||this;
a.utils.isDefined(a.ng)&&b.constructor!=a.ng.NgVPageView&&b.constructor!=d&&a.reportAPIMessage(a.J.W,a.sa,"ADRUM.events.VPageView",[]);
if(a.conf.spa2){return b
}b.perf=new a.PerformanceTracker;
b.start();
a.monitor.xhrMonitor.nc();
a.monitor.ma.Ej();
return b
}v(d,e);
d.prototype.type=function(){return a.EventType.VPageView
};
d.prototype.Mb=function(){return b.EventTracker.xb(this.guid(),this.url(),this.type())
};
d.prototype.kf=function(b){var d=this.Mb();
b.set("parent",d);
a.log("M97",d.guid(),d.url())
};
d.prototype.startCorrelatingXhrs=function(){a.conf.spa2||(a.log("M98"),this.kf(a.monitor.xhrMonitor))
};
d.prototype.stopCorrelatingXhrs=function(){a.conf.spa2||(a.monitor.xhrMonitor.set("parent",null),a.log("M99"))
};
d.prototype.vc=function(){a.conf.spa2||(a.log("M100"),this.kf(a.monitor.ma))
};
d.prototype.start=function(){a.conf.spa2||(this.markVirtualPageStart(),this.startCorrelatingXhrs())
};
d.prototype.end=function(){a.conf.spa2||(this.markVirtualPageEnd(),this.stopCorrelatingXhrs())
};
return d
}(b.EventTracker);
b.VPageView=k;
b.la(b.G[a.EventType.VPageView],k.prototype);
b.sd(b.metricSpec[a.EventType.VPageView],k.prototype)
})(a.events||(a.events={}))
})(g||(g={}));
(function(a){var b=a.ng||(a.ng={}),b=b.conf||(b.conf={});
b.disabled=a.conf.userConf&&a.conf.userConf.spa&&a.conf.userConf.spa.angular&&a.conf.userConf.spa.angular.disable;
b.distinguishVPwithItsTemplateUrl=a.conf.userConf&&a.conf.userConf.spa&&a.conf.userConf.spa.angular&&!0===a.conf.userConf.spa.angular.distinguishVPwithItsTemplateUrl?!0:!1;
b.xhr={};
b.metrics={includeResTimingInEndUserResponseTiming:!0};
a.conf.userConf&&a.conf.userConf.spa&&a.conf.userConf.spa.angular&&a.conf.userConf.spa.angular.vp&&(a.conf.userConf.spa.angular.vp.xhr&&a.monitor.XHRMonitor.Ne(b.xhr,a.conf.userConf.spa.angular.vp.xhr),a.conf.userConf.spa.angular.vp.metrics&&a.utils.mergeJSON(b.metrics,a.conf.userConf.spa.angular.vp.metrics))
})(g||(g={}));
(function(a){(function(b){var k=a.utils.map,e=a.utils.reduce,d=a.utils.filter,h=function(h){function p(b){b=h.call(this,b)||this;
b.je=!0;
b.Ia={};
b.ra=0;
b.El=[];
b.digestCount(0);
if(b.constructor!=p){return a.reportAPIMessage(a.J.W,a.sa,"ADRUM.events.Ajax",[]),b
}b.stopCorrelatingXhrs();
return b
}v(p,h);
p.prototype.type=function(){return a.EventType.VPageView
};
p.prototype.Hc=function(){this.markViewChangeStart();
this.markVirtualPageStart(this.getViewChangeStart());
this.timestamp(this.getViewChangeStart())
};
p.prototype.ui=function(){this.digestCount(this.digestCount()+1)
};
p.prototype.vi=function(){this.ra++;
a.log("M101",this.ra)
};
p.prototype.Dh=function(){this.ra--;
a.log("M102",this.ra)
};
p.prototype.pi=function(){var b=this.perf.getEntryByName(a.events.b.Ef);
a.log("M103",this.ra,b);
return 0<this.ra
};
p.prototype.ph=function(){var a={lb:0},b=document.querySelectorAll("ng-view, [ng-view], .ng-view, [ui-view]"),b=k(b,angular.element),d;
for(d in p.Ze){var h=p.Ze[d];
k(b,function(b){b=b.find(d);
k(b,function(b){if(b=b[h]){b=decodeURIComponent(b),a[b]||(a[b]=d,a.lb++)
}})
})
}this.Ia=a
};
p.prototype.oh=function(a){return !!this.Ia[decodeURIComponent(a.name)]
};
p.prototype.qh=function(){var b=[],d=this;
0<this.Ia.lb&&(b=a.monitor.perfMonitor.Z().filter(function(a){return d.oh(a)
}));
this.resTiming(b)
};
p.Rh=function(h){return d(h,function(d){return(d.eventType===a.EventType.Ajax||d.eventType===a.EventType.ADRUM_XHR)&&!a.monitor.XHRMonitor.jf(d.eventUrl,b.conf.xhr,d.method)
})
};
p.fi=function(a){return e(a,function(a,b){return Math.max(a,b.timestamp+b.metrics.PLT)
},-1)
};
p.prototype.fh=function(){if(b.conf.xhr){var d=p.Rh(a.channel.getEventsWithParentGUID(this.guid())),d=p.fi(d);
if(0<d){var h=this.perf.getEntryByName(a.events.b.Ef);
this.markXhrRequestsCompleted(Math.min(h&&h.startTime||Number.MAX_VALUE,d))
}}};
p.prototype.adjustTimings=function(){this.fh();
var d=this.getViewDOMLoaded(),h=this.getXhrRequestsCompleted(),d=Math.max(d,h);
b.conf.metrics.includeResTimingInEndUserResponseTiming&&(this.eh(),h=this.getViewResourcesLoaded(),h=Math.max(d,h),a.log("M104",d,h),d=h);
this.markVirtualPageEnd(d)
};
p.prototype.eh=function(){if(0<this.Ia.lb){this.qh();
var b=this.resTiming();
b&&b.length>=this.Ia.lb&&(b=e(b,function(a,b){return Math.max(a,b.responseEnd)
},0),this.markViewResourcesLoaded(a.PerformanceTracker.Bb(b)))
}};
p.prototype.identifier=function(b){var d=this.Bf;
a.utils.isDefined(b)&&(this.Bf=p.Ph(b),this.url(this.Bf.url));
return d
};
p.Ph=function(b){var d={};
b&&b.C?(d.C={fc:""},a.utils.mergeJSON(d.C,{fc:b.C.originalPath,Ja:b.C.template,Ka:b.C.templateUrl})):b&&b.state&&(d.state={url:""},a.utils.mergeJSON(d.state,{url:b.state.url,name:b.state.name,Ja:b.state.template,Ka:b.state.templateUrl}));
return d
};
return p
}(a.events.VPageView);
h.Ze={img:"src",script:"src",link:"href"};
b.NgVPageView=h;
a.events.la(a.events.G[a.EventType.NG_VIRTUAL_PAGE],h.prototype)
})(a.ng||(a.ng={}))
})(g||(g={}));
(function(a){(function(b){var k=function(){function e(){this.j=new b.NgVPageView
}e.prototype.Lj=function(){var d=this,h=this.j;
b.conf.metrics.includeResTimingInEndUserResponseTiming?(a.log("M105"),a.utils.oSTO(function(){d.kc(h)
},e.Sg)):a.utils.oSTO(function(){d.kc(h)
},e.Tg)
};
e.prototype.kc=function(b){a.log("M106");
b.parent(a.monitor.DOMEventsMonitor.currentBasePage);
a.command("call",function(){b.adjustTimings();
a.reporter.reportEvent(b)
})
};
e.prototype.Rj=function(a){this.j=a
};
return e
}();
k.Sg=5000;
k.Tg=2*a.monitor.XHRMonitor.Vf;
b.VirtualPageStateMachine=k;
a.fd.create({events:[{name:"start",from:"none",to:"ChangeView"},{name:"viewLoaded",from:"ChangeView",to:"XhrPending"},{name:"xhrCompleted",from:"XhrPending",to:"End"},{name:"abort",from:"*",to:"none"},{name:"init",from:"*",to:"none"},{name:"locChange",from:"*",to:"*"},{name:"beforeXhrReq",from:"*",to:"*"},{name:"afterXhrReq",from:"*",to:"*"}],error:function(b){a.log("M107",b)
},callbacks:{onChangeView:function(){this.j.Hc();
this.j.vc()
},onviewLoaded:function(){this.j.markViewDOMLoaded()
},onXhrPending:function(){this.j.je&&this.xhrCompleted()
},onleaveXhrPending:function(a,b,h){if("abort"===a){return this.kc(),!0
}if("xhrCompleted"===a&&"End"===h){if(this.j.pi()){return !1
}this.j.markXhrRequestsCompleted();
return !0
}},onEnd:function(){this.j.ph();
this.Lj()
},oninit:function(b,d,h,n){this.Rj(n);
a.monitor.xhrMonitor.nc()
},onlocChange:function(a,b,h,n){this.j.identifier.url=n;
this.j.jb({url:n})
},onbeforeXhrReq:function(b,d,h,n){var p=this.j;
p.je=!1;
a.log("M108",n&&n[1]||"",p.guid());
p.vi();
p.startCorrelatingXhrs();
n[3]&&(n[3]=a.aop.before(n[3],function(b,d,h){a.log("M109");
p.Dh();
h&&(b=a.utils.sj(h)["content-type"])&&0<=b.indexOf("text/html")&&p.markViewFragmentsLoaded()
}));
return n
},onafterXhrReq:function(){this.j.stopCorrelatingXhrs()
}}},k.prototype)
})(a.ng||(a.ng={}))
})(g||(g={}));
(function(a){(function(b){var k=function(){function e(){this.D=new b.VirtualPageStateMachine;
this.distinguishVPwithItsTemplateUrl=a.ng.conf.distinguishVPwithItsTemplateUrl
}e.prototype.F=function(d,h){a.log("M110",d);
switch(d){case b.c.bf:case b.c.mf:this.D.start();
var n=h.next.url||document.URL,p=new b.NgVPageView({url:n,identifier:h.next});
this.distinguishVPwithItsTemplateUrl&&e.Fi(this.D.j,p)?this.D.j.jb({url:n,identifier:h.next}):this.ek(p);
break;
case b.c.cf:case b.c.nf:this.D.j.markViewChangeEnd();
break;
case b.c.zf:this.D.viewLoaded();
break;
case b.c.vd:this.D.beforeXhrReq(h);
break;
case b.c.nd:this.D.afterXhrReq();
break;
case b.c.Ad:this.D.xhrCompleted();
break;
case b.c.re:this.D.j.jb({url:h.next.url});
this.D.locChange(h.next.url);
break;
case b.c.Id:this.D.j.ui()
}};
e.prototype.ek=function(a){this.D.abort();
this.D.init(a);
this.D.start()
};
e.Fi=function(b,h){var e=b.identifier(),p=h.identifier(),k=!1;
return k=!a.utils.isDefined(e)&&!a.utils.isDefined(p)||e===p?!0:a.utils.isDefined(e)&&a.utils.isDefined(p)?e.state||p.state?a.utils.isDefined(e.state)&&a.utils.isDefined(p.state)?e.state.name===p.state.name&&e.state.Ja===p.state.Ja&&e.state.Ka===p.state.Ka&&e.state.url===p.state.url:!1:e.C&&p.C?e.C.fc===p.C.fc&&e.C.Ja===p.C.Ja&&e.C.Ka===p.C.Ka:e.url===p.url:!1
};
return e
}();
b.Ug=k
})(a.ng||(a.ng={}))
})(g||(g={}));
(function(a){(function(b){var k=a.utils.addEventListener,e=function(){function d(){this.H=new b.Ug;
this.fe=!1
}d.prototype.setUp=function(){function b(h){return function(){a.log(h);
d.init()
}
}var d=this;
b("M111")();
k(document,"DOMContentLoaded",b("M112"));
k(window,"load",b("M113"))
};
d.prototype.init=function(){if("undefined"!=typeof angular&&!this.fe){this.fe=!0;
a.log("M114");
var b=this,d=angular.module("ng");
d.config(["$provide",function(a){b.Bi(a);
b.Ai(a)
}]);
d.run(["$browser",function(a){b.yi(a)
}]);
a.log("M115")
}};
d.prototype.Ai=function(d){var e=a.aop,p=this;
d.decorator("$httpBackend",["$delegate",function(a){return a=e.around(a,function(){var a=Array.prototype.slice.call(arguments);
p.H.F(b.c.vd,a);
return a
},function(){p.H.F(b.c.nd)
},"ng.httpBackend")
}])
};
d.prototype.Bi=function(d){var e=a.aop,p=this;
d.decorator("$rootScope",["$delegate",function(a){a.$digest=e.after(a.$digest,function(){p.H.F(b.c.Id)
},"ngevents.digest");
a.$on("$locationChangeStart",function(a,d){var h={url:d},e=a&&a.Aa&&a.Aa.$state&&a.Aa.$state.current;
e&&(h.state=e);
p.H.F(b.c.re,{next:h})
});
a.$on("$locationChangeSuccess",function(){p.H.F(b.c.Yi)
});
a.$on("$routeChangeStart",function(a,d){var h={url:location.href},e=d&&d.$$route;
e&&(h.C=e);
p.H.F(b.c.bf,{next:h})
});
a.$on("$routeChangeSuccess",function(){p.H.F(b.c.cf)
});
a.$on("$stateChangeStart",function(a,d){p.H.F(b.c.mf,{next:{state:d}})
});
a.$on("$stateChangeSuccess",function(){p.H.F(b.c.nf)
});
a.$on("$viewContentLoaded",function(a){var d={url:location.href};
if(a=a&&a.Aa&&a.Aa.$state&&a.Aa.$state.current){d.state=a
}p.H.F(b.c.zf,{next:d})
});
a.$on("$includeContentRequested",function(){p.H.F(b.c.ti)
});
a.$on("$includeContentLoaded",function(){p.H.F(b.c.si)
});
return a
}])
};
d.prototype.yi=function(d){var e=this;
d.$$completeOutstandingRequest=a.aop.before(d.$$completeOutstandingRequest,function(){e.H.F(b.c.Ad)
})
};
return d
}();
b.Ek=e;
b.ngMonitor=new e
})(a.ng||(a.ng={}))
})(g||(g={}));
(function(a){var b=a.ng||(a.ng={});
b.conf.disabled||a.conf.spa2||a.monitor.setUpMonitors(b.ngMonitor)
})(g||(g={}))
}}
})();
var adrumvPageView={};
window["dcc-vp-start"]=window.performance&&window.performance.timing?window.performance.timing.navigationStart:(new Date).getTime();
window.ADRUM_utils=function(){function f(g){var a=window.location.href.split("?")[0]?window.location.href.split("?")[0]:window.location.href;
a=a.replace(/\#/g,"");
a+="#";
a+=g;
if(typeof ADRUM!=="undefined"){console.log("PAGE LOAD START-"+a);
adrumvPageView=new ADRUM.events.VPageView({url:a});
adrumvPageView.start();
adrumvPageView.markVirtualPageStart(window["dcc-vp-start"]);
adrumvPageView.markViewChangeStart()
}}function d(){return adrumvPageView
}function c(a){try{if(a&&!a.submitted){window.dccPageRenderTime=(new Date).getTime()-window["dcc-vp-start"];
console.log("PAGE LOAD END-"+a._url);
a.submitted=true;
b(a)
}}catch(a){}}function b(a){try{if(typeof ADRUM!=="undefined"){a.markViewChangeEnd();
a.markViewDOMLoaded();
a.markXhrRequestsCompleted();
console.log("ADRUM END-"+a._url);
a.end();
ADRUM.report(a)
}}catch(a){}}return{getAdrumvPageView:d,initializeAdrumVirtualPage:f,endAdrumVPMainPage:c}
}();
window.ADRUM_utils.initializeAdrumVirtualPage(document.querySelectorAll("[data-param]")[0].getAttribute("data-param"));