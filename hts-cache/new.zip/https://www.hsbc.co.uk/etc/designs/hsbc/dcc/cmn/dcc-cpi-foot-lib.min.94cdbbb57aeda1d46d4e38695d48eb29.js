(function(b,a){typeof exports==="object"&&typeof module!=="undefined"?module.exports=a():typeof define==="function"&&define.amd?define(a):(b.Popper=a())
}(this,(function(){var N=typeof window!=="undefined"&&typeof document!=="undefined"&&typeof navigator!=="undefined";
var M=function(){var aF=["Edge","Trident","Firefox"];
for(var aG=0;
aG<aF.length;
aG+=1){if(N&&navigator.userAgent.indexOf(aF[aG])>=0){return 1
}}return 0
}();
function ay(aF){var aG=false;
return function(){if(aG){return
}aG=true;
window.Promise.resolve().then(function(){aG=false;
aF()
})
}
}function h(aF){var aG=false;
return function(){if(!aG){aG=true;
setTimeout(function(){aG=false;
aF()
},M)
}}
}var aq=N&&window.Promise;
var aE=aq?ay:h;
function at(aF){var aG={};
return aF&&aG.toString.call(aF)==="[object Function]"
}function F(aG,aI){if(aG.nodeType!==1){return[]
}var aH=aG.ownerDocument.defaultView;
var aF=aH.getComputedStyle(aG,null);
return aI?aF[aI]:aF
}function ab(aF){if(aF.nodeName==="HTML"){return aF
}return aF.parentNode||aF.host
}function ad(aI){if(!aI){return document.body
}switch(aI.nodeName){case"HTML":case"BODY":return aI.ownerDocument.body;
case"#document":return aI.body
}var aF=F(aI),aJ=aF.overflow,aH=aF.overflowX,aG=aF.overflowY;
if(/(auto|scroll|overlay)/.test(aJ+aG+aH)){return aI
}return ad(ab(aI))
}function an(aF){return aF&&aF.referenceNode?aF.referenceNode:aF
}var s=N&&!!(window.MSInputMethodContext&&document.documentMode);
var t=N&&/MSIE 10/.test(navigator.userAgent);
function az(aF){if(aF===11){return s
}if(aF===10){return t
}return s||t
}function al(aF){if(!aF){return document.documentElement
}var aH=az(10)?document.body:null;
var aG=aF.offsetParent||null;
while(aG===aH&&aF.nextElementSibling){aG=(aF=aF.nextElementSibling).offsetParent
}var aI=aG&&aG.nodeName;
if(!aI||aI==="BODY"||aI==="HTML"){return aF?aF.ownerDocument.documentElement:document.documentElement
}if(["TH","TD","TABLE"].indexOf(aG.nodeName)!==-1&&F(aG,"position")==="static"){return al(aG)
}return aG
}function C(aF){var aG=aF.nodeName;
if(aG==="BODY"){return false
}return aG==="HTML"||al(aF.firstElementChild)===aF
}function X(aF){if(aF.parentNode!==null){return X(aF.parentNode)
}return aF
}function ak(aK,aJ){if(!aK||!aK.nodeType||!aJ||!aJ.nodeType){return document.documentElement
}var aF=aK.compareDocumentPosition(aJ)&Node.DOCUMENT_POSITION_FOLLOWING;
var aM=aF?aK:aJ;
var aG=aF?aJ:aK;
var aH=document.createRange();
aH.setStart(aM,0);
aH.setEnd(aG,0);
var aL=aH.commonAncestorContainer;
if(aK!==aL&&aJ!==aL||aM.contains(aG)){if(C(aL)){return aL
}return al(aL)
}var aI=X(aK);
if(aI.host){return ak(aI.host,aJ)
}else{return ak(aK,X(aJ).host)
}}function E(aI){var aH=arguments.length>1&&arguments[1]!==undefined?arguments[1]:"top";
var aF=aH==="top"?"scrollTop":"scrollLeft";
var aK=aI.nodeName;
if(aK==="BODY"||aK==="HTML"){var aG=aI.ownerDocument.documentElement;
var aJ=aI.ownerDocument.scrollingElement||aG;
return aJ[aF]
}return aI[aF]
}function d(aH,aG){var aJ=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;
var aI=E(aG,"top");
var aK=E(aG,"left");
var aF=aJ?-1:1;
aH.top+=aI*aF;
aH.bottom+=aI*aF;
aH.left+=aK*aF;
aH.right+=aK*aF;
return aH
}function ai(aI,aH){var aG=aH==="x"?"Left":"Top";
var aF=aG==="Left"?"Right":"Bottom";
return parseFloat(aI["border"+aG+"Width"])+parseFloat(aI["border"+aF+"Width"])
}function i(aI,aF,aH,aG){return Math.max(aF["offset"+aI],aF["scroll"+aI],aH["client"+aI],aH["offset"+aI],aH["scroll"+aI],az(10)?parseInt(aH["offset"+aI])+parseInt(aG["margin"+(aI==="Height"?"Top":"Left")])+parseInt(aG["margin"+(aI==="Height"?"Bottom":"Right")]):0)
}function G(aG){var aF=aG.body;
var aI=aG.documentElement;
var aH=az(10)&&getComputedStyle(aI);
return{height:i("Height",aF,aI,aH),width:i("Width",aF,aI,aH)}
}var g=function(aF,aG){if(!(aF instanceof aG)){throw new TypeError("Cannot call a class as a function")
}};
var aB=function(){function aF(aJ,aH){for(var aG=0;
aG<aH.length;
aG++){var aI=aH[aG];
aI.enumerable=aI.enumerable||false;
aI.configurable=true;
if("value" in aI){aI.writable=true
}Object.defineProperty(aJ,aI.key,aI)
}}return function(aI,aG,aH){if(aG){aF(aI.prototype,aG)
}if(aH){aF(aI,aH)
}return aI
}
}();
var r=function(aH,aF,aG){if(aF in aH){Object.defineProperty(aH,aF,{value:aG,enumerable:true,configurable:true,writable:true})
}else{aH[aF]=aG
}return aH
};
var O=Object.assign||function(aI){for(var aG=1;
aG<arguments.length;
aG++){var aH=arguments[aG];
for(var aF in aH){if(Object.prototype.hasOwnProperty.call(aH,aF)){aI[aF]=aH[aF]
}}}return aI
};
function n(aF){return O({},aF,{right:aF.left+aF.width,bottom:aF.top+aF.height})
}function Z(aI){var aL={};
try{if(az(10)){aL=aI.getBoundingClientRect();
var aG=E(aI,"top");
var aH=E(aI,"left");
aL.top+=aG;
aL.left+=aH;
aL.bottom+=aG;
aL.right+=aH
}else{aL=aI.getBoundingClientRect()
}}catch(aJ){}var aQ={left:aL.left,top:aL.top,width:aL.right-aL.left,height:aL.bottom-aL.top};
var aP=aI.nodeName==="HTML"?G(aI.ownerDocument):{};
var aF=aP.width||aI.clientWidth||aQ.width;
var aN=aP.height||aI.clientHeight||aQ.height;
var aM=aI.offsetWidth-aF;
var aK=aI.offsetHeight-aN;
if(aM||aK){var aO=F(aI);
aM-=ai(aO,"x");
aK-=ai(aO,"y");
aQ.width-=aM;
aQ.height-=aK
}return n(aQ)
}function H(aH,aO){var aK=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;
var aF=az(10);
var aL=aO.nodeName==="HTML";
var aM=Z(aH);
var aS=Z(aO);
var aQ=ad(aH);
var aR=F(aO);
var aN=parseFloat(aR.borderTopWidth);
var aP=parseFloat(aR.borderLeftWidth);
if(aK&&aL){aS.top=Math.max(aS.top,0);
aS.left=Math.max(aS.left,0)
}var aJ=n({top:aM.top-aS.top-aN,left:aM.left-aS.left-aP,width:aM.width,height:aM.height});
aJ.marginTop=0;
aJ.marginLeft=0;
if(!aF&&aL){var aG=parseFloat(aR.marginTop);
var aI=parseFloat(aR.marginLeft);
aJ.top-=aN-aG;
aJ.bottom-=aN-aG;
aJ.left-=aP-aI;
aJ.right-=aP-aI;
aJ.marginTop=aG;
aJ.marginLeft=aI
}if(aF&&!aK?aO.contains(aQ):aO===aQ&&aQ.nodeName!=="BODY"){aJ=d(aJ,aO)
}return aJ
}function Q(aJ){var aM=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;
var aL=aJ.ownerDocument.documentElement;
var aK=H(aJ,aL);
var aF=Math.max(aL.clientWidth,window.innerWidth||0);
var aN=Math.max(aL.clientHeight,window.innerHeight||0);
var aG=!aM?E(aL):0;
var aH=!aM?E(aL,"left"):0;
var aI={top:aG-aK.top+aK.marginTop,left:aH-aK.left+aK.marginLeft,width:aF,height:aN};
return n(aI)
}function k(aG){var aH=aG.nodeName;
if(aH==="BODY"||aH==="HTML"){return false
}if(F(aG,"position")==="fixed"){return true
}var aF=ab(aG);
if(!aF){return false
}return k(aF)
}function aj(aF){if(!aF||!aF.parentElement||az()){return document.documentElement
}var aG=aF.parentElement;
while(aG&&F(aG,"transform")==="none"){aG=aG.parentElement
}return aG||document.documentElement
}function J(aO,aL,aP,aH){var aM=arguments.length>4&&arguments[4]!==undefined?arguments[4]:false;
var aJ={top:0,left:0};
var aF=aM?aj(aO):ak(aO,an(aL));
if(aH==="viewport"){aJ=Q(aF,aM)
}else{var aQ=void 0;
if(aH==="scrollParent"){aQ=ad(ab(aL));
if(aQ.nodeName==="BODY"){aQ=aO.ownerDocument.documentElement
}}else{if(aH==="window"){aQ=aO.ownerDocument.documentElement
}else{aQ=aH
}}var aK=H(aQ,aF,aM);
if(aQ.nodeName==="HTML"&&!k(aF)){var aI=G(aO.ownerDocument),aR=aI.height,aG=aI.width;
aJ.top+=aK.top-aK.marginTop;
aJ.bottom=aR+aK.top;
aJ.left+=aK.left-aK.marginLeft;
aJ.right=aG+aK.left
}else{aJ=aK
}}aP=aP||0;
var aN=typeof aP==="number";
aJ.left+=aN?aP:aP.left||0;
aJ.top+=aN?aP:aP.top||0;
aJ.right-=aN?aP:aP.right||0;
aJ.bottom-=aN?aP:aP.bottom||0;
return aJ
}function ao(aH){var aG=aH.width,aF=aH.height;
return aG*aF
}function aC(aN,aF,aO,aM,aI){var aP=arguments.length>5&&arguments[5]!==undefined?arguments[5]:0;
if(aN.indexOf("auto")===-1){return aN
}var aK=J(aO,aM,aP,aI);
var aQ={top:{width:aK.width,height:aF.top-aK.top},right:{width:aK.right-aF.right,height:aK.height},bottom:{width:aK.width,height:aK.bottom-aF.bottom},left:{width:aF.left-aK.left,height:aK.height}};
var aJ=Object.keys(aQ).map(function(aR){return O({key:aR},aQ[aR],{area:ao(aQ[aR])})
}).sort(function(aS,aR){return aR.area-aS.area
});
var aH=aJ.filter(function(aT){var aS=aT.width,aR=aT.height;
return aS>=aO.clientWidth&&aR>=aO.clientHeight
});
var aG=aH.length>0?aH[0].key:aJ[0].key;
var aL=aN.split("-")[1];
return aG+(aL?"-"+aL:"")
}function p(aI,aG,aF){var aH=arguments.length>3&&arguments[3]!==undefined?arguments[3]:null;
var aJ=aH?aj(aG):ak(aG,an(aF));
return H(aF,aJ,aH)
}function z(aH){var aJ=aH.ownerDocument.defaultView;
var aI=aJ.getComputedStyle(aH);
var aG=parseFloat(aI.marginTop||0)+parseFloat(aI.marginBottom||0);
var aK=parseFloat(aI.marginLeft||0)+parseFloat(aI.marginRight||0);
var aF={width:aH.offsetWidth+aK,height:aH.offsetHeight+aG};
return aF
}function w(aF){var aG={left:"right",right:"left",bottom:"top",top:"bottom"};
return aF.replace(/left|right|bottom|top/g,function(aH){return aG[aH]
})
}function P(aN,aG,aH){aH=aH.split("-")[0];
var aM=z(aN);
var aI={width:aM.width,height:aM.height};
var aO=["right","left"].indexOf(aH)!==-1;
var aK=aO?"top":"left";
var aL=aO?"left":"top";
var aF=aO?"height":"width";
var aJ=!aO?"height":"width";
aI[aK]=aG[aK]+aG[aF]/2-aM[aF]/2;
if(aH===aL){aI[aL]=aG[aL]-aM[aJ]
}else{aI[aL]=aG[w(aL)]
}return aI
}function aD(aF,aG){if(Array.prototype.find){return aF.find(aG)
}return aF.filter(aG)[0]
}function ah(aF,aI,aH){if(Array.prototype.findIndex){return aF.findIndex(function(aJ){return aJ[aI]===aH
})
}var aG=aD(aF,function(aJ){return aJ[aI]===aH
});
return aF.indexOf(aG)
}function x(aH,aI,aG){var aF=aG===undefined?aH:aH.slice(0,ah(aH,"name",aG));
aF.forEach(function(aJ){if(aJ["function"]){console.warn("`modifier.function` is deprecated, use `modifier.fn`!")
}var aK=aJ["function"]||aJ.fn;
if(aJ.enabled&&at(aK)){aI.offsets.popper=n(aI.offsets.popper);
aI.offsets.reference=n(aI.offsets.reference);
aI=aK(aI,aJ)
}});
return aI
}function A(){if(this.state.isDestroyed){return
}var aF={instance:this,styles:{},arrowStyles:{},attributes:{},flipped:false,offsets:{}};
aF.offsets.reference=p(this.state,this.popper,this.reference,this.options.positionFixed);
aF.placement=aC(this.options.placement,aF.offsets.reference,this.popper,this.reference,this.options.modifiers.flip.boundariesElement,this.options.modifiers.flip.padding);
aF.originalPlacement=aF.placement;
aF.positionFixed=this.options.positionFixed;
aF.offsets.popper=P(this.popper,aF.offsets.reference,aF.placement);
aF.offsets.popper.position=this.options.positionFixed?"fixed":"absolute";
aF=x(this.modifiers,aF);
if(!this.state.isCreated){this.state.isCreated=true;
this.options.onCreate(aF)
}else{this.options.onUpdate(aF)
}}function ar(aF,aG){return aF.some(function(aJ){var aI=aJ.name,aH=aJ.enabled;
return aH&&aI===aG
})
}function u(aK){var aJ=[false,"ms","Webkit","Moz","O"];
var aH=aK.charAt(0).toUpperCase()+aK.slice(1);
for(var aF=0;
aF<aJ.length;
aF++){var aI=aJ[aF];
var aG=aI?""+aI+aH:aK;
if(typeof document.body.style[aG]!=="undefined"){return aG
}}return null
}function c(){this.state.isDestroyed=true;
if(ar(this.modifiers,"applyStyle")){this.popper.removeAttribute("x-placement");
this.popper.style.position="";
this.popper.style.top="";
this.popper.style.left="";
this.popper.style.right="";
this.popper.style.bottom="";
this.popper.style.willChange="";
this.popper.style[u("transform")]=""
}this.disableEventListeners();
if(this.options.removeOnDestroy){this.popper.parentNode.removeChild(this.popper)
}return this
}function W(aG){var aF=aG.ownerDocument;
return aF?aF.defaultView:window
}function U(aK,aG,aJ,aI){var aF=aK.nodeName==="BODY";
var aH=aF?aK.ownerDocument.defaultView:aK;
aH.addEventListener(aG,aJ,{passive:true});
if(!aF){U(ad(aH.parentNode),aG,aJ,aI)
}aI.push(aH)
}function V(aF,aG,aH,aJ){aH.updateBound=aJ;
W(aF).addEventListener("resize",aH.updateBound,{passive:true});
var aI=ad(aF);
U(aI,"scroll",aH.updateBound,aH.scrollParents);
aH.scrollElement=aI;
aH.eventsEnabled=true;
return aH
}function e(){if(!this.state.eventsEnabled){this.state=V(this.reference,this.options,this.state,this.scheduleUpdate)
}}function v(aF,aG){W(aF).removeEventListener("resize",aG.updateBound);
aG.scrollParents.forEach(function(aH){aH.removeEventListener("scroll",aG.updateBound)
});
aG.updateBound=null;
aG.scrollParents=[];
aG.scrollElement=null;
aG.eventsEnabled=false;
return aG
}function y(){if(this.state.eventsEnabled){cancelAnimationFrame(this.scheduleUpdate);
this.state=v(this.reference,this.state)
}}function q(aF){return aF!==""&&!isNaN(parseFloat(aF))&&isFinite(aF)
}function o(aF,aG){Object.keys(aG).forEach(function(aI){var aH="";
if(["width","height","top","right","bottom","left"].indexOf(aI)!==-1&&q(aG[aI])){aH="px"
}aF.style[aI]=aG[aI]+aH
})
}function B(aG,aF){Object.keys(aF).forEach(function(aI){var aH=aF[aI];
if(aH!==false){aG.setAttribute(aI,aF[aI])
}else{aG.removeAttribute(aI)
}})
}function l(aF){o(aF.instance.popper,aF.styles);
B(aF.instance.popper,aF.attributes);
if(aF.arrowElement&&Object.keys(aF.arrowStyles).length){o(aF.arrowElement,aF.arrowStyles)
}return aF
}function au(aF,aH,aI,aK,aL){var aG=p(aL,aH,aF,aI.positionFixed);
var aJ=aC(aI.placement,aG,aH,aF,aI.modifiers.flip.boundariesElement,aI.modifiers.flip.padding);
aH.setAttribute("x-placement",aJ);
o(aH,{position:aI.positionFixed?"fixed":"absolute"});
return aI
}function f(aM,aP){var aQ=aM.offsets,aR=aQ.popper,aH=aQ.reference;
var aU=Math.round,aO=Math.floor;
var aJ=function aJ(aV){return aV
};
var aG=aU(aH.width);
var aL=aU(aR.width);
var aS=["left","right"].indexOf(aM.placement)!==-1;
var aI=aM.placement.indexOf("-")!==-1;
var aK=aG%2===aL%2;
var aT=aG%2===1&&aL%2===1;
var aN=!aP?aJ:aS||aI||aK?aU:aO;
var aF=!aP?aJ:aU;
return{left:aN(aT&&!aI&&aP?aR.left-1:aR.left),top:aF(aR.top),bottom:aF(aR.bottom),right:aN(aR.right)}
}var b=N&&/Firefox/i.test(navigator.userAgent);
function ap(aX,aH){var aN=aH.x,aM=aH.y;
var aU=aX.offsets.popper;
var aR=aD(aX.instance.modifiers,function(aY){return aY.name==="applyStyle"
}).gpuAcceleration;
if(aR!==undefined){console.warn("WARNING: `gpuAcceleration` option moved to `computeStyle` modifier and will not be supported in future versions of Popper.js!")
}var aQ=aR!==undefined?aR:aH.gpuAcceleration;
var aF=al(aX.instance.popper);
var aS=Z(aF);
var aL={position:aU.position};
var aJ=f(aX,window.devicePixelRatio<2||!b);
var aW=aN==="bottom"?"top":"bottom";
var aV=aM==="right"?"left":"right";
var aO=u("transform");
var aI=void 0,aP=void 0;
if(aW==="bottom"){if(aF.nodeName==="HTML"){aP=-aF.clientHeight+aJ.bottom
}else{aP=-aS.height+aJ.bottom
}}else{aP=aJ.top
}if(aV==="right"){if(aF.nodeName==="HTML"){aI=-aF.clientWidth+aJ.right
}else{aI=-aS.width+aJ.right
}}else{aI=aJ.left
}if(aQ&&aO){aL[aO]="translate3d("+aI+"px, "+aP+"px, 0)";
aL[aW]=0;
aL[aV]=0;
aL.willChange="transform"
}else{var aG=aW==="bottom"?-1:1;
var aT=aV==="right"?-1:1;
aL[aW]=aP*aG;
aL[aV]=aI*aT;
aL.willChange=aW+", "+aV
}var aK={"x-placement":aX.placement};
aX.attributes=O({},aK,aX.attributes);
aX.styles=O({},aL,aX.styles);
aX.arrowStyles=O({},aX.offsets.arrow,aX.arrowStyles);
return aX
}function I(aF,aG,aH){var aL=aD(aF,function(aN){var aM=aN.name;
return aM===aG
});
var aJ=!!aL&&aF.some(function(aM){return aM.name===aH&&aM.enabled&&aM.order<aL.order
});
if(!aJ){var aI="`"+aG+"`";
var aK="`"+aH+"`";
console.warn(aK+" modifier is required by "+aI+" modifier in order to work, be sure to include it before "+aI+"!")
}return aJ
}function L(aY,aK){var aS;
if(!I(aY.instance.modifiers,"arrow","keepTogether")){return aY
}var aT=aK.element;
if(typeof aT==="string"){aT=aY.instance.popper.querySelector(aT);
if(!aT){return aY
}}else{if(!aY.instance.popper.contains(aT)){console.warn("WARNING: `arrow.element` must be child of its popper element!");
return aY
}}var aR=aY.placement.split("-")[0];
var aI=aY.offsets,aV=aI.popper,aM=aI.reference;
var aN=["left","right"].indexOf(aR)!==-1;
var aU=aN?"height":"width";
var aJ=aN?"Top":"Left";
var aH=aJ.toLowerCase();
var aW=aN?"left":"top";
var aG=aN?"bottom":"right";
var aL=z(aT)[aU];
if(aM[aG]-aL<aV[aH]){aY.offsets.popper[aH]-=aV[aH]-(aM[aG]-aL)
}if(aM[aH]+aL>aV[aG]){aY.offsets.popper[aH]+=aM[aH]+aL-aV[aG]
}aY.offsets.popper=n(aY.offsets.popper);
var aX=aM[aH]+aM[aU]/2-aL/2;
var aP=F(aY.instance.popper);
var aF=parseFloat(aP["margin"+aJ]);
var aO=parseFloat(aP["border"+aJ+"Width"]);
var aQ=aX-aY.offsets.popper[aH]-aF-aO;
aQ=Math.max(Math.min(aV[aU]-aL,aQ),0);
aY.arrowElement=aT;
aY.offsets.arrow=(aS={},r(aS,aH,Math.round(aQ)),r(aS,aW,""),aS);
return aY
}function ac(aF){if(aF==="end"){return"start"
}else{if(aF==="start"){return"end"
}}return aF
}var K=["auto-start","auto","auto-end","top-start","top","top-end","right-start","right","right-end","bottom-end","bottom","bottom-start","left-end","left","left-start"];
var aw=K.slice(3);
function ax(aI){var aG=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;
var aH=aw.indexOf(aI);
var aF=aw.slice(aH+1).concat(aw.slice(0,aH));
return aG?aF.reverse():aF
}var av={FLIP:"flip",CLOCKWISE:"clockwise",COUNTERCLOCKWISE:"counterclockwise"};
function af(aK,aG){if(ar(aK.instance.modifiers,"inner")){return aK
}if(aK.flipped&&aK.placement===aK.originalPlacement){return aK
}var aF=J(aK.instance.popper,aK.instance.reference,aG.padding,aG.boundariesElement,aK.positionFixed);
var aI=aK.placement.split("-")[0];
var aL=w(aI);
var aH=aK.placement.split("-")[1]||"";
var aJ=[];
switch(aG.behavior){case av.FLIP:aJ=[aI,aL];
break;
case av.CLOCKWISE:aJ=ax(aI);
break;
case av.COUNTERCLOCKWISE:aJ=ax(aI,true);
break;
default:aJ=aG.behavior
}aJ.forEach(function(aS,aY){if(aI!==aS||aJ.length===aY+1){return aK
}aI=aK.placement.split("-")[0];
aL=w(aI);
var aX=aK.offsets.popper;
var aN=aK.offsets.reference;
var aW=Math.floor;
var aU=aI==="left"&&aW(aX.right)>aW(aN.left)||aI==="right"&&aW(aX.left)<aW(aN.right)||aI==="top"&&aW(aX.bottom)>aW(aN.top)||aI==="bottom"&&aW(aX.top)<aW(aN.bottom);
var aM=aW(aX.left)<aW(aF.left);
var aP=aW(aX.right)>aW(aF.right);
var a0=aW(aX.top)<aW(aF.top);
var aR=aW(aX.bottom)>aW(aF.bottom);
var aT=aI==="left"&&aM||aI==="right"&&aP||aI==="top"&&a0||aI==="bottom"&&aR;
var aZ=["top","bottom"].indexOf(aI)!==-1;
var aV=!!aG.flipVariations&&(aZ&&aH==="start"&&aM||aZ&&aH==="end"&&aP||!aZ&&aH==="start"&&a0||!aZ&&aH==="end"&&aR);
var aO=!!aG.flipVariationsByContent&&(aZ&&aH==="start"&&aP||aZ&&aH==="end"&&aM||!aZ&&aH==="start"&&aR||!aZ&&aH==="end"&&a0);
var aQ=aV||aO;
if(aU||aT||aQ){aK.flipped=true;
if(aU||aT){aI=aJ[aY+1]
}if(aQ){aH=ac(aH)
}aK.placement=aI+(aH?"-"+aH:"");
aK.offsets.popper=O({},aK.offsets.popper,P(aK.instance.popper,aK.offsets.reference,aK.placement));
aK=x(aK.instance.modifiers,aK,"flip")
}});
return aK
}function Y(aJ){var aM=aJ.offsets,aN=aM.popper,aH=aM.reference;
var aI=aJ.placement.split("-")[0];
var aK=Math.floor;
var aO=["top","bottom"].indexOf(aI)!==-1;
var aL=aO?"right":"bottom";
var aG=aO?"left":"top";
var aF=aO?"width":"height";
if(aN[aL]<aK(aH[aG])){aJ.offsets.popper[aG]=aK(aH[aG])-aN[aF]
}if(aN[aG]>aK(aH[aL])){aJ.offsets.popper[aG]=aK(aH[aL])
}return aJ
}function a(aJ,aF,aI,aG){var aK=aJ.match(/((?:\-|\+)?\d*\.?\d*)(.*)/);
var aM=+aK[1];
var aN=aK[2];
if(!aM){return aJ
}if(aN.indexOf("%")===0){var aH=void 0;
switch(aN){case"%p":aH=aI;
break;
case"%":case"%r":default:aH=aG
}var aL=n(aH);
return aL[aF]/100*aM
}else{if(aN==="vh"||aN==="vw"){var aO=void 0;
if(aN==="vh"){aO=Math.max(document.documentElement.clientHeight,window.innerHeight||0)
}else{aO=Math.max(document.documentElement.clientWidth,window.innerWidth||0)
}return aO/100*aM
}else{return aM
}}}function am(aK,aM,aH,aG){var aI=[0,0];
var aO=["right","left"].indexOf(aG)!==-1;
var aN=aK.split(/(\+|\-)/).map(function(aP){return aP.trim()
});
var aL=aN.indexOf(aD(aN,function(aP){return aP.search(/,|\s/)!==-1
}));
if(aN[aL]&&aN[aL].indexOf(",")===-1){console.warn("Offsets separated by white space(s) are deprecated, use a comma (,) instead.")
}var aJ=/\s*,\s*|\s+/;
var aF=aL!==-1?[aN.slice(0,aL).concat([aN[aL].split(aJ)[0]]),[aN[aL].split(aJ)[1]].concat(aN.slice(aL+1))]:[aN];
aF=aF.map(function(aS,aP){var aR=(aP===1?!aO:aO)?"height":"width";
var aQ=false;
return aS.reduce(function(aU,aT){if(aU[aU.length-1]===""&&["+","-"].indexOf(aT)!==-1){aU[aU.length-1]=aT;
aQ=true;
return aU
}else{if(aQ){aU[aU.length-1]+=aT;
aQ=false;
return aU
}else{return aU.concat(aT)
}}},[]).map(function(aT){return a(aT,aR,aM,aH)
})
});
aF.forEach(function(aQ,aP){aQ.forEach(function(aS,aR){if(q(aS)){aI[aP]+=aS*(aQ[aR-1]==="-"?-1:1)
}})
});
return aI
}function m(aK,aL){var aI=aL.offset;
var aJ=aK.placement,aM=aK.offsets,aN=aM.popper,aH=aM.reference;
var aF=aJ.split("-")[0];
var aG=void 0;
if(q(+aI)){aG=[+aI,0]
}else{aG=am(aI,aN,aH,aF)
}if(aF==="left"){aN.top+=aG[0];
aN.left-=aG[1]
}else{if(aF==="right"){aN.top+=aG[0];
aN.left+=aG[1]
}else{if(aF==="top"){aN.left+=aG[0];
aN.top-=aG[1]
}else{if(aF==="bottom"){aN.left+=aG[0];
aN.top+=aG[1]
}}}}aK.popper=aN;
return aK
}function j(aN,aS){var aG=aS.boundariesElement||al(aN.instance.popper);
if(aN.instance.reference===aG){aG=al(aG)
}var aQ=u("transform");
var aM=aN.instance.popper.style;
var aP=aM.top,aL=aM.left,aI=aM[aQ];
aM.top="";
aM.left="";
aM[aQ]="";
var aH=J(aN.instance.popper,aN.instance.reference,aS.padding,aG,aN.positionFixed);
aM.top=aP;
aM.left=aL;
aM[aQ]=aI;
aS.boundaries=aH;
var aK=aS.priority;
var aO=aN.offsets.popper;
var aF={primary:function aJ(aT){var aU=aO[aT];
if(aO[aT]<aH[aT]&&!aS.escapeWithReference){aU=Math.max(aO[aT],aH[aT])
}return r({},aT,aU)
},secondary:function aR(aT){var aV=aT==="right"?"left":"top";
var aU=aO[aV];
if(aO[aT]>aH[aT]&&!aS.escapeWithReference){aU=Math.min(aO[aV],aH[aT]-(aT==="right"?aO.width:aO.height))
}return r({},aV,aU)
}};
aK.forEach(function(aU){var aT=["left","top"].indexOf(aU)!==-1?"primary":"secondary";
aO=O({},aO,aF[aT](aU))
});
aN.offsets.popper=aO;
return aN
}function T(aJ){var aI=aJ.placement;
var aF=aI.split("-")[0];
var aK=aI.split("-")[1];
if(aK){var aM=aJ.offsets,aH=aM.reference,aN=aM.popper;
var aO=["bottom","top"].indexOf(aF)!==-1;
var aL=aO?"left":"top";
var aG=aO?"width":"height";
var aP={start:r({},aL,aH[aL]),end:r({},aL,aH[aL]+aH[aG]-aN[aG])};
aJ.offsets.popper=O({},aN,aP[aK])
}return aJ
}function ag(aH){if(!I(aH.instance.modifiers,"hide","preventOverflow")){return aH
}var aF=aH.offsets.reference;
var aG=aD(aH.instance.modifiers,function(aI){return aI.name==="preventOverflow"
}).boundaries;
if(aF.bottom<aG.top||aF.left>aG.right||aF.top>aG.bottom||aF.right<aG.left){if(aH.hide===true){return aH
}aH.hide=true;
aH.attributes["x-out-of-boundaries"]=""
}else{if(aH.hide===false){return aH
}aH.hide=false;
aH.attributes["x-out-of-boundaries"]=false
}return aH
}function ae(aJ){var aI=aJ.placement;
var aM=aI.split("-")[0];
var aL=aJ.offsets,aH=aL.popper,aF=aL.reference;
var aG=["left","right"].indexOf(aM)!==-1;
var aK=["top","left"].indexOf(aM)===-1;
aH[aG?"left":"top"]=aF[aM]-(aK?aH[aG?"width":"height"]:0);
aJ.placement=w(aI);
aJ.offsets.popper=n(aH);
return aJ
}var aa={shift:{order:100,enabled:true,fn:T},offset:{order:200,enabled:true,fn:m,offset:0},preventOverflow:{order:300,enabled:true,fn:j,priority:["left","right","top","bottom"],padding:5,boundariesElement:"scrollParent"},keepTogether:{order:400,enabled:true,fn:Y},arrow:{order:500,enabled:true,fn:L,element:"[x-arrow]"},flip:{order:600,enabled:true,fn:af,behavior:"flip",padding:5,boundariesElement:"viewport",flipVariations:false,flipVariationsByContent:false},inner:{order:700,enabled:false,fn:ae},hide:{order:800,enabled:true,fn:ag},computeStyle:{order:850,enabled:true,fn:ap,gpuAcceleration:true,x:"bottom",y:"right"},applyStyle:{order:900,enabled:true,fn:l,onLoad:au,gpuAcceleration:undefined}};
var R={placement:"bottom",positionFixed:false,eventsEnabled:true,removeOnDestroy:false,onCreate:function D(){},onUpdate:function S(){},modifiers:aa};
var aA=function(){function aF(aK,aL){var aO=this;
var aM=arguments.length>2&&arguments[2]!==undefined?arguments[2]:{};
g(this,aF);
this.scheduleUpdate=function(){return requestAnimationFrame(aO.update)
};
this.update=aE(this.update.bind(this));
this.options=O({},aF.Defaults,aM);
this.state={isDestroyed:false,isCreated:false,scrollParents:[]};
this.reference=aK&&aK.jquery?aK[0]:aK;
this.popper=aL&&aL.jquery?aL[0]:aL;
this.options.modifiers={};
Object.keys(O({},aF.Defaults.modifiers,aM.modifiers)).forEach(function(aP){aO.options.modifiers[aP]=O({},aF.Defaults.modifiers[aP]||{},aM.modifiers?aM.modifiers[aP]:{})
});
this.modifiers=Object.keys(this.options.modifiers).map(function(aP){return O({name:aP},aO.options.modifiers[aP])
}).sort(function(aQ,aP){return aQ.order-aP.order
});
this.modifiers.forEach(function(aP){if(aP.enabled&&at(aP.onLoad)){aP.onLoad(aO.reference,aO.popper,aO.options,aP,aO.state)
}});
this.update();
var aN=this.options.eventsEnabled;
if(aN){this.enableEventListeners()
}this.state.eventsEnabled=aN
}aB(aF,[{key:"update",value:function aH(){return A.call(this)
}},{key:"destroy",value:function aG(){return c.call(this)
}},{key:"enableEventListeners",value:function aJ(){return e.call(this)
}},{key:"disableEventListeners",value:function aI(){return y.call(this)
}}]);
return aF
}();
aA.Utils=(typeof window!=="undefined"?window:global).PopperUtils;
aA.placements=K;
aA.Defaults=R;
return aA
})));
/*!
  * Bootstrap v4.5.2 (https://getbootstrap.com/)
  * Copyright 2011-2020 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
  * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
  */
(function(b,a){typeof exports==="object"&&typeof module!=="undefined"?a(exports,require("jquery"),require("popper.js")):typeof define==="function"&&define.amd?define(["exports","jquery","popper.js"],a):(b=typeof globalThis!=="undefined"?globalThis:b||self,a(b.bootstrap={},b.jQuery,b.Popper))
}(this,(function(aX,d9,cd){d9=d9&&Object.prototype.hasOwnProperty.call(d9,"default")?d9["default"]:d9;
cd=cd&&Object.prototype.hasOwnProperty.call(cd,"default")?cd["default"]:cd;
function cm(ev,et){for(var es=0;
es<et.length;
es++){var eu=et[es];
eu.enumerable=eu.enumerable||false;
eu.configurable=true;
if("value" in eu){eu.writable=true
}Object.defineProperty(ev,eu.key,eu)
}}function aQ(eu,es,et){if(es){cm(eu.prototype,es)
}if(et){cm(eu,et)
}return eu
}function k(){k=Object.assign||function(ev){for(var et=1;
et<arguments.length;
et++){var eu=arguments[et];
for(var es in eu){if(Object.prototype.hasOwnProperty.call(eu,es)){ev[es]=eu[es]
}}}return ev
};
return k.apply(this,arguments)
}function ch(et,es){et.prototype=Object.create(es.prototype);
et.prototype.constructor=et;
et.__proto__=es
}var dy="transitionend";
var db=1000000;
var cT=1000;
function aZ(es){if(es===null||typeof es==="undefined"){return""+es
}return{}.toString.call(es).match(/\s([a-z]+)/i)[1].toLowerCase()
}function ec(){return{bindType:dy,delegateType:dy,handle:function es(et){if(d9(et.target).is(this)){return et.handleObj.handler.apply(this,arguments)
}return undefined
}}
}function dg(et){var eu=this;
var es=false;
d9(this).one(dp.TRANSITION_END,function(){es=true
});
setTimeout(function(){if(!es){dp.triggerTransitionEnd(eu)
}},et);
return this
}function P(){d9.fn.emulateTransitionEnd=dg;
d9.event.special[dp.TRANSITION_END]=ec()
}var dp={TRANSITION_END:"bsTransitionEnd",getUID:function cC(es){do{es+=~~(Math.random()*db)
}while(document.getElementById(es));
return es
},getSelectorFromElement:function cn(eu){var et=eu.getAttribute("data-target");
if(!et||et==="#"){var es=eu.getAttribute("href");
et=es&&es!=="#"?es.trim():""
}try{return document.querySelector(et)?et:null
}catch(ev){return null
}},getTransitionDurationFromElement:function ae(ev){if(!ev){return 0
}var es=d9(ev).css("transition-duration");
var et=d9(ev).css("transition-delay");
var eu=parseFloat(es);
var ew=parseFloat(et);
if(!eu&&!ew){return 0
}es=es.split(",")[0];
et=et.split(",")[0];
return(parseFloat(es)+parseFloat(et))*cT
},reflow:function bE(es){return es.offsetHeight
},triggerTransitionEnd:function E(es){d9(es).trigger(dy)
},supportsTransitionEnd:function d7(){return Boolean(dy)
},isElement:function F(es){return(es[0]||es).nodeType
},typeCheckConfig:function dj(es,et,ew){for(var ev in ew){if(Object.prototype.hasOwnProperty.call(ew,ev)){var ey=ew[ev];
var eu=et[ev];
var ex=eu&&dp.isElement(eu)?"element":aZ(eu);
if(!new RegExp(ey).test(ex)){throw new Error(es.toUpperCase()+": "+('Option "'+ev+'" provided type "'+ex+'" ')+('but expected type "'+ey+'".'))
}}}},findShadowRoot:function el(et){if(!document.documentElement.attachShadow){return null
}if(typeof et.getRootNode==="function"){var es=et.getRootNode();
return es instanceof ShadowRoot?es:null
}if(et instanceof ShadowRoot){return et
}if(!et.parentNode){return null
}return dp.findShadowRoot(et.parentNode)
},jQueryDetection:function cR(){if(typeof d9==="undefined"){throw new TypeError("Bootstrap's JavaScript requires jQuery. jQuery must be included before Bootstrap's JavaScript.")
}var es=d9.fn.jquery.split(" ")[0].split(".");
var eu=1;
var et=2;
var ew=9;
var ex=1;
var ev=4;
if(es[0]<et&&es[1]<ew||es[0]===eu&&es[1]===ew&&es[2]<ex||es[0]>=ev){throw new Error("Bootstrap's JavaScript requires at least jQuery v1.9.1 but less than v4.0.0")
}}};
dp.jQueryDetection();
P();
var dl="alert";
var ei="4.5.2";
var cP="bs.alert";
var dG="."+cP;
var cS=".data-api";
var df=d9.fn[dl];
var bh='[data-dismiss="alert"]';
var cX="close"+dG;
var b6="closed"+dG;
var a3="click"+dG+cS;
var dY="alert";
var a0="fade";
var M="show";
var bD=function(){function ex(eD){this._element=eD
}var ey=ex.prototype;
ey.close=function eC(eE){var eD=this._element;
if(eE){eD=this._getRootElement(eE)
}var eF=this._triggerCloseEvent(eD);
if(eF.isDefaultPrevented()){return
}this._removeElement(eD)
};
ey.dispose=function eA(){d9.removeData(this._element,cP);
this._element=null
};
ey._getRootElement=function eB(eE){var eD=dp.getSelectorFromElement(eE);
var eF=false;
if(eD){eF=document.querySelector(eD)
}if(!eF){eF=d9(eE).closest("."+dY)[0]
}return eF
};
ey._triggerCloseEvent=function eu(eD){var eE=d9.Event(cX);
d9(eD).trigger(eE);
return eE
};
ey._removeElement=function ew(eE){var eF=this;
d9(eE).removeClass(M);
if(!d9(eE).hasClass(a0)){this._destroyElement(eE);
return
}var eD=dp.getTransitionDurationFromElement(eE);
d9(eE).one(dp.TRANSITION_END,function(eG){return eF._destroyElement(eE,eG)
}).emulateTransitionEnd(eD)
};
ey._destroyElement=function ev(eD){d9(eD).detach().trigger(b6).remove()
};
ex._jQueryInterface=function et(eD){return this.each(function(){var eE=d9(this);
var eF=eE.data(cP);
if(!eF){eF=new ex(this);
eE.data(cP,eF)
}if(eD==="close"){eF[eD](this)
}})
};
ex._handleDismiss=function ez(eD){return function(eE){if(eE){eE.preventDefault()
}eD.close(this)
}
};
aQ(ex,null,[{key:"VERSION",get:function es(){return ei
}}]);
return ex
}();
d9(document).on(a3,bh,bD._handleDismiss(new bD()));
d9.fn[dl]=bD._jQueryInterface;
d9.fn[dl].Constructor=bD;
d9.fn[dl].noConflict=function(){d9.fn[dl]=df;
return bD._jQueryInterface
};
var d="button";
var D="4.5.2";
var au="bs.button";
var bP="."+au;
var b4=".data-api";
var cA=d9.fn[d];
var bo="active";
var bQ="btn";
var b2="focus";
var bw='[data-toggle^="button"]';
var bv='[data-toggle="buttons"]';
var dm='[data-toggle="button"]';
var cH='[data-toggle="buttons"] .btn';
var br='input:not([type="hidden"])';
var aN=".active";
var bp=".btn";
var c2="click"+bP+b4;
var d8="focus"+bP+b4+" "+("blur"+bP+b4);
var a2="load"+bP+b4;
var g=function(){function eu(ey){this._element=ey
}var et=eu.prototype;
et.toggle=function es(){var eB=true;
var eA=true;
var ey=d9(this._element).closest(bv)[0];
if(ey){var ez=this._element.querySelector(br);
if(ez){if(ez.type==="radio"){if(ez.checked&&this._element.classList.contains(bo)){eB=false
}else{var eC=ey.querySelector(aN);
if(eC){d9(eC).removeClass(bo)
}}}if(eB){if(ez.type==="checkbox"||ez.type==="radio"){ez.checked=!this._element.classList.contains(bo)
}d9(ez).trigger("change")
}ez.focus();
eA=false
}}if(!(this._element.hasAttribute("disabled")||this._element.classList.contains("disabled"))){if(eA){this._element.setAttribute("aria-pressed",!this._element.classList.contains(bo))
}if(eB){d9(this._element).toggleClass(bo)
}}};
et.dispose=function ex(){d9.removeData(this._element,au);
this._element=null
};
eu._jQueryInterface=function ew(ey){return this.each(function(){var ez=d9(this).data(au);
if(!ez){ez=new eu(this);
d9(this).data(au,ez)
}if(ey==="toggle"){ez[ey]()
}})
};
aQ(eu,null,[{key:"VERSION",get:function ev(){return D
}}]);
return eu
}();
d9(document).on(c2,bw,function(et){var es=et.target;
var eu=es;
if(!d9(es).hasClass(bQ)){es=d9(es).closest(bp)[0]
}if(!es||es.hasAttribute("disabled")||es.classList.contains("disabled")){et.preventDefault()
}else{var ev=es.querySelector(br);
if(ev&&(ev.hasAttribute("disabled")||ev.classList.contains("disabled"))){et.preventDefault();
return
}if(eu.tagName!=="LABEL"||ev&&ev.type!=="checkbox"){g._jQueryInterface.call(d9(es),"toggle")
}}}).on(d8,bw,function(et){var es=d9(et.target).closest(bp)[0];
d9(es).toggleClass(b2,/^focus(in)?$/.test(et.type))
});
d9(window).on(a2,function(){var ex=[].slice.call(document.querySelectorAll(cH));
for(var ew=0,es=ex.length;
ew<es;
ew++){var ev=ex[ew];
var eu=ev.querySelector(br);
if(eu.checked||eu.hasAttribute("checked")){ev.classList.add(bo)
}else{ev.classList.remove(bo)
}}ex=[].slice.call(document.querySelectorAll(dm));
for(var ey=0,et=ex.length;
ey<et;
ey++){var ez=ex[ey];
if(ez.getAttribute("aria-pressed")==="true"){ez.classList.add(bo)
}else{ez.classList.remove(bo)
}}});
d9.fn[d]=g._jQueryInterface;
d9.fn[d].Constructor=g;
d9.fn[d].noConflict=function(){d9.fn[d]=cA;
return g._jQueryInterface
};
var b="carousel";
var C="4.5.2";
var at="bs.carousel";
var bO="."+at;
var b3=".data-api";
var cz=d9.fn[b];
var bg=37;
var de=39;
var ac=500;
var a8=40;
var ah={interval:5000,keyboard:true,slide:false,pause:"hover",wrap:true,touch:true};
var bx={interval:"(number|boolean)",keyboard:"boolean",slide:"(boolean|string)",pause:"(string|boolean)",wrap:"boolean",touch:"boolean"};
var cL="next";
var bR="prev";
var l="left";
var T="right";
var c7="slide"+bO;
var bt="slid"+bO;
var bm="keydown"+bO;
var ds="mouseenter"+bO;
var u="mouseleave"+bO;
var en="touchstart"+bO;
var bH="touchmove"+bO;
var aF="touchend"+bO;
var a5="pointerdown"+bO;
var cV="pointerup"+bO;
var aD="dragstart"+bO;
var bC="load"+bO+b3;
var c1="click"+bO+b3;
var K="carousel";
var z="active";
var a1="slide";
var aE="carousel-item-right";
var Q="carousel-item-left";
var c4="carousel-item-next";
var b8="carousel-item-prev";
var dr="pointer-event";
var cj=".active";
var d6=".active.carousel-item";
var dn=".carousel-item";
var d5=".carousel-item img";
var dq=".carousel-item-next, .carousel-item-prev";
var by=".carousel-indicators";
var cq="[data-slide], [data-slide-to]";
var aO='[data-ride="carousel"]';
var bs={TOUCH:"touch",PEN:"pen"};
var aC=function(){function eJ(eP,eO){this._items=null;
this._interval=null;
this._activeElement=null;
this._isPaused=false;
this._isSliding=false;
this.touchTimeout=null;
this.touchStartX=0;
this.touchDeltaX=0;
this._config=this._getConfig(eO);
this._element=eP;
this._indicatorsElement=this._element.querySelector(by);
this._touchSupported="ontouchstart" in document.documentElement||navigator.maxTouchPoints>0;
this._pointerEvent=Boolean(window.PointerEvent||window.MSPointerEvent);
this._addEventListeners()
}var ew=eJ.prototype;
ew.next=function eH(){if(!this._isSliding){this._slide(cL)
}};
ew.nextWhenVisible=function eN(){if(!document.hidden&&d9(this._element).is(":visible")&&d9(this._element).css("visibility")!=="hidden"){this.next()
}};
ew.prev=function eG(){if(!this._isSliding){this._slide(bR)
}};
ew.pause=function ez(eO){if(!eO){this._isPaused=true
}if(this._element.querySelector(dq)){dp.triggerTransitionEnd(this._element);
this.cycle(true)
}clearInterval(this._interval);
this._interval=null
};
ew.cycle=function eD(eO){if(!eO){this._isPaused=false
}if(this._interval){clearInterval(this._interval);
this._interval=null
}if(this._config.interval&&!this._isPaused){this._interval=setInterval((document.visibilityState?this.nextWhenVisible:this.next).bind(this),this._config.interval)
}};
ew.to=function eu(eP){var eR=this;
this._activeElement=this._element.querySelector(d6);
var eO=this._getItemIndex(this._activeElement);
if(eP>this._items.length-1||eP<0){return
}if(this._isSliding){d9(this._element).one(bt,function(){return eR.to(eP)
});
return
}if(eO===eP){this.pause();
this.cycle();
return
}var eQ=eP>eO?cL:bR;
this._slide(eQ,this._items[eP])
};
ew.dispose=function eM(){d9(this._element).off(bO);
d9.removeData(this._element,at);
this._items=null;
this._config=null;
this._element=null;
this._interval=null;
this._isPaused=null;
this._isSliding=null;
this._activeElement=null;
this._indicatorsElement=null
};
ew._getConfig=function ex(eO){eO=k({},ah,eO);
dp.typeCheckConfig(b,eO,bx);
return eO
};
ew._handleSwipe=function eA(){var eO=Math.abs(this.touchDeltaX);
if(eO<=a8){return
}var eP=eO/this.touchDeltaX;
this.touchDeltaX=0;
if(eP>0){this.prev()
}if(eP<0){this.next()
}};
ew._addEventListeners=function ev(){var eO=this;
if(this._config.keyboard){d9(this._element).on(bm,function(eP){return eO._keydown(eP)
})
}if(this._config.pause==="hover"){d9(this._element).on(ds,function(eP){return eO.pause(eP)
}).on(u,function(eP){return eO.cycle(eP)
})
}if(this._config.touch){this._addTouchEventListeners()
}};
ew._addTouchEventListeners=function ey(){var eQ=this;
if(!this._touchSupported){return
}var eR=function eR(eS){if(eQ._pointerEvent&&bs[eS.originalEvent.pointerType.toUpperCase()]){eQ.touchStartX=eS.originalEvent.clientX
}else{if(!eQ._pointerEvent){eQ.touchStartX=eS.originalEvent.touches[0].clientX
}}};
var eP=function eP(eS){if(eS.originalEvent.touches&&eS.originalEvent.touches.length>1){eQ.touchDeltaX=0
}else{eQ.touchDeltaX=eS.originalEvent.touches[0].clientX-eQ.touchStartX
}};
var eO=function eO(eS){if(eQ._pointerEvent&&bs[eS.originalEvent.pointerType.toUpperCase()]){eQ.touchDeltaX=eS.originalEvent.clientX-eQ.touchStartX
}eQ._handleSwipe();
if(eQ._config.pause==="hover"){eQ.pause();
if(eQ.touchTimeout){clearTimeout(eQ.touchTimeout)
}eQ.touchTimeout=setTimeout(function(eT){return eQ.cycle(eT)
},ac+eQ._config.interval)
}};
d9(this._element.querySelectorAll(d5)).on(aD,function(eS){return eS.preventDefault()
});
if(this._pointerEvent){d9(this._element).on(a5,function(eS){return eR(eS)
});
d9(this._element).on(cV,function(eS){return eO(eS)
});
this._element.classList.add(dr)
}else{d9(this._element).on(en,function(eS){return eR(eS)
});
d9(this._element).on(bH,function(eS){return eP(eS)
});
d9(this._element).on(aF,function(eS){return eO(eS)
})
}};
ew._keydown=function es(eO){if(/input|textarea/i.test(eO.target.tagName)){return
}switch(eO.which){case bg:eO.preventDefault();
this.prev();
break;
case de:eO.preventDefault();
this.next();
break
}};
ew._getItemIndex=function eL(eO){this._items=eO&&eO.parentNode?[].slice.call(eO.parentNode.querySelectorAll(dn)):[];
return this._items.indexOf(eO)
};
ew._getItemByDirection=function et(eU,eP){var eR=eU===cL;
var eT=eU===bR;
var eW=this._getItemIndex(eP);
var eS=this._items.length-1;
var eQ=eT&&eW===0||eR&&eW===eS;
if(eQ&&!this._config.wrap){return eP
}var eV=eU===bR?-1:1;
var eO=(eW+eV)%this._items.length;
return eO===-1?this._items[this._items.length-1]:this._items[eO]
};
ew._triggerSlideEvent=function eI(eP,eS){var eQ=this._getItemIndex(eP);
var eR=this._getItemIndex(this._element.querySelector(d6));
var eO=d9.Event(c7,{relatedTarget:eP,direction:eS,from:eR,to:eQ});
d9(this._element).trigger(eO);
return eO
};
ew._setActiveIndicatorElement=function eB(eP){if(this._indicatorsElement){var eQ=[].slice.call(this._indicatorsElement.querySelectorAll(cj));
d9(eQ).removeClass(z);
var eO=this._indicatorsElement.children[this._getItemIndex(eP)];
if(eO){d9(eO).addClass(z)
}}};
ew._slide=function eF(e1,eV){var eW=this;
var eP=this._element.querySelector(d6);
var e0=this._getItemIndex(eP);
var eZ=eV||eP&&this._getItemByDirection(e1,eP);
var eU=this._getItemIndex(eZ);
var eX=Boolean(this._interval);
var eT;
var eS;
var eQ;
if(e1===cL){eT=Q;
eS=c4;
eQ=l
}else{eT=aE;
eS=b8;
eQ=T
}if(eZ&&d9(eZ).hasClass(z)){this._isSliding=false;
return
}var eO=this._triggerSlideEvent(eZ,eQ);
if(eO.isDefaultPrevented()){return
}if(!eP||!eZ){return
}this._isSliding=true;
if(eX){this.pause()
}this._setActiveIndicatorElement(eZ);
var e2=d9.Event(bt,{relatedTarget:eZ,direction:eQ,from:e0,to:eU});
if(d9(this._element).hasClass(a1)){d9(eZ).addClass(eS);
dp.reflow(eZ);
d9(eP).addClass(eT);
d9(eZ).addClass(eT);
var eY=parseInt(eZ.getAttribute("data-interval"),10);
if(eY){this._config.defaultInterval=this._config.defaultInterval||this._config.interval;
this._config.interval=eY
}else{this._config.interval=this._config.defaultInterval||this._config.interval
}var eR=dp.getTransitionDurationFromElement(eP);
d9(eP).one(dp.TRANSITION_END,function(){d9(eZ).removeClass(eT+" "+eS).addClass(z);
d9(eP).removeClass(z+" "+eS+" "+eT);
eW._isSliding=false;
setTimeout(function(){return d9(eW._element).trigger(e2)
},0)
}).emulateTransitionEnd(eR)
}else{d9(eP).removeClass(z);
d9(eZ).addClass(z);
this._isSliding=false;
d9(this._element).trigger(e2)
}if(eX){this.cycle()
}};
eJ._jQueryInterface=function eC(eO){return this.each(function(){var eR=d9(this).data(at);
var eQ=k({},ah,d9(this).data());
if(typeof eO==="object"){eQ=k({},eQ,eO)
}var eP=typeof eO==="string"?eO:eQ.slide;
if(!eR){eR=new eJ(this,eQ);
d9(this).data(at,eR)
}if(typeof eO==="number"){eR.to(eO)
}else{if(typeof eP==="string"){if(typeof eR[eP]==="undefined"){throw new TypeError('No method named "'+eP+'"')
}eR[eP]()
}else{if(eQ.interval&&eQ.ride){eR.pause();
eR.cycle()
}}}})
};
eJ._dataApiClickHandler=function eE(eQ){var eO=dp.getSelectorFromElement(this);
if(!eO){return
}var eS=d9(eO)[0];
if(!eS||!d9(eS).hasClass(K)){return
}var eP=k({},d9(eS).data(),d9(this).data());
var eR=this.getAttribute("data-slide-to");
if(eR){eP.interval=false
}eJ._jQueryInterface.call(d9(eS),eP);
if(eR){d9(eS).data(at).to(eR)
}eQ.preventDefault()
};
aQ(eJ,null,[{key:"VERSION",get:function eK(){return C
}},{key:"Default",get:function eK(){return ah
}}]);
return eJ
}();
d9(document).on(c1,cq,aC._dataApiClickHandler);
d9(window).on(bC,function(){var ev=[].slice.call(document.querySelectorAll(aO));
for(var eu=0,es=ev.length;
eu<es;
eu++){var et=d9(ev[eu]);
aC._jQueryInterface.call(et,et.data())
}});
d9.fn[b]=aC._jQueryInterface;
d9.fn[b].Constructor=aC;
d9.fn[b].noConflict=function(){d9.fn[b]=cz;
return aC._jQueryInterface
};
var er="collapse";
var B="4.5.2";
var ar="bs.collapse";
var bM="."+ar;
var b1=".data-api";
var cy=d9.fn[er];
var d0={toggle:true,parent:""};
var cO={toggle:"boolean",parent:"(string|element)"};
var O="show"+bM;
var di="shown"+bM;
var cl="hide"+bM;
var a="hidden"+bM;
var c0="click"+bM+b1;
var aa="show";
var bj="collapse";
var bT="collapsing";
var dC="collapsed";
var cc="width";
var a9="height";
var bq=".show, .collapsing";
var A='[data-toggle="collapse"]';
var J=function(){function ey(eK,eI){this._isTransitioning=false;
this._element=eK;
this._config=this._getConfig(eI);
this._triggerArray=[].slice.call(document.querySelectorAll('[data-toggle="collapse"][href="#'+eK.id+'"],'+('[data-toggle="collapse"][data-target="#'+eK.id+'"]')));
var eL=[].slice.call(document.querySelectorAll(A));
for(var eJ=0,eH=eL.length;
eJ<eH;
eJ++){var eM=eL[eJ];
var eG=dp.getSelectorFromElement(eM);
var eN=[].slice.call(document.querySelectorAll(eG)).filter(function(eO){return eO===eK
});
if(eG!==null&&eN.length>0){this._selector=eG;
this._triggerArray.push(eM)
}}this._parent=this._config.parent?this._getParent():null;
if(!this._config.parent){this._addAriaAndCollapsedClass(this._element,this._triggerArray)
}if(this._config.toggle){this.toggle()
}}var eA=ey.prototype;
eA.toggle=function ex(){if(d9(this._element).hasClass(aa)){this.hide()
}else{this.show()
}};
eA.show=function eD(){var eN=this;
if(this._isTransitioning||d9(this._element).hasClass(aa)){return
}var eG;
var eL;
if(this._parent){eG=[].slice.call(this._parent.querySelectorAll(bq)).filter(function(eP){if(typeof eN._config.parent==="string"){return eP.getAttribute("data-parent")===eN._config.parent
}return eP.classList.contains(bj)
});
if(eG.length===0){eG=null
}}if(eG){eL=d9(eG).not(this._selector).data(ar);
if(eL&&eL._isTransitioning){return
}}var eM=d9.Event(O);
d9(this._element).trigger(eM);
if(eM.isDefaultPrevented()){return
}if(eG){ey._jQueryInterface.call(d9(eG).not(this._selector),"hide");
if(!eL){d9(eG).data(ar,null)
}}var eK=this._getDimension();
d9(this._element).removeClass(bj).addClass(bT);
this._element.style[eK]=0;
if(this._triggerArray.length){d9(this._triggerArray).removeClass(dC).attr("aria-expanded",true)
}this.setTransitioning(true);
var eI=function eI(){d9(eN._element).removeClass(bT).addClass(bj+" "+aa);
eN._element.style[eK]="";
eN.setTransitioning(false);
d9(eN._element).trigger(di)
};
var eO=eK[0].toUpperCase()+eK.slice(1);
var eH="scroll"+eO;
var eJ=dp.getTransitionDurationFromElement(this._element);
d9(this._element).one(dp.TRANSITION_END,eI).emulateTransitionEnd(eJ);
this._element.style[eK]=this._element[eH]+"px"
};
eA.hide=function ez(){var eP=this;
if(this._isTransitioning||!d9(this._element).hasClass(aa)){return
}var eN=d9.Event(cl);
d9(this._element).trigger(eN);
if(eN.isDefaultPrevented()){return
}var eM=this._getDimension();
this._element.style[eM]=this._element.getBoundingClientRect()[eM]+"px";
dp.reflow(this._element);
d9(this._element).addClass(bT).removeClass(bj+" "+aa);
var eJ=this._triggerArray.length;
if(eJ>0){for(var eO=0;
eO<eJ;
eO++){var eI=this._triggerArray[eO];
var eK=dp.getSelectorFromElement(eI);
if(eK!==null){var eH=d9([].slice.call(document.querySelectorAll(eK)));
if(!eH.hasClass(aa)){d9(eI).addClass(dC).attr("aria-expanded",false)
}}}}this.setTransitioning(true);
var eG=function eG(){eP.setTransitioning(false);
d9(eP._element).removeClass(bT).addClass(bj).trigger(a)
};
this._element.style[eM]="";
var eL=dp.getTransitionDurationFromElement(this._element);
d9(this._element).one(dp.TRANSITION_END,eG).emulateTransitionEnd(eL)
};
eA.setTransitioning=function ev(eG){this._isTransitioning=eG
};
eA.dispose=function eE(){d9.removeData(this._element,ar);
this._config=null;
this._parent=null;
this._element=null;
this._triggerArray=null;
this._isTransitioning=null
};
eA._getConfig=function eC(eG){eG=k({},d0,eG);
eG.toggle=Boolean(eG.toggle);
dp.typeCheckConfig(er,eG,cO);
return eG
};
eA._getDimension=function eF(){var eG=d9(this._element).hasClass(cc);
return eG?cc:a9
};
eA._getParent=function eu(){var eJ=this;
var eI;
if(dp.isElement(this._config.parent)){eI=this._config.parent;
if(typeof this._config.parent.jquery!=="undefined"){eI=this._config.parent[0]
}}else{eI=document.querySelector(this._config.parent)
}var eG='[data-toggle="collapse"][data-parent="'+this._config.parent+'"]';
var eH=[].slice.call(eI.querySelectorAll(eG));
d9(eH).each(function(eL,eK){eJ._addAriaAndCollapsedClass(ey._getTargetFromElement(eK),[eK])
});
return eI
};
eA._addAriaAndCollapsedClass=function ew(eI,eG){var eH=d9(eI).hasClass(aa);
if(eG.length){d9(eG).toggleClass(dC,!eH).attr("aria-expanded",eH)
}};
ey._getTargetFromElement=function eB(eH){var eG=dp.getSelectorFromElement(eH);
return eG?document.querySelector(eG):null
};
ey._jQueryInterface=function et(eG){return this.each(function(){var eJ=d9(this);
var eI=eJ.data(ar);
var eH=k({},d0,eJ.data(),typeof eG==="object"&&eG?eG:{});
if(!eI&&eH.toggle&&typeof eG==="string"&&/show|hide/.test(eG)){eH.toggle=false
}if(!eI){eI=new ey(this,eH);
eJ.data(ar,eI)
}if(typeof eG==="string"){if(typeof eI[eG]==="undefined"){throw new TypeError('No method named "'+eG+'"')
}eI[eG]()
}})
};
aQ(ey,null,[{key:"VERSION",get:function es(){return B
}},{key:"Default",get:function es(){return d0
}}]);
return ey
}();
d9(document).on(c0,A,function(ev){if(ev.currentTarget.tagName==="A"){ev.preventDefault()
}var et=d9(this);
var es=dp.getSelectorFromElement(this);
var eu=[].slice.call(document.querySelectorAll(es));
d9(eu).each(function(){var ew=d9(this);
var ey=ew.data(ar);
var ex=ey?"toggle":et.data();
J._jQueryInterface.call(ew,ex)
})
});
d9.fn[er]=J._jQueryInterface;
d9.fn[er].Constructor=J;
d9.fn[er].noConflict=function(){d9.fn[er]=cy;
return J._jQueryInterface
};
var eq="dropdown";
var y="4.5.2";
var aq="bs.dropdown";
var bL="."+aq;
var b0=".data-api";
var cx=d9.fn[eq];
var m=27;
var bi=32;
var dJ=9;
var c5=38;
var co=40;
var dw=3;
var dM=new RegExp(c5+"|"+co+"|"+m);
var aj="hide"+bL;
var bd="hidden"+bL;
var dx="show"+bL;
var cF="shown"+bL;
var dz="click"+bL;
var cZ="click"+bL+b0;
var ag="keydown"+bL+b0;
var a6="keyup"+bL+b0;
var c6="disabled";
var Z="show";
var bn="dropup";
var b5="dropright";
var L="dropleft";
var ay="dropdown-menu-right";
var I="position-static";
var x='[data-toggle="dropdown"]';
var bf=".dropdown form";
var dE=".dropdown-menu";
var az=".navbar-nav";
var e=".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)";
var aJ="top-start";
var dA="top-end";
var dK="bottom-start";
var dO="bottom-end";
var c3="right-start";
var ce="left-start";
var dZ={offset:0,flip:true,boundary:"scrollParent",reference:"toggle",display:"dynamic",popperConfig:null};
var cN={offset:"(number|string|function)",flip:"boolean",boundary:"(string|element)",reference:"(string|element)",display:"string",popperConfig:"(null|object)"};
var bA=function(){function eH(eM,eL){this._element=eM;
this._popper=null;
this._config=this._getConfig(eL);
this._menu=this._getMenuElement();
this._inNavbar=this._detectNavbar();
this._addEventListeners()
}var ev=eH.prototype;
ev.toggle=function eG(){if(this._element.disabled||d9(this._element).hasClass(c6)){return
}var eL=d9(this._menu).hasClass(Z);
eH._clearMenus();
if(eL){return
}this.show(true)
};
ev.show=function eJ(eO){if(eO===void 0){eO=false
}if(this._element.disabled||d9(this._element).hasClass(c6)||d9(this._menu).hasClass(Z)){return
}var eL={relatedTarget:this._element};
var eM=d9.Event(dx,eL);
var eN=eH._getParentFromElement(this._element);
d9(eN).trigger(eM);
if(eM.isDefaultPrevented()){return
}if(!this._inNavbar&&eO){if(typeof cd==="undefined"){throw new TypeError("Bootstrap's dropdowns require Popper.js (https://popper.js.org/)")
}var eP=this._element;
if(this._config.reference==="parent"){eP=eN
}else{if(dp.isElement(this._config.reference)){eP=this._config.reference;
if(typeof this._config.reference.jquery!=="undefined"){eP=this._config.reference[0]
}}}if(this._config.boundary!=="scrollParent"){d9(eN).addClass(I)
}this._popper=new cd(eP,this._menu,this._getPopperConfig())
}if("ontouchstart" in document.documentElement&&d9(eN).closest(az).length===0){d9(document.body).children().on("mouseover",null,d9.noop)
}this._element.focus();
this._element.setAttribute("aria-expanded",true);
d9(this._menu).toggleClass(Z);
d9(eN).toggleClass(Z).trigger(d9.Event(cF,eL))
};
ev.hide=function eA(){if(this._element.disabled||d9(this._element).hasClass(c6)||!d9(this._menu).hasClass(Z)){return
}var eL={relatedTarget:this._element};
var eN=d9.Event(aj,eL);
var eM=eH._getParentFromElement(this._element);
d9(eM).trigger(eN);
if(eN.isDefaultPrevented()){return
}if(this._popper){this._popper.destroy()
}d9(this._menu).toggleClass(Z);
d9(eM).toggleClass(Z).trigger(d9.Event(bd,eL))
};
ev.dispose=function eK(){d9.removeData(this._element,aq);
d9(this._element).off(bL);
this._element=null;
this._menu=null;
if(this._popper!==null){this._popper.destroy();
this._popper=null
}};
ev.update=function ey(){this._inNavbar=this._detectNavbar();
if(this._popper!==null){this._popper.scheduleUpdate()
}};
ev._addEventListeners=function et(){var eL=this;
d9(this._element).on(dz,function(eM){eM.preventDefault();
eM.stopPropagation();
eL.toggle()
})
};
ev._getConfig=function ew(eL){eL=k({},this.constructor.Default,d9(this._element).data(),eL);
dp.typeCheckConfig(eq,eL,this.constructor.DefaultType);
return eL
};
ev._getMenuElement=function ez(){if(!this._menu){var eL=eH._getParentFromElement(this._element);
if(eL){this._menu=eL.querySelector(dE)
}}return this._menu
};
ev._getPlacement=function eu(){var eL=d9(this._element.parentNode);
var eM=dK;
if(eL.hasClass(bn)){eM=d9(this._menu).hasClass(ay)?dA:aJ
}else{if(eL.hasClass(b5)){eM=c3
}else{if(eL.hasClass(L)){eM=ce
}else{if(d9(this._menu).hasClass(ay)){eM=dO
}}}}return eM
};
ev._detectNavbar=function eF(){return d9(this._element).closest(".navbar").length>0
};
ev._getOffset=function eC(){var eL=this;
var eM={};
if(typeof this._config.offset==="function"){eM.fn=function(eN){eN.offsets=k({},eN.offsets,eL._config.offset(eN.offsets,eL._element)||{});
return eN
}
}else{eM.offset=this._config.offset
}return eM
};
ev._getPopperConfig=function eD(){var eL={placement:this._getPlacement(),modifiers:{offset:this._getOffset(),flip:{enabled:this._config.flip},preventOverflow:{boundariesElement:this._config.boundary}}};
if(this._config.display==="static"){eL.modifiers.applyStyle={enabled:false}
}return k({},eL,this._config.popperConfig)
};
eH._jQueryInterface=function eB(eL){return this.each(function(){var eN=d9(this).data(aq);
var eM=typeof eL==="object"?eL:null;
if(!eN){eN=new eH(this,eM);
d9(this).data(aq,eN)
}if(typeof eL==="string"){if(typeof eN[eL]==="undefined"){throw new TypeError('No method named "'+eL+'"')
}eN[eL]()
}})
};
eH._clearMenus=function ex(eL){if(eL&&(eL.which===dw||eL.type==="keyup"&&eL.which!==dJ)){return
}var eQ=[].slice.call(document.querySelectorAll(x));
for(var eP=0,eR=eQ.length;
eP<eR;
eP++){var eT=eH._getParentFromElement(eQ[eP]);
var eM=d9(eQ[eP]).data(aq);
var eS={relatedTarget:eQ[eP]};
if(eL&&eL.type==="click"){eS.clickEvent=eL
}if(!eM){continue
}var eO=eM._menu;
if(!d9(eT).hasClass(Z)){continue
}if(eL&&(eL.type==="click"&&/input|textarea/i.test(eL.target.tagName)||eL.type==="keyup"&&eL.which===dJ)&&d9.contains(eT,eL.target)){continue
}var eN=d9.Event(aj,eS);
d9(eT).trigger(eN);
if(eN.isDefaultPrevented()){continue
}if("ontouchstart" in document.documentElement){d9(document.body).children().off("mouseover",null,d9.noop)
}eQ[eP].setAttribute("aria-expanded","false");
if(eM._popper){eM._popper.destroy()
}d9(eO).removeClass(Z);
d9(eT).removeClass(Z).trigger(d9.Event(bd,eS))
}};
eH._getParentFromElement=function es(eM){var eN;
var eL=dp.getSelectorFromElement(eM);
if(eL){eN=document.querySelector(eL)
}return eN||eM.parentNode
};
eH._dataApiKeydownHandler=function eE(eP){if(/input|textarea/i.test(eP.target.tagName)?eP.which===bi||eP.which!==m&&(eP.which!==co&&eP.which!==c5||d9(eP.target).closest(dE).length):!dM.test(eP.which)){return
}if(this.disabled||d9(this).hasClass(c6)){return
}var eO=eH._getParentFromElement(this);
var eN=d9(eO).hasClass(Z);
if(!eN&&eP.which===m){return
}eP.preventDefault();
eP.stopPropagation();
if(!eN||eN&&(eP.which===m||eP.which===bi)){if(eP.which===m){d9(eO.querySelector(x)).trigger("focus")
}d9(this).trigger("click");
return
}var eL=[].slice.call(eO.querySelectorAll(e)).filter(function(eQ){return d9(eQ).is(":visible")
});
if(eL.length===0){return
}var eM=eL.indexOf(eP.target);
if(eP.which===c5&&eM>0){eM--
}if(eP.which===co&&eM<eL.length-1){eM++
}if(eM<0){eM=0
}eL[eM].focus()
};
aQ(eH,null,[{key:"VERSION",get:function eI(){return y
}},{key:"Default",get:function eI(){return dZ
}},{key:"DefaultType",get:function eI(){return cN
}}]);
return eH
}();
d9(document).on(ag,x,bA._dataApiKeydownHandler).on(ag,dE,bA._dataApiKeydownHandler).on(cZ+" "+a6,bA._clearMenus).on(cZ,x,function(es){es.preventDefault();
es.stopPropagation();
bA._jQueryInterface.call(d9(this),"toggle")
}).on(cZ,bf,function(es){es.stopPropagation()
});
d9.fn[eq]=bA._jQueryInterface;
d9.fn[eq].Constructor=bA;
d9.fn[eq].noConflict=function(){d9.fn[eq]=cx;
return bA._jQueryInterface
};
var ep="modal";
var v="4.5.2";
var ap="bs.modal";
var bK="."+ap;
var bZ=".data-api";
var cw=d9.fn[ep];
var aw=27;
var dX={backdrop:true,keyboard:true,focus:true,show:true};
var cM={backdrop:"(boolean|string)",keyboard:"boolean",focus:"boolean",show:"boolean"};
var ai="hide"+bK;
var bN="hidePrevented"+bK;
var bb="hidden"+bK;
var dv="show"+bK;
var cE="shown"+bK;
var N="focusin"+bK;
var ax="resize"+bK;
var ca="click.dismiss"+bK;
var d2="keydown.dismiss"+bK;
var ab="mouseup.dismiss"+bK;
var cU="mousedown.dismiss"+bK;
var cY="click"+bK+bZ;
var aL="modal-dialog-scrollable";
var eh="modal-scrollbar-measure";
var a4="modal-backdrop";
var dB="modal-open";
var aY="fade";
var Y="show";
var bk="modal-static";
var dI=".modal-dialog";
var dc=".modal-body";
var t='[data-toggle="modal"]';
var aI='[data-dismiss="modal"]';
var aA=".fixed-top, .fixed-bottom, .is-fixed, .sticky-top";
var i=".sticky-top";
var ee=function(){function es(eR,eQ){this._config=this._getConfig(eQ);
this._element=eR;
this._dialog=eR.querySelector(dI);
this._backdrop=null;
this._isShown=false;
this._isBodyOverflowing=false;
this._ignoreBackdropClick=false;
this._isTransitioning=false;
this._scrollbarWidth=0
}var ev=es.prototype;
ev.toggle=function eJ(eQ){return this._isShown?this.hide():this.show(eQ)
};
ev.show=function eM(eQ){var eS=this;
if(this._isShown||this._isTransitioning){return
}if(d9(this._element).hasClass(aY)){this._isTransitioning=true
}var eR=d9.Event(dv,{relatedTarget:eQ});
d9(this._element).trigger(eR);
if(this._isShown||eR.isDefaultPrevented()){return
}this._isShown=true;
this._checkScrollbar();
this._setScrollbar();
this._adjustDialog();
this._setEscapeEvent();
this._setResizeEvent();
d9(this._element).on(ca,aI,function(eT){return eS.hide(eT)
});
d9(this._dialog).on(cU,function(){d9(eS._element).one(ab,function(eT){if(d9(eT.target).is(eS._element)){eS._ignoreBackdropClick=true
}})
});
this._showBackdrop(function(){return eS._showElement(eQ)
})
};
ev.hide=function eC(eS){var eR=this;
if(eS){eS.preventDefault()
}if(!this._isShown||this._isTransitioning){return
}var eT=d9.Event(ai);
d9(this._element).trigger(eT);
if(!this._isShown||eT.isDefaultPrevented()){return
}this._isShown=false;
var eU=d9(this._element).hasClass(aY);
if(eU){this._isTransitioning=true
}this._setEscapeEvent();
this._setResizeEvent();
d9(document).off(N);
d9(this._element).removeClass(Y);
d9(this._element).off(ca);
d9(this._dialog).off(cU);
if(eU){var eQ=dp.getTransitionDurationFromElement(this._element);
d9(this._element).one(dp.TRANSITION_END,function(eV){return eR._hideModal(eV)
}).emulateTransitionEnd(eQ)
}else{this._hideModal()
}};
ev.dispose=function eO(){[window,this._element,this._dialog].forEach(function(eQ){return d9(eQ).off(bK)
});
d9(document).off(N);
d9.removeData(this._element,ap);
this._config=null;
this._element=null;
this._dialog=null;
this._backdrop=null;
this._isShown=null;
this._isBodyOverflowing=null;
this._ignoreBackdropClick=null;
this._isTransitioning=null;
this._scrollbarWidth=null
};
ev.handleUpdate=function eA(){this._adjustDialog()
};
ev._getConfig=function ew(eQ){eQ=k({},dX,eQ);
dp.typeCheckConfig(ep,eQ,cM);
return eQ
};
ev._triggerBackdropTransition=function eP(){var eR=this;
if(this._config.backdrop==="static"){var eS=d9.Event(bN);
d9(this._element).trigger(eS);
if(eS.defaultPrevented){return
}var eQ=this._element.scrollHeight>document.documentElement.clientHeight;
if(!eQ){this._element.style.overflowY="hidden"
}this._element.classList.add(bk);
var eT=dp.getTransitionDurationFromElement(this._dialog);
d9(this._element).off(dp.TRANSITION_END);
d9(this._element).one(dp.TRANSITION_END,function(){eR._element.classList.remove(bk);
if(!eQ){d9(eR._element).one(dp.TRANSITION_END,function(){eR._element.style.overflowY=""
}).emulateTransitionEnd(eR._element,eT)
}}).emulateTransitionEnd(eT);
this._element.focus()
}else{this.hide()
}};
ev._showElement=function eN(eS){var eV=this;
var eW=d9(this._element).hasClass(aY);
var eT=this._dialog?this._dialog.querySelector(dc):null;
if(!this._element.parentNode||this._element.parentNode.nodeType!==Node.ELEMENT_NODE){document.body.appendChild(this._element)
}this._element.style.display="block";
this._element.removeAttribute("aria-hidden");
this._element.setAttribute("aria-modal",true);
this._element.setAttribute("role","dialog");
if(d9(this._dialog).hasClass(aL)&&eT){eT.scrollTop=0
}else{this._element.scrollTop=0
}if(eW){dp.reflow(this._element)
}d9(this._element).addClass(Y);
if(this._config.focus){this._enforceFocus()
}var eR=d9.Event(cE,{relatedTarget:eS});
var eU=function eU(){if(eV._config.focus){eV._element.focus()
}eV._isTransitioning=false;
d9(eV._element).trigger(eR)
};
if(eW){var eQ=dp.getTransitionDurationFromElement(this._dialog);
d9(this._dialog).one(dp.TRANSITION_END,eU).emulateTransitionEnd(eQ)
}else{eU()
}};
ev._enforceFocus=function eu(){var eQ=this;
d9(document).off(N).on(N,function(eR){if(document!==eR.target&&eQ._element!==eR.target&&d9(eQ._element).has(eR.target).length===0){eQ._element.focus()
}})
};
ev._setEscapeEvent=function ez(){var eQ=this;
if(this._isShown){d9(this._element).on(d2,function(eR){if(eQ._config.keyboard&&eR.which===aw){eR.preventDefault();
eQ.hide()
}else{if(!eQ._config.keyboard&&eR.which===aw){eQ._triggerBackdropTransition()
}}})
}else{if(!this._isShown){d9(this._element).off(d2)
}}};
ev._setResizeEvent=function eF(){var eQ=this;
if(this._isShown){d9(window).on(ax,function(eR){return eQ.handleUpdate(eR)
})
}else{d9(window).off(ax)
}};
ev._hideModal=function eK(){var eQ=this;
this._element.style.display="none";
this._element.setAttribute("aria-hidden",true);
this._element.removeAttribute("aria-modal");
this._element.removeAttribute("role");
this._isTransitioning=false;
this._showBackdrop(function(){d9(document.body).removeClass(dB);
eQ._resetAdjustments();
eQ._resetScrollbar();
d9(eQ._element).trigger(bb)
})
};
ev._removeBackdrop=function ex(){if(this._backdrop){d9(this._backdrop).remove();
this._backdrop=null
}};
ev._showBackdrop=function ey(eV){var eU=this;
var eS=d9(this._element).hasClass(aY)?aY:"";
if(this._isShown&&this._config.backdrop){this._backdrop=document.createElement("div");
this._backdrop.className=a4;
if(eS){this._backdrop.classList.add(eS)
}d9(this._backdrop).appendTo(document.body);
d9(this._element).on(ca,function(eW){if(eU._ignoreBackdropClick){eU._ignoreBackdropClick=false;
return
}if(eW.target!==eW.currentTarget){return
}eU._triggerBackdropTransition()
});
if(eS){dp.reflow(this._backdrop)
}d9(this._backdrop).addClass(Y);
if(!eV){return
}if(!eS){eV();
return
}var eQ=dp.getTransitionDurationFromElement(this._backdrop);
d9(this._backdrop).one(dp.TRANSITION_END,eV).emulateTransitionEnd(eQ)
}else{if(!this._isShown&&this._backdrop){d9(this._backdrop).removeClass(Y);
var eT=function eT(){eU._removeBackdrop();
if(eV){eV()
}};
if(d9(this._element).hasClass(aY)){var eR=dp.getTransitionDurationFromElement(this._backdrop);
d9(this._backdrop).one(dp.TRANSITION_END,eT).emulateTransitionEnd(eR)
}else{eT()
}}else{if(eV){eV()
}}}};
ev._adjustDialog=function eH(){var eQ=this._element.scrollHeight>document.documentElement.clientHeight;
if(!this._isBodyOverflowing&&eQ){this._element.style.paddingLeft=this._scrollbarWidth+"px"
}if(this._isBodyOverflowing&&!eQ){this._element.style.paddingRight=this._scrollbarWidth+"px"
}};
ev._resetAdjustments=function eE(){this._element.style.paddingLeft="";
this._element.style.paddingRight=""
};
ev._checkScrollbar=function eG(){var eQ=document.body.getBoundingClientRect();
this._isBodyOverflowing=Math.round(eQ.left+eQ.right)<window.innerWidth;
this._scrollbarWidth=this._getScrollbarWidth()
};
ev._setScrollbar=function eI(){var eU=this;
if(this._isBodyOverflowing){var eS=[].slice.call(document.querySelectorAll(aA));
var eR=[].slice.call(document.querySelectorAll(i));
d9(eS).each(function(eW,eX){var eV=eX.style.paddingRight;
var eY=d9(eX).css("padding-right");
d9(eX).data("padding-right",eV).css("padding-right",parseFloat(eY)+eU._scrollbarWidth+"px")
});
d9(eR).each(function(eW,eX){var eY=eX.style.marginRight;
var eV=d9(eX).css("margin-right");
d9(eX).data("margin-right",eY).css("margin-right",parseFloat(eV)-eU._scrollbarWidth+"px")
});
var eQ=document.body.style.paddingRight;
var eT=d9(document.body).css("padding-right");
d9(document.body).data("padding-right",eQ).css("padding-right",parseFloat(eT)+this._scrollbarWidth+"px")
}d9(document.body).addClass(dB)
};
ev._resetScrollbar=function eD(){var eQ=[].slice.call(document.querySelectorAll(aA));
d9(eQ).each(function(eT,eU){var eV=d9(eU).data("padding-right");
d9(eU).removeData("padding-right");
eU.style.paddingRight=eV?eV:""
});
var eR=[].slice.call(document.querySelectorAll(""+i));
d9(eR).each(function(eT,eU){var eV=d9(eU).data("margin-right");
if(typeof eV!=="undefined"){d9(eU).css("margin-right",eV).removeData("margin-right")
}});
var eS=d9(document.body).data("padding-right");
d9(document.body).removeData("padding-right");
document.body.style.paddingRight=eS?eS:""
};
ev._getScrollbarWidth=function et(){var eR=document.createElement("div");
eR.className=eh;
document.body.appendChild(eR);
var eQ=eR.getBoundingClientRect().width-eR.clientWidth;
document.body.removeChild(eR);
return eQ
};
es._jQueryInterface=function eB(eR,eQ){return this.each(function(){var eT=d9(this).data(ap);
var eS=k({},dX,d9(this).data(),typeof eR==="object"&&eR?eR:{});
if(!eT){eT=new es(this,eS);
d9(this).data(ap,eT)
}if(typeof eR==="string"){if(typeof eT[eR]==="undefined"){throw new TypeError('No method named "'+eR+'"')
}eT[eR](eQ)
}else{if(eS.show){eT.show(eQ)
}}})
};
aQ(es,null,[{key:"VERSION",get:function eL(){return v
}},{key:"Default",get:function eL(){return dX
}}]);
return es
}();
d9(document).on(cY,t,function(ev){var ew=this;
var ex;
var et=dp.getSelectorFromElement(this);
if(et){ex=document.querySelector(et)
}var eu=d9(ex).data(ap)?"toggle":k({},d9(ex).data(),d9(this).data());
if(this.tagName==="A"||this.tagName==="AREA"){ev.preventDefault()
}var es=d9(ex).one(dv,function(ey){if(ey.isDefaultPrevented()){return
}es.one(bb,function(){if(d9(ew).is(":visible")){ew.focus()
}})
});
ee._jQueryInterface.call(d9(ex),eu,this)
});
d9.fn[ep]=ee._jQueryInterface;
d9.fn[ep].Constructor=ee;
d9.fn[ep].noConflict=function(){d9.fn[ep]=cw;
return ee._jQueryInterface
};
var eg=["background","cite","href","itemtype","longdesc","poster","src","xlink:href"];
var f=/^aria-[\w-]*$/i;
var dR={"*":["class","dir","id","lang","role",f],a:["target","href","title","rel"],area:[],b:[],br:[],col:[],code:[],div:[],em:[],hr:[],h1:[],h2:[],h3:[],h4:[],h5:[],h6:[],i:[],img:["src","srcset","alt","title","width","height"],li:[],ol:[],p:[],pre:[],s:[],small:[],span:[],sub:[],sup:[],strong:[],u:[],ul:[]};
var be=/^(?:(?:https?|mailto|ftp|tel|file):|[^#&/:?]*(?:[#/?]|$))/gi;
var S=/^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[\d+/a-z]+=*$/i;
function c(et,eu){var ex=et.nodeName.toLowerCase();
if(eu.indexOf(ex)!==-1){if(eg.indexOf(ex)!==-1){return Boolean(et.nodeValue.match(be)||et.nodeValue.match(S))
}return true
}var ev=eu.filter(function(ey){return ey instanceof RegExp
});
for(var ew=0,es=ev.length;
ew<es;
ew++){if(ex.match(ev[ew])){return true
}}return false
}function bz(eB,ew,eC){if(eB.length===0){return eB
}if(eC&&typeof eC==="function"){return eC(eB)
}var ez=new window.DOMParser();
var eA=ez.parseFromString(eB,"text/html");
var ex=Object.keys(ew);
var es=[].slice.call(eA.body.querySelectorAll("*"));
var et=function et(eE,eD){var eF=es[eE];
var eI=eF.nodeName.toLowerCase();
if(ex.indexOf(eF.nodeName.toLowerCase())===-1){eF.parentNode.removeChild(eF);
return"continue"
}var eG=[].slice.call(eF.attributes);
var eH=[].concat(ew["*"]||[],ew[eI]||[]);
eG.forEach(function(eJ){if(!c(eJ,eH)){eF.removeAttribute(eJ.nodeName)
}})
};
for(var eu=0,ev=es.length;
eu<ev;
eu++){var ey=et(eu);
if(ey==="continue"){continue
}}return eA.body.innerHTML
}var eo="tooltip";
var r="4.5.2";
var an="bs.tooltip";
var bJ="."+an;
var cv=d9.fn[eo];
var cQ="bs-tooltip";
var cr=new RegExp("(^|\\s)"+cQ+"\\S+","g");
var c9=["sanitize","whiteList","sanitizeFn"];
var cK={animation:"boolean",template:"string",title:"(string|element|function)",trigger:"string",delay:"(number|object)",html:"boolean",selector:"(string|boolean)",placement:"(string|function)",offset:"(number|string|function)",container:"(string|element|boolean)",fallbackPlacement:"(string|array)",boundary:"(string|element)",sanitize:"boolean",sanitizeFn:"(null|function)",whiteList:"object",popperConfig:"(null|object)"};
var bS={AUTO:"auto",TOP:"top",RIGHT:"right",BOTTOM:"bottom",LEFT:"left"};
var dW={animation:true,template:'<div class="tooltip" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>',trigger:"hover focus",title:"",delay:0,html:false,selector:false,placement:"top",offset:0,container:false,fallbackPlacement:"flip",boundary:"scrollParent",sanitize:true,sanitizeFn:null,whiteList:dR,popperConfig:null};
var dk="show";
var bX="out";
var dH={HIDE:"hide"+bJ,HIDDEN:"hidden"+bJ,SHOW:"show"+bJ,SHOWN:"shown"+bJ,INSERTED:"inserted"+bJ,CLICK:"click"+bJ,FOCUSIN:"focusin"+bJ,FOCUSOUT:"focusout"+bJ,MOUSEENTER:"mouseenter"+bJ,MOUSELEAVE:"mouseleave"+bJ};
var aW="fade";
var X="show";
var aK=".tooltip-inner";
var aR=".arrow";
var aH="hover";
var b9="focus";
var bV="click";
var dQ="manual";
var dD=function(){function eR(eZ,eY){if(typeof cd==="undefined"){throw new TypeError("Bootstrap's tooltips require Popper.js (https://popper.js.org/)")
}this._isEnabled=true;
this._timeout=0;
this._hoverState="";
this._activeTrigger={};
this._popper=null;
this.element=eZ;
this.config=this._getConfig(eY);
this.tip=null;
this._setListeners()
}var ew=eR.prototype;
ew.enable=function eJ(){this._isEnabled=true
};
ew.disable=function eu(){this._isEnabled=false
};
ew.toggleEnabled=function eE(){this._isEnabled=!this._isEnabled
};
ew.toggle=function eO(eZ){if(!this._isEnabled){return
}if(eZ){var e0=this.constructor.DATA_KEY;
var eY=d9(eZ.currentTarget).data(e0);
if(!eY){eY=new this.constructor(eZ.currentTarget,this._getDelegateConfig());
d9(eZ.currentTarget).data(e0,eY)
}eY._activeTrigger.click=!eY._activeTrigger.click;
if(eY._isWithActiveTrigger()){eY._enter(null,eY)
}else{eY._leave(null,eY)
}}else{if(d9(this.getTipElement()).hasClass(X)){this._leave(null,this);
return
}this._enter(null,this)
}};
ew.dispose=function eX(){clearTimeout(this._timeout);
d9.removeData(this.element,this.constructor.DATA_KEY);
d9(this.element).off(this.constructor.EVENT_KEY);
d9(this.element).closest(".modal").off("hide.bs.modal",this._hideModalHandler);
if(this.tip){d9(this.tip).remove()
}this._isEnabled=null;
this._timeout=null;
this._hoverState=null;
this._activeTrigger=null;
if(this._popper){this._popper.destroy()
}this._popper=null;
this.element=null;
this.config=null;
this.tip=null
};
ew.show=function eU(){var e5=this;
if(d9(this.element).css("display")==="none"){throw new Error("Please use show on visible elements")
}var e6=d9.Event(this.constructor.Event.SHOW);
if(this.isWithContent()&&this._isEnabled){d9(this.element).trigger(e6);
var e8=dp.findShadowRoot(this.element);
var e1=d9.contains(e8!==null?e8:this.element.ownerDocument.documentElement,this.element);
if(e6.isDefaultPrevented()||!e1){return
}var e7=this.getTipElement();
var e0=dp.getUID(this.constructor.NAME);
e7.setAttribute("id",e0);
this.element.setAttribute("aria-describedby",e0);
this.setContent();
if(this.config.animation){d9(e7).addClass(aW)
}var e3=typeof this.config.placement==="function"?this.config.placement.call(this,e7,this.element):this.config.placement;
var e4=this._getAttachment(e3);
this.addAttachmentClass(e4);
var eY=this._getContainer();
d9(e7).data(this.constructor.DATA_KEY,this);
if(!d9.contains(this.element.ownerDocument.documentElement,this.tip)){d9(e7).appendTo(eY)
}d9(this.element).trigger(this.constructor.Event.INSERTED);
this._popper=new cd(this.element,e7,this._getPopperConfig(e4));
d9(e7).addClass(X);
if("ontouchstart" in document.documentElement){d9(document.body).children().on("mouseover",null,d9.noop)
}var eZ=function eZ(){if(e5.config.animation){e5._fixTransition()
}var e9=e5._hoverState;
e5._hoverState=null;
d9(e5.element).trigger(e5.constructor.Event.SHOWN);
if(e9===bX){e5._leave(null,e5)
}};
if(d9(this.tip).hasClass(aW)){var e2=dp.getTransitionDurationFromElement(this.tip);
d9(this.tip).one(dp.TRANSITION_END,eZ).emulateTransitionEnd(e2)
}else{eZ()
}}};
ew.hide=function eI(e3){var e0=this;
var e1=this.getTipElement();
var e2=d9.Event(this.constructor.Event.HIDE);
var eZ=function eZ(){if(e0._hoverState!==dk&&e1.parentNode){e1.parentNode.removeChild(e1)
}e0._cleanTipClass();
e0.element.removeAttribute("aria-describedby");
d9(e0.element).trigger(e0.constructor.Event.HIDDEN);
if(e0._popper!==null){e0._popper.destroy()
}if(e3){e3()
}};
d9(this.element).trigger(e2);
if(e2.isDefaultPrevented()){return
}d9(e1).removeClass(X);
if("ontouchstart" in document.documentElement){d9(document.body).children().off("mouseover",null,d9.noop)
}this._activeTrigger[bV]=false;
this._activeTrigger[b9]=false;
this._activeTrigger[aH]=false;
if(d9(this.tip).hasClass(aW)){var eY=dp.getTransitionDurationFromElement(e1);
d9(e1).one(dp.TRANSITION_END,eZ).emulateTransitionEnd(eY)
}else{eZ()
}this._hoverState=""
};
ew.update=function eB(){if(this._popper!==null){this._popper.scheduleUpdate()
}};
ew.isWithContent=function eP(){return Boolean(this.getTitle())
};
ew.addAttachmentClass=function eD(eY){d9(this.getTipElement()).addClass(cQ+"-"+eY)
};
ew.getTipElement=function eS(){this.tip=this.tip||d9(this.config.template)[0];
return this.tip
};
ew.setContent=function ez(){var eY=this.getTipElement();
this.setElementContent(d9(eY.querySelectorAll(aK)),this.getTitle());
d9(eY).removeClass(aW+" "+X)
};
ew.setElementContent=function eN(eY,eZ){if(typeof eZ==="object"&&(eZ.nodeType||eZ.jquery)){if(this.config.html){if(!d9(eZ).parent().is(eY)){eY.empty().append(eZ)
}}else{eY.text(d9(eZ).text())
}return
}if(this.config.html){if(this.config.sanitize){eZ=bz(eZ,this.config.whiteList,this.config.sanitizeFn)
}eY.html(eZ)
}else{eY.text(eZ)
}};
ew.getTitle=function eF(){var eY=this.element.getAttribute("data-original-title");
if(!eY){eY=typeof this.config.title==="function"?this.config.title.call(this.element):this.config.title
}return eY
};
ew._getPopperConfig=function eM(e2){var e0=this;
var eZ={placement:e2,modifiers:{offset:this._getOffset(),flip:{behavior:this.config.fallbackPlacement},arrow:{element:aR},preventOverflow:{boundariesElement:this.config.boundary}},onCreate:function e1(e3){if(e3.originalPlacement!==e3.placement){e0._handlePopperPlacementChange(e3)
}},onUpdate:function eY(e3){return e0._handlePopperPlacementChange(e3)
}};
return k({},eZ,this.config.popperConfig)
};
ew._getOffset=function eL(){var eY=this;
var eZ={};
if(typeof this.config.offset==="function"){eZ.fn=function(e0){e0.offsets=k({},e0.offsets,eY.config.offset(e0.offsets,eY.element)||{});
return e0
}
}else{eZ.offset=this.config.offset
}return eZ
};
ew._getContainer=function et(){if(this.config.container===false){return document.body
}if(dp.isElement(this.config.container)){return d9(this.config.container)
}return d9(document).find(this.config.container)
};
ew._getAttachment=function eW(eY){return bS[eY.toUpperCase()]
};
ew._setListeners=function eQ(){var eY=this;
var eZ=this.config.trigger.split(" ");
eZ.forEach(function(e1){if(e1==="click"){d9(eY.element).on(eY.constructor.Event.CLICK,eY.config.selector,function(e3){return eY.toggle(e3)
})
}else{if(e1!==dQ){var e2=e1===aH?eY.constructor.Event.MOUSEENTER:eY.constructor.Event.FOCUSIN;
var e0=e1===aH?eY.constructor.Event.MOUSELEAVE:eY.constructor.Event.FOCUSOUT;
d9(eY.element).on(e2,eY.config.selector,function(e3){return eY._enter(e3)
}).on(e0,eY.config.selector,function(e3){return eY._leave(e3)
})
}}});
this._hideModalHandler=function(){if(eY.element){eY.hide()
}};
d9(this.element).closest(".modal").on("hide.bs.modal",this._hideModalHandler);
if(this.config.selector){this.config=k({},this.config,{trigger:"manual",selector:""})
}else{this._fixTitle()
}};
ew._fixTitle=function eA(){var eY=typeof this.element.getAttribute("data-original-title");
if(this.element.getAttribute("title")||eY!=="string"){this.element.setAttribute("data-original-title",this.element.getAttribute("title")||"");
this.element.setAttribute("title","")
}};
ew._enter=function eC(eZ,eY){var e0=this.constructor.DATA_KEY;
eY=eY||d9(eZ.currentTarget).data(e0);
if(!eY){eY=new this.constructor(eZ.currentTarget,this._getDelegateConfig());
d9(eZ.currentTarget).data(e0,eY)
}if(eZ){eY._activeTrigger[eZ.type==="focusin"?b9:aH]=true
}if(d9(eY.getTipElement()).hasClass(X)||eY._hoverState===dk){eY._hoverState=dk;
return
}clearTimeout(eY._timeout);
eY._hoverState=dk;
if(!eY.config.delay||!eY.config.delay.show){eY.show();
return
}eY._timeout=setTimeout(function(){if(eY._hoverState===dk){eY.show()
}},eY.config.delay.show)
};
ew._leave=function eV(eZ,eY){var e0=this.constructor.DATA_KEY;
eY=eY||d9(eZ.currentTarget).data(e0);
if(!eY){eY=new this.constructor(eZ.currentTarget,this._getDelegateConfig());
d9(eZ.currentTarget).data(e0,eY)
}if(eZ){eY._activeTrigger[eZ.type==="focusout"?b9:aH]=false
}if(eY._isWithActiveTrigger()){return
}clearTimeout(eY._timeout);
eY._hoverState=bX;
if(!eY.config.delay||!eY.config.delay.hide){eY.hide();
return
}eY._timeout=setTimeout(function(){if(eY._hoverState===bX){eY.hide()
}},eY.config.delay.hide)
};
ew._isWithActiveTrigger=function ev(){for(var eY in this._activeTrigger){if(this._activeTrigger[eY]){return true
}}return false
};
ew._getConfig=function ex(eY){var eZ=d9(this.element).data();
Object.keys(eZ).forEach(function(e0){if(c9.indexOf(e0)!==-1){delete eZ[e0]
}});
eY=k({},this.constructor.Default,eZ,typeof eY==="object"&&eY?eY:{});
if(typeof eY.delay==="number"){eY.delay={show:eY.delay,hide:eY.delay}
}if(typeof eY.title==="number"){eY.title=eY.title.toString()
}if(typeof eY.content==="number"){eY.content=eY.content.toString()
}dp.typeCheckConfig(eo,eY,this.constructor.DefaultType);
if(eY.sanitize){eY.template=bz(eY.template,eY.whiteList,eY.sanitizeFn)
}return eY
};
ew._getDelegateConfig=function eH(){var eY={};
if(this.config){for(var eZ in this.config){if(this.constructor.Default[eZ]!==this.config[eZ]){eY[eZ]=this.config[eZ]
}}}return eY
};
ew._cleanTipClass=function eK(){var eZ=d9(this.getTipElement());
var eY=eZ.attr("class").match(cr);
if(eY!==null&&eY.length){eZ.removeClass(eY.join(""))
}};
ew._handlePopperPlacementChange=function ey(eY){this.tip=eY.instance.popper;
this._cleanTipClass();
this.addAttachmentClass(this._getAttachment(eY.placement))
};
ew._fixTransition=function es(){var eZ=this.getTipElement();
var eY=this.config.animation;
if(eZ.getAttribute("x-placement")!==null){return
}d9(eZ).removeClass(aW);
this.config.animation=false;
this.hide();
this.show();
this.config.animation=eY
};
eR._jQueryInterface=function eG(eY){return this.each(function(){var e0=d9(this).data(an);
var eZ=typeof eY==="object"&&eY;
if(!e0&&/dispose|hide/.test(eY)){return
}if(!e0){e0=new eR(this,eZ);
d9(this).data(an,e0)
}if(typeof eY==="string"){if(typeof e0[eY]==="undefined"){throw new TypeError('No method named "'+eY+'"')
}e0[eY]()
}})
};
aQ(eR,null,[{key:"VERSION",get:function eT(){return r
}},{key:"Default",get:function eT(){return dW
}},{key:"NAME",get:function eT(){return eo
}},{key:"DATA_KEY",get:function eT(){return an
}},{key:"Event",get:function eT(){return dH
}},{key:"EVENT_KEY",get:function eT(){return bJ
}},{key:"DefaultType",get:function eT(){return cK
}}]);
return eR
}();
d9.fn[eo]=dD._jQueryInterface;
d9.fn[eo].Constructor=dD;
d9.fn[eo].noConflict=function(){d9.fn[eo]=cv;
return dD._jQueryInterface
};
var em="popover";
var p="4.5.2";
var am="bs.popover";
var bI="."+am;
var cu=d9.fn[em];
var G="bs-popover";
var d1=new RegExp("(^|\\s)"+G+"\\S+","g");
var dV=k({},dD.Default,{placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>'});
var cJ=k({},dD.DefaultType,{content:"(string|element|function)"});
var aV="fade";
var W="show";
var av=".popover-header";
var aM=".popover-body";
var ef={HIDE:"hide"+bI,HIDDEN:"hidden"+bI,SHOW:"show"+bI,SHOWN:"shown"+bI,INSERTED:"inserted"+bI,CLICK:"click"+bI,FOCUSIN:"focusin"+bI,FOCUSOUT:"focusout"+bI,MOUSEENTER:"mouseenter"+bI,MOUSELEAVE:"mouseleave"+bI};
var dS=function(eA){ch(ew,eA);
function ew(){return eA.apply(this,arguments)||this
}var eB=ew.prototype;
eB.isWithContent=function ey(){return this.getTitle()||this._getContent()
};
eB.addAttachmentClass=function eC(eD){d9(this.getTipElement()).addClass(G+"-"+eD)
};
eB.getTipElement=function ex(){this.tip=this.tip||d9(this.config.template)[0];
return this.tip
};
eB.setContent=function eu(){var eE=d9(this.getTipElement());
this.setElementContent(eE.find(av),this.getTitle());
var eD=this._getContent();
if(typeof eD==="function"){eD=eD.call(this.element)
}this.setElementContent(eE.find(aM),eD);
eE.removeClass(aV+" "+W)
};
eB._getContent=function ez(){return this.element.getAttribute("data-content")||this.config.content
};
eB._cleanTipClass=function et(){var eE=d9(this.getTipElement());
var eD=eE.attr("class").match(d1);
if(eD!==null&&eD.length>0){eE.removeClass(eD.join(""))
}};
ew._jQueryInterface=function ev(eD){return this.each(function(){var eF=d9(this).data(am);
var eE=typeof eD==="object"?eD:null;
if(!eF&&/dispose|hide/.test(eD)){return
}if(!eF){eF=new ew(this,eE);
d9(this).data(am,eF)
}if(typeof eD==="string"){if(typeof eF[eD]==="undefined"){throw new TypeError('No method named "'+eD+'"')
}eF[eD]()
}})
};
aQ(ew,null,[{key:"VERSION",get:function es(){return p
}},{key:"Default",get:function es(){return dV
}},{key:"NAME",get:function es(){return em
}},{key:"DATA_KEY",get:function es(){return am
}},{key:"Event",get:function es(){return ef
}},{key:"EVENT_KEY",get:function es(){return bI
}},{key:"DefaultType",get:function es(){return cJ
}}]);
return ew
}(dD);
d9.fn[em]=dS._jQueryInterface;
d9.fn[em].Constructor=dS;
d9.fn[em].noConflict=function(){d9.fn[em]=cu;
return dS._jQueryInterface
};
var ek="scrollspy";
var o="4.5.2";
var al="bs.scrollspy";
var bG="."+al;
var bY=".data-api";
var ct=d9.fn[ek];
var dU={offset:10,method:"auto",target:""};
var cI={offset:"number",method:"string",target:"(string|element)"};
var bc="activate"+bG;
var h="scroll"+bG;
var bB="load"+bG+bY;
var ao="dropdown-item";
var w="active";
var dh='[data-spy="scroll"]';
var bl=".nav, .list-group";
var cp=".nav-link";
var dd=".nav-item";
var bU=".list-group-item";
var R=".dropdown";
var d4=".dropdown-item";
var c8=".dropdown-toggle";
var ea="offset";
var dN="position";
var dL=function(){function ex(eG,eF){var eH=this;
this._element=eG;
this._scrollElement=eG.tagName==="BODY"?window:eG;
this._config=this._getConfig(eF);
this._selector=this._config.target+" "+cp+","+(this._config.target+" "+bU+",")+(this._config.target+" "+d4);
this._offsets=[];
this._targets=[];
this._activeTarget=null;
this._scrollHeight=0;
d9(this._scrollElement).on(h,function(eI){return eH._process(eI)
});
this.refresh();
this._process()
}var eB=ex.prototype;
eB.refresh=function eA(){var eJ=this;
var eH=this._scrollElement===this._scrollElement.window?ea:dN;
var eF=this._config.method==="auto"?eH:this._config.method;
var eI=eF===dN?this._getScrollTop():0;
this._offsets=[];
this._targets=[];
this._scrollHeight=this._getScrollHeight();
var eG=[].slice.call(document.querySelectorAll(this._selector));
eG.map(function(eK){var eN;
var eL=dp.getSelectorFromElement(eK);
if(eL){eN=document.querySelector(eL)
}if(eN){var eM=eN.getBoundingClientRect();
if(eM.width||eM.height){return[d9(eN)[eF]().top+eI,eL]
}}return null
}).filter(function(eK){return eK
}).sort(function(eL,eK){return eL[0]-eK[0]
}).forEach(function(eK){eJ._offsets.push(eK[0]);
eJ._targets.push(eK[1])
})
};
eB.dispose=function eE(){d9.removeData(this._element,al);
d9(this._scrollElement).off(bG);
this._element=null;
this._scrollElement=null;
this._config=null;
this._selector=null;
this._offsets=null;
this._targets=null;
this._activeTarget=null;
this._scrollHeight=null
};
eB._getConfig=function eC(eF){eF=k({},dU,typeof eF==="object"&&eF?eF:{});
if(typeof eF.target!=="string"&&dp.isElement(eF.target)){var eG=d9(eF.target).attr("id");
if(!eG){eG=dp.getUID(ek);
d9(eF.target).attr("id",eG)
}eF.target="#"+eG
}dp.typeCheckConfig(ek,eF,cI);
return eF
};
eB._getScrollTop=function eD(){return this._scrollElement===window?this._scrollElement.pageYOffset:this._scrollElement.scrollTop
};
eB._getScrollHeight=function et(){return this._scrollElement.scrollHeight||Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)
};
eB._getOffsetHeight=function ev(){return this._scrollElement===window?window.innerHeight:this._scrollElement.getBoundingClientRect().height
};
eB._process=function es(){var eK=this._getScrollTop()+this._config.offset;
var eG=this._getScrollHeight();
var eH=this._config.offset+eG-this._getOffsetHeight();
if(this._scrollHeight!==eG){this.refresh()
}if(eK>=eH){var eJ=this._targets[this._targets.length-1];
if(this._activeTarget!==eJ){this._activate(eJ)
}return
}if(this._activeTarget&&eK<this._offsets[0]&&this._offsets[0]>0){this._activeTarget=null;
this._clear();
return
}for(var eF=this._offsets.length;
eF--;
){var eI=this._activeTarget!==this._targets[eF]&&eK>=this._offsets[eF]&&(typeof this._offsets[eF+1]==="undefined"||eK<this._offsets[eF+1]);
if(eI){this._activate(this._targets[eF])
}}};
eB._activate=function ey(eH){this._activeTarget=eH;
this._clear();
var eG=this._selector.split(",").map(function(eI){return eI+'[data-target="'+eH+'"],'+eI+'[href="'+eH+'"]'
});
var eF=d9([].slice.call(document.querySelectorAll(eG.join(","))));
if(eF.hasClass(ao)){eF.closest(R).find(c8).addClass(w);
eF.addClass(w)
}else{eF.addClass(w);
eF.parents(bl).prev(cp+", "+bU).addClass(w);
eF.parents(bl).prev(dd).children(cp).addClass(w)
}d9(this._scrollElement).trigger(bc,{relatedTarget:eH})
};
eB._clear=function ez(){[].slice.call(document.querySelectorAll(this._selector)).filter(function(eF){return eF.classList.contains(w)
}).forEach(function(eF){return eF.classList.remove(w)
})
};
ex._jQueryInterface=function ew(eF){return this.each(function(){var eH=d9(this).data(al);
var eG=typeof eF==="object"&&eF;
if(!eH){eH=new ex(this,eG);
d9(this).data(al,eH)
}if(typeof eF==="string"){if(typeof eH[eF]==="undefined"){throw new TypeError('No method named "'+eF+'"')
}eH[eF]()
}})
};
aQ(ex,null,[{key:"VERSION",get:function eu(){return o
}},{key:"Default",get:function eu(){return dU
}}]);
return ex
}();
d9(window).on(bB,function(){var eu=[].slice.call(document.querySelectorAll(dh));
var et=eu.length;
for(var es=et;
es--;
){var ev=d9(eu[es]);
dL._jQueryInterface.call(ev,ev.data())
}});
d9.fn[ek]=dL._jQueryInterface;
d9.fn[ek].Constructor=dL;
d9.fn[ek].noConflict=function(){d9.fn[ek]=ct;
return dL._jQueryInterface
};
var ej="tab";
var n="4.5.2";
var ak="bs.tab";
var bF="."+ak;
var bW=".data-api";
var cs=d9.fn[ej];
var af="hide"+bF;
var ba="hidden"+bF;
var du="show"+bF;
var cD="shown"+bF;
var cW="click"+bF+bW;
var aG="dropdown-menu";
var s="active";
var aT="disabled";
var aU="fade";
var V="show";
var b7=".dropdown";
var j=".nav, .list-group";
var ci=".active";
var cf="> li > .active";
var q='[data-toggle="tab"], [data-toggle="pill"], [data-toggle="list"]';
var aB=".dropdown-toggle";
var aP="> .dropdown-menu .active";
var da=function(){function eu(eA){this._element=eA
}var et=eu.prototype;
et.show=function es(){var eF=this;
if(this._element.parentNode&&this._element.parentNode.nodeType===Node.ELEMENT_NODE&&d9(this._element).hasClass(s)||d9(this._element).hasClass(aT)){return
}var eG;
var eE;
var eI=d9(this._element).closest(j)[0];
var eD=dp.getSelectorFromElement(this._element);
if(eI){var eB=eI.nodeName==="UL"||eI.nodeName==="OL"?cf:ci;
eE=d9.makeArray(d9(eI).find(eB));
eE=eE[eE.length-1]
}var eC=d9.Event(af,{relatedTarget:this._element});
var eH=d9.Event(du,{relatedTarget:eE});
if(eE){d9(eE).trigger(eC)
}d9(this._element).trigger(eH);
if(eH.isDefaultPrevented()||eC.isDefaultPrevented()){return
}if(eD){eG=document.querySelector(eD)
}this._activate(this._element,eI);
var eA=function eA(){var eK=d9.Event(ba,{relatedTarget:eF._element});
var eJ=d9.Event(cD,{relatedTarget:eE});
d9(eE).trigger(eK);
d9(eF._element).trigger(eJ)
};
if(eG){this._activate(eG,eG.parentNode,eA)
}else{eA()
}};
et.dispose=function ez(){d9.removeData(this._element,ak);
this._element=null
};
et._activate=function ey(eF,eB,eH){var eG=this;
var eI=eB&&(eB.nodeName==="UL"||eB.nodeName==="OL")?d9(eB).find(cf):d9(eB).children(ci);
var eD=eI[0];
var eA=eH&&eD&&d9(eD).hasClass(aU);
var eC=function eC(){return eG._transitionComplete(eF,eD,eH)
};
if(eD&&eA){var eE=dp.getTransitionDurationFromElement(eD);
d9(eD).removeClass(V).one(dp.TRANSITION_END,eC).emulateTransitionEnd(eE)
}else{eC()
}};
et._transitionComplete=function ex(eA,eD,eF){if(eD){d9(eD).removeClass(s);
var eE=d9(eD.parentNode).find(aP)[0];
if(eE){d9(eE).removeClass(s)
}if(eD.getAttribute("role")==="tab"){eD.setAttribute("aria-selected",false)
}}d9(eA).addClass(s);
if(eA.getAttribute("role")==="tab"){eA.setAttribute("aria-selected",true)
}dp.reflow(eA);
if(eA.classList.contains(aU)){eA.classList.add(V)
}if(eA.parentNode&&d9(eA.parentNode).hasClass(aG)){var eC=d9(eA).closest(b7)[0];
if(eC){var eB=[].slice.call(eC.querySelectorAll(aB));
d9(eB).addClass(s)
}eA.setAttribute("aria-expanded",true)
}if(eF){eF()
}};
eu._jQueryInterface=function ew(eA){return this.each(function(){var eC=d9(this);
var eB=eC.data(ak);
if(!eB){eB=new eu(this);
eC.data(ak,eB)
}if(typeof eA==="string"){if(typeof eB[eA]==="undefined"){throw new TypeError('No method named "'+eA+'"')
}eB[eA]()
}})
};
aQ(eu,null,[{key:"VERSION",get:function ev(){return n
}}]);
return eu
}();
d9(document).on(cW,q,function(es){es.preventDefault();
da._jQueryInterface.call(d9(this),"show")
});
d9.fn[ej]=da._jQueryInterface;
d9.fn[ej].Constructor=da;
d9.fn[ej].noConflict=function(){d9.fn[ej]=cs;
return da._jQueryInterface
};
var d3="toast";
var ed="4.5.2";
var H="bs.toast";
var bu="."+H;
var cg=d9.fn[d3];
var dP="click.dismiss"+bu;
var ad="hide"+bu;
var a7="hidden"+bu;
var dt="show"+bu;
var cB="shown"+bu;
var aS="fade";
var ck="hide";
var U="show";
var dF="showing";
var cG={animation:"boolean",autohide:"boolean",delay:"number"};
var dT={animation:true,autohide:true,delay:500};
var eb='[data-dismiss="toast"]';
var cb=function(){function ez(eE,eD){this._element=eE;
this._config=this._getConfig(eD);
this._timeout=null;
this._setListeners()
}var ew=ez.prototype;
ew.show=function eA(){var eG=this;
var eF=d9.Event(dt);
d9(this._element).trigger(eF);
if(eF.isDefaultPrevented()){return
}this._clearTimeout();
if(this._config.animation){this._element.classList.add(aS)
}var eE=function eE(){eG._element.classList.remove(dF);
eG._element.classList.add(U);
d9(eG._element).trigger(cB);
if(eG._config.autohide){eG._timeout=setTimeout(function(){eG.hide()
},eG._config.delay)
}};
this._element.classList.remove(ck);
dp.reflow(this._element);
this._element.classList.add(dF);
if(this._config.animation){var eD=dp.getTransitionDurationFromElement(this._element);
d9(this._element).one(dp.TRANSITION_END,eE).emulateTransitionEnd(eD)
}else{eE()
}};
ew.hide=function ev(){if(!this._element.classList.contains(U)){return
}var eD=d9.Event(ad);
d9(this._element).trigger(eD);
if(eD.isDefaultPrevented()){return
}this._close()
};
ew.dispose=function eB(){this._clearTimeout();
if(this._element.classList.contains(U)){this._element.classList.remove(U)
}d9(this._element).off(dP);
d9.removeData(this._element,H);
this._element=null;
this._config=null
};
ew._getConfig=function ex(eD){eD=k({},dT,d9(this._element).data(),typeof eD==="object"&&eD?eD:{});
dp.typeCheckConfig(d3,eD,this.constructor.DefaultType);
return eD
};
ew._setListeners=function eC(){var eD=this;
d9(this._element).on(dP,eb,function(){return eD.hide()
})
};
ew._close=function es(){var eF=this;
var eE=function eE(){eF._element.classList.add(ck);
d9(eF._element).trigger(a7)
};
this._element.classList.remove(U);
if(this._config.animation){var eD=dp.getTransitionDurationFromElement(this._element);
d9(this._element).one(dp.TRANSITION_END,eE).emulateTransitionEnd(eD)
}else{eE()
}};
ew._clearTimeout=function ey(){clearTimeout(this._timeout);
this._timeout=null
};
ez._jQueryInterface=function eu(eD){return this.each(function(){var eE=d9(this);
var eG=eE.data(H);
var eF=typeof eD==="object"&&eD;
if(!eG){eG=new ez(this,eF);
eE.data(H,eG)
}if(typeof eD==="string"){if(typeof eG[eD]==="undefined"){throw new TypeError('No method named "'+eD+'"')
}eG[eD](this)
}})
};
aQ(ez,null,[{key:"VERSION",get:function et(){return ed
}},{key:"DefaultType",get:function et(){return cG
}},{key:"Default",get:function et(){return dT
}}]);
return ez
}();
d9.fn[d3]=cb._jQueryInterface;
d9.fn[d3].Constructor=cb;
d9.fn[d3].noConflict=function(){d9.fn[d3]=cg;
return cb._jQueryInterface
};
aX.Alert=bD;
aX.Button=g;
aX.Carousel=aC;
aX.Collapse=J;
aX.Dropdown=bA;
aX.Modal=ee;
aX.Popover=dS;
aX.Scrollspy=dL;
aX.Tab=da;
aX.Toast=cb;
aX.Tooltip=dD;
aX.Util=dp;
Object.defineProperty(aX,"__esModule",{value:true})
})));
(function(a){var b={};
function c(e){if(b[e]){return b[e].exports
}var d=b[e]={i:e,l:false,exports:{}};
a[e].call(d.exports,d,d.exports,c);
d.l=true;
return d.exports
}c.m=a;
c.c=b;
c.i=function(d){return d
};
c.d=function(e,f,d){if(!c.o(e,f)){Object.defineProperty(e,f,{configurable:false,enumerable:true,get:d})
}};
c.n=function(e){var d=e&&e.__esModule?function f(){return e["default"]
}:function g(){return e
};
c.d(d,"a",d);
return d
};
c.o=function(d,e){return Object.prototype.hasOwnProperty.call(d,e)
};
c.p="";
return c(c.s=59)
})({49:(function(c,b,g){function f(h,i){if(!(h instanceof i)){throw new TypeError("Cannot call a class as a function")
}}var e=Bootstrap.jQuery,a={ie:"MSIE ",edge:"rv:",ff:"Firefox/",safari:"Safari/",chrome:"Chrome/"};
var d=function(){function h(){f(this,h);
this.setUpUserAgentString();
this.setUpUserAgent();
this.useUserAgent()
}h.prototype.setUpUserAgentString=function l(){this.userAgentString=navigator.userAgent
};
h.prototype.setUpUserAgent=function k(){for(var n in a){var m=this.constructor.fetchBrowserVersion(this.userAgentString,a[n]);
if(m){this.userAgent=n+"-"+m
}}};
h.prototype.useUserAgent=function i(){e("html").addClass(this.userAgent)
};
h.fetchBrowserVersion=function j(o,p){var n=o.split(p);
var m=void 0;
if(n.length===2){m=parseInt(n[1],10)
}return m
};
return h
}();
new d()
}),50:(function(b,a,c){(function(){window.DCC=window.DCC||{}
})()
}),51:(function(b,a,c){window.HSBC_utils=function(i){var z=[],h=[],y={initialized:"initialized"},j=["a","button","input",'[tabindex="0"]'],p={small:480,medium:960},B={ENTER:13,SPACE:32,UP:38,DOWN:40,LEFT:37,RIGHT:39,ESC:27,TAB:9,SHIFT:16},l=navigator.userAgent.toLowerCase().indexOf("firefox")>-1,d=C(),w=k(),n=null;
function A(F){z.push(F);
if(F.reinitIfParent){h.push(F)
}}function o(F){z.splice(F,1)
}function t(F,H){var I=void 0,G=void 0;
if(e()){G=i(H).find(F.selector)
}else{I=H.querySelectorAll(F.selector);
G=i(I)
}G.each(function(){if(!i(this).hasClass(y.initialized)&&F.init){i(this).addClass(y.initialized);
F.init(this);
F.initialized=true
}})
}function g(F,G){if(F.init){i(G).addClass(y.initialized);
F.init(G)
}}function v(H){var K=void 0,F=null;
H=H||{};
K=H.node||document.body;
F=i(K);
for(var I=0;
I<z.length;
I++){var G=z[I],J=G.selector.replace(/\./g,"");
if(H.node&&F.hasClass(J)){g(G,K)
}else{t(G,K)
}}}function u(J){var F=J.parent().closest(".initialized"),I=h.length,H=void 0;
if(!F.length){return
}for(var G=0;
G<I;
G++){H=h[G].selector.replace(/\./g,"");
if(F.hasClass(H)&&h[G].reinit){h[G].reinit(F[0]);
return
}}}function E(){var F=["Edit","Design","Developer"];
return typeof parent.Granite!=="undefined"&&typeof parent.Granite.author!=="undefined"&&typeof parent.Granite.author.layerManager!=="undefined"&&F.indexOf(parent.Granite.author.layerManager.getCurrentLayer())!==-1
}function D(){var F=false;
if(parent.document&&i(parent.document.documentElement).attr("id")==="patternlab-html"){F=true
}return F
}function e(){return document.addEventListener?false:true
}function r(I){var H=z.length,G=null,F=0;
if(I.prevLayer!==I.layer){if(I.layer==="Edit"){G="switchToEditHandler"
}else{if(I.layer==="Preview"){G="switchToPreviewHandler"
}}for(F;
F<H;
F++){if(z[F][G]){z[F][G]()
}}}}function C(){return{mobile:k()==="mobile",tablet:k()==="tablet",desktop:k()==="desktop"}
}function k(){var G="mobile",F=window.innerWidth;
if(F<p.small){G="mobile"
}else{if(F>=p.medium){G="desktop"
}else{G="tablet"
}}return G
}function q(){var G=200,H=1,F=300;
if(n){return
}n=setInterval(I,F);
function I(){v();
if(H===G){clearInterval(n);
n=null
}H++
}}function s(F,N,M,L){var J=void 0,G=void 0,K=void 0,H=void 0,I=void 0;
M=M||{};
J=M?M.expires:null;
if(typeof J==="number"){I=new Date();
I.setTime(I.getTime()+J*L);
M.expires=I;
J=M.expires
}if(J&&J.toUTCString){M.expires=J.toUTCString()
}N=encodeURIComponent(N);
G=F+"="+N;
for(K in M){if(M.hasOwnProperty(K)&&M[K]){G+="; "+K;
H=M[K];
if(H!==true){G+="="+H
}}}document.cookie=G
}function f(F,H,G){s(F,"",{domain:G,path:H,expires:0},-1)
}function x(F){var H=new RegExp("(?:^|; )"+F+"=([^;]*)"),G=document.cookie.match(H);
return G?decodeURIComponent(G[1]):undefined
}function m(H,G){var F=void 0,J=void 0,I=void 0;
G=G||location.href;
H=H||"";
H=H.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");
J=new RegExp("[\\?&]"+H+"=([^&#]*)");
I=J.exec(G);
return I==null?null:decodeURIComponent(I[1])
}i(window).on("resize",function(){var F=k();
if(F!==w){w=F;
window.HSBC_utils.matchMedia=C()
}});
i(document).ready(function(){v();
q()
});
return{deregisterComponent:o,init:v,isEditMode:E,isPatternLab:D,registerComponent:A,reinitializeParent:u,isIE8orLower:e,dispatchLayerSwitchEvent:r,setCookie:s,getCookie:x,deleteCookie:f,keyCodes:B,matchMedia:d,focusables:j,getUrlParam:m,isFirefox:l}
}(jQuery)
}),52:(function(b,d,a){function e(j,k){if(!(j instanceof k)){throw new TypeError("Cannot call a class as a function")
}}var c="a[target='_blank']",g="noopener",h={childList:true,attributes:true,characterData:true,subtree:true},f=Bootstrap.jQuery;
var i=function(){function m(){e(this,m)
}m.init=function n(){this.timer=undefined;
this.bindUIEvents();
this.setNoOpenerAttr()
};
m.bindUIEvents=function k(){var o=this;
if(window.MutationObserver){new MutationObserver(function(){return o.handleDOMChange()
}).observe(document.body,h)
}else{f("body").on("DOMNodeInserted",c,function(p){return o.setNoOpenerAttr(f(p.target))
})
}};
m.setNoOpenerAttr=function l(){var o=arguments.length>0&&arguments[0]!==undefined?arguments[0]:f(c);
o.each(function(){var q=f(this),p=q.attr("rel");
if(typeof p==="undefined"){q.attr("rel",g)
}else{if(!(p.toLowerCase().indexOf(g)>-1)){q.attr("rel",p+" "+g)
}}})
};
m.handleDOMChange=function j(){var o=this;
if(typeof this.timer==="undefined"){this.timer=setTimeout(function(){o.setNoOpenerAttr();
o.timer=undefined
},10)
}};
return m
}();
f(document).ready(function(){return i.init()
})
}),53:(function(d,a,h){function g(i,j){if(!(i instanceof j)){throw new TypeError("Cannot call a class as a function")
}}var f=Bootstrap.jQuery,e=f("body"),c={noOutlines:"no-outlines"};
var b=function(){function i(){g(this,i)
}i.init=function j(){e.on("mousedown",function(){return e.addClass(c.noOutlines)
}).on("keydown",function(){return e.removeClass(c.noOutlines)
})
};
return i
}();
b.init()
}),54:(function(d,b,h){b.__esModule=true;
function g(i,j){if(!(i instanceof j)){throw new TypeError("Cannot call a class as a function")
}}var e=Bootstrap.jQuery,a=[".link-container .link"],c=a.map(function(i){return e(i)
});
var f=b.TrimUtils=function(){function i(){g(this,i)
}i.trimElements=function j(){c.forEach(function(k){k.each(function(){var l=e(this),m=l.text().trim();
l.text(m)
})
})
};
return i
}();
f.trimElements()
}),55:(function(b,a,c){window.Bootstrap=function(){return{jQuery:jQuery.noConflict()}
}()
}),56:(function(d,b,g){function f(h,i){if(!(h instanceof i)){throw new TypeError("Cannot call a class as a function")
}}var e=Bootstrap.jQuery,c={smartTemplate:'[class*="globalSmart"]',buttons:".buttons-vertically"};
var a=function(){function h(){f(this,h)
}h.init=function k(){this.$smartTemplate=e(c.smartTemplate);
this.$buttons=this.$smartTemplate.find(c.buttons);
this.setButtonsWidth(this.$buttons);
this.bindUIEvents()
};
h.setButtonsWidth=function j(n){e(n).width("auto");
var l=216,m=Math.max.apply(null,n.map(function(o,p){return e(p).width()
}).get());
if(m>l){n.each(function(o,p){return e(p).width(m)
})
}else{e(n).width(l)
}};
h.bindUIEvents=function i(){var l=this;
e(window).on("resize",function(){return l.setButtonsWidth(l.$buttons)
})
};
return h
}();
a.init()
}),59:(function(b,a,c){c(55);
c(49);
c(50);
c(51);
c(52);
c(53);
c(54);
b.exports=c(56)
})});
/*!
 * mustache.js - Logic-less {{mustache}} templates with JavaScript
 * http://github.com/janl/mustache.js
 */
(function defineMustache(b,a){if(typeof exports==="object"&&exports&&typeof exports.nodeName!=="string"){a(exports)
}else{if(typeof define==="function"&&define.amd){define(["exports"],a)
}else{b.Mustache={};
a(b.Mustache)
}}}(this,function mustacheFactory(F){var x=Object.prototype.toString;
var y=Array.isArray||function d(Q){return x.call(Q)==="[object Array]"
};
function u(Q){return typeof Q==="function"
}function L(Q){return y(Q)?"array":typeof Q
}function i(Q){return Q.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&")
}function J(R,Q){return R!=null&&typeof R==="object"&&(Q in R)
}var o=RegExp.prototype.test;
function c(R,Q){return o.call(R,Q)
}var s=/\S/;
function E(Q){return !c(s,Q)
}var q={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#x2F;","`":"&#x60;","=":"&#x3D;"};
function z(Q){return String(Q).replace(/[&<>"'`=\/]/g,function R(S){return q[S]
})
}var t=/\s*/;
var C=/\s+/;
var l=/\s*=/;
var N=/\s*\}/;
var r=/#|\^|\/|>|\{|&|=|!/;
function e(aj,Y){if(!aj){return[]
}var aa=[];
var Z=[];
var V=[];
var ak=false;
var ah=false;
function ag(){if(ak&&!ah){while(V.length){delete Z[V.pop()]
}}else{V=[]
}ak=false;
ah=false
}var ac,X,ai;
function W(al){if(typeof al==="string"){al=al.split(C,2)
}if(!y(al)||al.length!==2){throw new Error("Invalid tags: "+al)
}ac=new RegExp(i(al[0])+"\\s*");
X=new RegExp("\\s*"+i(al[1]));
ai=new RegExp("\\s*"+i("}"+al[1]))
}W(Y||F.tags);
var S=new a(aj);
var T,R,ab,ae,U,Q;
while(!S.eos()){T=S.pos;
ab=S.scanUntil(ac);
if(ab){for(var af=0,ad=ab.length;
af<ad;
++af){ae=ab.charAt(af);
if(E(ae)){V.push(Z.length)
}else{ah=true
}Z.push(["text",ae,T,T+1]);
T+=1;
if(ae==="\n"){ag()
}}}if(!S.scan(ac)){break
}ak=true;
R=S.scan(r)||"name";
S.scan(t);
if(R==="="){ab=S.scanUntil(l);
S.scan(l);
S.scanUntil(X)
}else{if(R==="{"){ab=S.scanUntil(ai);
S.scan(N);
S.scanUntil(X);
R="&"
}else{ab=S.scanUntil(X)
}}if(!S.scan(X)){throw new Error("Unclosed tag at "+S.pos)
}U=[R,ab,T,S.pos];
Z.push(U);
if(R==="#"||R==="^"){aa.push(U)
}else{if(R==="/"){Q=aa.pop();
if(!Q){throw new Error('Unopened section "'+ab+'" at '+T)
}if(Q[1]!==ab){throw new Error('Unclosed section "'+Q[1]+'" at '+T)
}}else{if(R==="name"||R==="{"||R==="&"){ah=true
}else{if(R==="="){W(ab)
}}}}}Q=aa.pop();
if(Q){throw new Error('Unclosed section "'+Q[1]+'" at '+S.pos)
}return m(p(Z))
}function p(V){var R=[];
var T,Q;
for(var S=0,U=V.length;
S<U;
++S){T=V[S];
if(T){if(T[0]==="text"&&Q&&Q[0]==="text"){Q[1]+=T[1];
Q[3]=T[3]
}else{R.push(T);
Q=T
}}}return R
}function m(V){var X=[];
var U=X;
var W=[];
var R,T;
for(var Q=0,S=V.length;
Q<S;
++Q){R=V[Q];
switch(R[0]){case"#":case"^":U.push(R);
W.push(R);
U=R[4]=[];
break;
case"/":T=W.pop();
T[5]=R[2];
U=W.length>0?W[W.length-1][4]:X;
break;
default:U.push(R)
}}return X
}function a(Q){this.string=Q;
this.tail=Q;
this.pos=0
}a.prototype.eos=function K(){return this.tail===""
};
a.prototype.scan=function O(S){var R=this.tail.match(S);
if(!R||R.index!==0){return""
}var Q=R[0];
this.tail=this.tail.substring(Q.length);
this.pos+=Q.length;
return Q
};
a.prototype.scanUntil=function I(S){var R=this.tail.search(S),Q;
switch(R){case -1:Q=this.tail;
this.tail="";
break;
case 0:Q="";
break;
default:Q=this.tail.substring(0,R);
this.tail=this.tail.substring(R)
}this.pos+=Q.length;
return Q
};
function M(R,Q){this.view=R;
this.cache={".":this.view};
this.parent=Q
}M.prototype.push=function G(Q){return new M(Q,this)
};
M.prototype.lookup=function j(T){var R=this.cache;
var V;
if(R.hasOwnProperty(T)){V=R[T]
}else{var U=this,W,S,Q=false;
while(U){if(T.indexOf(".")>0){V=U.view;
W=T.split(".");
S=0;
while(V!=null&&S<W.length){if(S===W.length-1){Q=J(V,W[S])
}V=V[W[S++]]
}}else{V=U.view[T];
Q=J(U.view,T)
}if(Q){break
}U=U.parent
}R[T]=V
}if(u(V)){V=V.call(this.view)
}return V
};
function k(){this.cache={}
}k.prototype.clearCache=function A(){this.cache={}
};
k.prototype.parse=function v(S,R){var Q=this.cache;
var T=Q[S];
if(T==null){T=Q[S]=e(S,R)
}return T
};
k.prototype.render=function B(T,Q,S){var U=this.parse(T);
var R=(Q instanceof M)?Q:new M(Q);
return this.renderTokens(U,R,S,T)
};
k.prototype.renderTokens=function n(X,Q,V,Z){var T="";
var S,R,Y;
for(var U=0,W=X.length;
U<W;
++U){Y=undefined;
S=X[U];
R=S[0];
if(R==="#"){Y=this.renderSection(S,Q,V,Z)
}else{if(R==="^"){Y=this.renderInverted(S,Q,V,Z)
}else{if(R===">"){Y=this.renderPartial(S,Q,V,Z)
}else{if(R==="&"){Y=this.unescapedValue(S,Q)
}else{if(R==="name"){Y=this.escapedValue(S,Q)
}else{if(R==="text"){Y=this.rawValue(S)
}}}}}}if(Y!==undefined){T+=Y
}}return T
};
k.prototype.renderSection=function w(S,Q,V,Y){var Z=this;
var U="";
var W=Q.lookup(S[1]);
function R(aa){return Z.render(aa,Q,V)
}if(!W){return
}if(y(W)){for(var T=0,X=W.length;
T<X;
++T){U+=this.renderTokens(S[4],Q.push(W[T]),V,Y)
}}else{if(typeof W==="object"||typeof W==="string"||typeof W==="number"){U+=this.renderTokens(S[4],Q.push(W),V,Y)
}else{if(u(W)){if(typeof Y!=="string"){throw new Error("Cannot use higher-order sections without the original template")
}W=W.call(Q.view,Y.slice(S[3],S[5]),R);
if(W!=null){U+=W
}}else{U+=this.renderTokens(S[4],Q,V,Y)
}}}return U
};
k.prototype.renderInverted=function b(S,R,Q,U){var T=R.lookup(S[1]);
if(!T||(y(T)&&T.length===0)){return this.renderTokens(S[4],R,Q,U)
}};
k.prototype.renderPartial=function H(S,R,Q){if(!Q){return
}var T=u(Q)?Q(S[1]):Q[S[1]];
if(T!=null){return this.renderTokens(this.parse(T),R,Q,T)
}};
k.prototype.unescapedValue=function g(R,Q){var S=Q.lookup(R[1]);
if(S!=null){return S
}};
k.prototype.escapedValue=function D(R,Q){var S=Q.lookup(R[1]);
if(S!=null){return F.escape(S)
}};
k.prototype.rawValue=function f(Q){return Q[1]
};
F.name="mustache.js";
F.version="2.3.0";
F.tags=["{{","}}"];
var P=new k();
F.clearCache=function A(){return P.clearCache()
};
F.parse=function v(R,Q){return P.parse(R,Q)
};
F.render=function B(S,Q,R){if(typeof S!=="string"){throw new TypeError('Invalid template! Template should be a "string" but "'+L(S)+'" was given as the first argument for mustache#render(template, view, partials)')
}return P.render(S,Q,R)
};
F.to_html=function h(T,R,S,U){var Q=F.render(T,R,S);
if(u(U)){U(Q)
}else{return Q
}};
F.escape=z;
F.Scanner=a;
F.Context=M;
F.Writer=k;
return F
}));
/*! jQuery Mustache - v0.2.8 - 2013-06-23
 * https://github.com/jonnyreeves/jquery-Mustache
 * Copyright (c) 2013 Jonny Reeves; Licensed MIT */
(function(f,h){var b={},l=null,n={warnOnMissingTemplates:false,allowOverwrite:true,domTemplateType:"text/html",externalTemplateDataType:"text"};
function c(){if(l===null){l=h.Mustache;
if(l===void 0){f.error("Failed to locate Mustache instance, are you sure it has been loaded?")
}}return l
}function k(o){return b[o]!==void 0
}function m(o,p){if(!n.allowOverwrite&&k(o)){f.error("TemplateName: "+o+" is already mapped.");
return
}b[o]=f.trim(p)
}function e(){var o;
if(arguments.length===0){o=f('script[type="'+n.domTemplateType+'"]').map(function(){return this.id
})
}else{o=f.makeArray(arguments)
}f.each(o,function(){var p=document.getElementById(this);
if(p===null){f.error("No such elementId: #"+this)
}else{m(this,f(p).html())
}})
}function d(p){var o=b[p];
delete b[p];
return o
}function g(){b={};
c().clearCache()
}function a(o,p){if(!k(o)){if(n.warnOnMissingTemplates){f.error("No template registered for: "+o)
}return""
}return c().to_html(b[o],p,b)
}function j(o,p){return f.ajax({url:o,dataType:n.externalTemplateDataType}).done(function(q){f(q).filter("script").each(function(r,s){m(s.id,f(s).html())
});
if(f.isFunction(p)){p()
}})
}function i(){return f.map(b,function(p,o){return o
})
}f.Mustache={options:n,load:j,has:k,add:m,addFromDom:e,remove:d,clear:g,render:a,templates:i,instance:l};
f.fn.mustache=function(o,s,q){var r=f.extend({method:"append"},q);
var p=function(u,t){f(u)[r.method](a(o,t))
};
return this.each(function(){var t=this;
if(f.isArray(s)){f.each(s,function(){p(t,this)
})
}else{p(t,s)
}})
}
}(window.jQuery||Bootstrap.jQuery,window));
(function(a){var b={};
function c(e){if(b[e]){return b[e].exports
}var d=b[e]={i:e,l:false,exports:{}};
a[e].call(d.exports,d,d.exports,c);
d.l=true;
return d.exports
}c.m=a;
c.c=b;
c.d=function(e,f,d){if(!c.o(e,f)){Object.defineProperty(e,f,{configurable:false,enumerable:true,get:d})
}};
c.n=function(e){var d=e&&e.__esModule?function f(){return e["default"]
}:function g(){return e
};
c.d(d,"a",d);
return d
};
c.o=function(d,e){return Object.prototype.hasOwnProperty.call(d,e)
};
c.p="";
return c(c.s=45)
})([(function(b,a,c){}),(function(b,a){b.exports=jQuery
}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a){var c=b.exports=typeof window!="undefined"&&window.Math==Math?window:typeof self!="undefined"&&self.Math==Math?self:Function("return this")();
if(typeof __g=="number"){__g=c
}}),(function(c,b){var a=c.exports={version:"2.5.6"};
if(typeof __e=="number"){__e=a
}}),(function(b,a,f){a.__esModule=true;
function e(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}var d=Bootstrap.jQuery;
var c=a.SearchService=function(){function m(o,p){e(this,m);
this.config=o||{};
this.resultsPageSize=p;
this.currentId=0
}m.prototype.getSuggestions=function i(s){var u=this;
var r=d.Deferred(),p=s.query,t=this.getNextId(),o=4;
if(p!=null){var q=Object.assign({token:p,max_matches:o},this.getDefaultData());
this.getRequest(this.config.suggestionsEndpointURL,q).done(function(v){return u.resolveSuggestions(r,JSON.parse(v),t)
}).fail(r.reject)
}else{this.resolveSuggestions(r,[],t)
}return r.promise()
};
m.prototype.getNextId=function k(){return isFinite(this.currentId)?++this.currentId:0
};
m.prototype.resolveSuggestions=function h(p,o,q){if(q===this.currentId){p.resolve(o)
}};
m.prototype.getSearchResults=function g(u){var o=this;
var t=d.Deferred(),s=u.query;
if(s){var r=parseInt(u.page,10),q=!isNaN(r)&&r>1?(r-1)*this.resultsPageSize:0,p=Object.assign({q:s.trim(),requiredfields:u.requiredfields,num:this.resultsPageSize,start:q,ie:"utf8",oe:"utf8",filter:0,rc:1},this.getDefaultData());
this.getRequest(this.config.endpointURL,p).done(function(v){t.resolve({results:o.formatSearchRequest(s,v),params:u})
}).fail(t.reject)
}else{t.resolve([])
}return t.promise()
};
m.prototype.formatSearchRequest=function l(v,s){var r={"application/pdf":"pdf","application/msword":"document","text/richtext":"document","application/x-tar":"attachment","application/zip":"attachment","image/gif":"camera","image/jpeg":"camera","image/png":"camera"};
var q={},u=d.parseXML(s),t=d(u),p=t.find("R"),o=t.find("Spelling").find("Suggestion").attr("q");
q={queryString:v,numberOfResults:t.find("M").text(),firstResult:t.find("RES").attr("SN"),lastResult:t.find("RES").attr("EN"),rows:[],suggestion:o};
if(p){p.map(function(x,A){var w=d(A),y=w.attr("MIME"),z=y?{type:r[y]||"assets",directory:w.find("HN").attr("U")}:{};
q.rows.push({url:w.find("U").text(),title:w.find("T").text(),summary:w.find("S").text(),date:w.find("FS").attr("VALUE"),size:w.find("HAS").find("C").attr("SZ"),CID:w.find("HAS").find("C").attr("CID"),attachment:z,language:w.find("LANG").text(),rank:w.find("RK").text()})
})
}return q
};
m.prototype.getRequest=function n(o,q){return d.ajax({method:"GET",url:o,data:q,beforeSend:function p(r){return r.overrideMimeType("text/html; charset=UTF-8")
}})
};
m.prototype.getDefaultData=function j(){return{ssid:this.config.ssid,site:this.config.site}
};
return m
}()
}),(function(b,a,c){}),(function(c,b,f){b.__esModule=true;
b.HSBC_utils=undefined;
var e=f(1);
var a=d(e);
function d(h){return h&&h.__esModule?h:{"default":h}
}var g=function(){var C=[],t=[],P=["a","button","input",'[tabindex="0"]'],l={small:480,medium:960},D={ENTER:13,SPACE:32,UP:38,DOWN:40,LEFT:37,RIGHT:39,ESC:27,TAB:9,SHIFT:16},I=navigator.userAgent,i=I.toLowerCase().indexOf("firefox")>-1,y=I.indexOf("MSIE")>-1||navigator.appVersion.indexOf("Trident/")>0,R=I.indexOf("Chrome")>-1,n=I.indexOf("Safari")>-1&&!R&&!/(CriOS|FxiOS|OPiOS|mercury|UCBrowser|QQBrowser)/i.test(I),S=Number(I.split("OS ").slice(1).join().slice(0,3).replace("_","."))<6,M=/iphone|ipad|ipod/i.test(I),E=/android/i.test(I),k=(0,a["default"])("body").is('[class*="globalSmart"]'),w=typeof utag_data!=="undefined",x=A(),h=p(),H=null,s=200,G=/iphone|android|webos|ipad|ipod|blackberry|iemobile|opera mini|Windows Phone/i.test(I);
function v(){var V=(0,a["default"])("a[href^=tel]");
if(!G){V.addClass("no-link").attr("role","presentation").click(function(W){W.preventDefault()
})
}}function J(V){C.push(V);
if(V.reinitIfParent){t.push(V)
}}function F(V){C.splice(V,1)
}function j(V,X){var W=void 0;
if(K()){W=(0,a["default"])(X).find(V.selector)
}else{W=(0,a["default"])(X.querySelectorAll(V.selector))
}W.each(function(){if(!this.gpwsInitialized){B(V,this)
}})
}function B(V,W){W.gpwsInitialized=true;
V.init(W)
}function Q(Y){var X=Y||document.body;
for(var W=0;
W<C.length;
W++){var V=C[W];
if(Y&&(0,a["default"])(X).is(V.selector)){B(V,X)
}else{j(V,X)
}}v()
}function r(X){do{X=X.parentNode
}while(X&&!X.gpwsInitialized);
if(!X){return
}for(var W=0;
W<t.length;
W++){var V=t[W];
if((0,a["default"])(X).is(V.selector)){V.reinit(X);
return
}}}function T(){var V=["Edit","Design","Developer"];
return typeof parent.Granite!=="undefined"&&typeof parent.Granite.author!=="undefined"&&typeof parent.Granite.author.layerManager!=="undefined"&&V.indexOf(parent.Granite.author.layerManager.getCurrentLayer())!==-1
}function u(){var V=["Preview"];
return typeof parent.Granite!=="undefined"&&typeof parent.Granite.author!=="undefined"&&typeof parent.Granite.author.layerManager!=="undefined"&&V.indexOf(parent.Granite.author.layerManager.getCurrentLayer())!==-1
}function L(){var V=false;
if(parent.document&&(0,a["default"])(parent.document.documentElement).attr("id")==="patternlab-html"){V=true
}return V
}function K(){return document.addEventListener?false:true
}function N(Y){var X=C.length,W=null,V=0;
if(Y.prevLayer!==Y.layer){if(Y.layer==="Edit"){W="switchToEditHandler"
}else{if(Y.layer==="Preview"){W="switchToPreviewHandler"
}}for(V;
V<X;
V++){if(C[V][W]){C[V][W]()
}}}}function A(){return{mobile:p()==="mobile",tablet:p()==="tablet",desktop:p()==="desktop"}
}function p(){var W="mobile",V=window.innerWidth;
if(V<l.small){W="mobile"
}else{if(V>=l.medium){W="desktop"
}else{W="tablet"
}}return W
}function z(){var W=200,X=1,V=300;
if(H){return
}H=setInterval(Y,V);
function Y(){Q();
if(X===W){clearInterval(H);
H=null
}X++
}}function q(V,ad,ac,ab){var Z=void 0,W=void 0,aa=void 0,X=void 0,Y=void 0;
ac=ac||{};
Z=ac?ac.expires:null;
if(typeof Z==="number"){Y=new Date();
Y.setTime(Y.getTime()+Z*ab);
ac.expires=Y;
Z=ac.expires
}if(Z&&Z.toUTCString){ac.expires=Z.toUTCString()
}ad=encodeURIComponent(ad);
W=V+"="+ad;
for(aa in ac){if(ac.hasOwnProperty(aa)&&ac[aa]){W+="; "+aa;
X=ac[aa];
if(X!==true){W+="="+X
}}}document.cookie=W
}function O(V,X,W){q(V,"",{domain:W,path:X,expires:0},-1)
}function o(V){var X=new RegExp("(?:^|; )"+V+"=([^;]*)"),W=document.cookie.match(X);
return W?decodeURIComponent(W[1]):undefined
}function U(W,V){var Z=void 0,aa=void 0,Y=void 0,X=void 0;
V=V||location.href;
W=W||"";
W=W.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");
Z=new RegExp("[\\?&]"+W+"=([^&#]*)");
aa=Z.exec(V);
Y=aa==null?null:aa[1];
X=Y!=null?decodeURIComponent(Y.replace(/\+/g,"%20")):null;
return X
}function m(W){var V=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;
W.animate({height:0},s,function(){if(V){W.remove()
}})
}(0,a["default"])(window).on("resize",function(){var V=p();
if(V!==h){h=V;
window.HSBC_utils.matchMedia=A()
}});
(0,a["default"])(document).ready(function(){Q()
});
(0,a["default"])(window).on("load",function(){if(T()||u()){setTimeout(Q,300)
}else{z()
}});
return{deregisterComponent:F,init:Q,isEditMode:T,isPreviewMode:u,isPatternLab:L,registerComponent:J,reinitializeParent:r,isIE8orLower:K,dispatchLayerSwitchEvent:N,setCookie:q,getCookie:o,deleteCookie:O,keyCodes:D,matchMedia:x,focusables:P,getUrlParam:U,collapseElement:m,isFirefox:i,isInternetExplorer:y,isChrome:R,isSafari:n,iOSLowerVersion:S,isMobileiOS:M,isMobileAndroid:E,isSmartTemplate:k,isTealiumReady:w}
}();
window.HSBC_utils=g;
b.HSBC_utils=g
}),(function(b,a){b.exports=function(c){return typeof c==="object"?c!==null:typeof c==="function"
}
}),(function(b,a,c){b.exports=!c(30)(function(){return Object.defineProperty({},"a",{get:function(){return 7
}}).a!=7
})
}),(function(b,a,c){var e=c(81);
var d=c(83);
b.exports=function(f){return e(d(f))
}
}),(function(c,d,b){d.__esModule=true;
function f(m,n){if(!(m instanceof n)){throw new TypeError("Cannot call a class as a function")
}}var j={arrow:"pagination-arrow",number:"pagination-number",dots:"pagination-dots"},k={pagination:".A-PAGMAN-RW-ALL",pageSwitchers:".number a, .arrow a"},g={page:"page",currentPageText:"current-page-text",pageText:"page-text"},l={disabled:"disabled",active:"active"},a={desktop:2,tablet:1,mobile:0},e=Bootstrap.jQuery;
var i=2;
var h=d.Pagination=function(){function x(B,D,C){f(this,x);
this.$el=e(B);
this.$wrapper=this.$el.find(k.pagination);
this.elNum=D;
this.currentEl=C;
this.allyTexts=this.getAccessibilityTexts();
this.setMustacheTemplates();
this.initElements()
}x.prototype.destroy=function z(){this.$wrapper.empty()
};
x.prototype.getAccessibilityTexts=function n(){var B=this.$el.data(g.currentPageText)||"",C=this.$el.data(g.pageText)||"";
return{currentPage:B,page:C}
};
x.prototype.setMustacheTemplates=function s(){var B=this;
Object.keys(j).forEach(function(C){var D=j[C],E=B.$el.find("."+D);
e.Mustache.add(D,E.html())
})
};
x.prototype.initElements=function t(){if(this.elNum>1){this.setVisibleElCount();
this.render(this.getPaginationMap());
this.bindPaginationUIEvents()
}else{this.destroy()
}};
x.prototype.bindPaginationUIEvents=function q(){var B=this;
this.$pageSwitchers=this.$wrapper.find(k.pageSwitchers);
this.$pageSwitchers.on("click",function(D){D.preventDefault();
var C=e(D.target);
B.currentEl=C.data(g.page);
B.initElements()
})
};
x.prototype.setVisibleElCount=function A(){i=HSBC_utils.matchMedia.mobile?a.mobile:HSBC_utils.matchMedia.tablet?a.tablet:a.desktop
};
x.prototype.render=function p(B){var C=this;
this.destroy();
B.forEach(function(D){return C.$wrapper.mustache(D.template,D.data)
})
};
x.prototype.getPaginationMap=function r(){var E=[];
E.push(this.getArrowElement("left"));
for(var F=1;
F<=this.elNum;
F++){var D=F===1,I=F===this.elNum,C=this.getElementVisibilityCondition(F),G=this.getDotElement(I,F,-1),B=this.getDotElement(D,F,1);
if(G!==null){E.push(G)
}if(C||D||I){var H=F===this.currentEl?l.active:"";
E.push(this.getNumberElement(F,H))
}if(B!==null){E.push(B)
}}E.push(this.getArrowElement("right"));
return E
};
x.prototype.getDotVisibilityCondition=function u(B){return Math.abs(this.currentEl-B)>i+1
};
x.prototype.getElementVisibilityCondition=function o(B){return Math.abs(this.currentEl-B)<=i
};
x.prototype.getPaginationControls=function y(){if(this.$pageSwitchers===undefined){return{on:function B(){}}
}else{return this.$pageSwitchers
}};
x.prototype.getArrowElement=function m(F){var B=this.currentEl===1&&F==="left"||this.currentEl===this.elNum&&F==="right",E=B?l.disabled:"",D=this.currentEl+(F==="left"?-1:1),C=F==="right";
return{template:j.arrow,data:{direction:F,page:D,isDisabled:B,state:E,isRight:C}}
};
x.prototype.getDotElement=function w(G,C,F){if(G&&this.getDotVisibilityCondition(C)){var E=C+F,D=this.getElementVisibilityCondition(E*2)?j.number:j.dots,B=this.allyTexts.page;
return{template:D,data:{page:E,accessibilityText:B}}
}return null
};
x.prototype.getNumberElement=function v(D,C){var B=C===l.active?this.allyTexts.currentPage:this.allyTexts.page;
return{template:j.number,data:{page:D,state:C,accessibilityText:B}}
};
return x
}()
}),(function(b,e,a){e.__esModule=true;
e.SearchMobileSuggestions=undefined;
var i=a(8);
var l=a(116);
function g(m,n){if(!(m instanceof n)){throw new TypeError("Cannot call a class as a function")
}}var k={searchContainer:".header-mobile-search-container",suggestions:".search-suggestions",suggestionList:".suggestion-list",searchBox:".search-box",suggestionItem:".suggestion-item",helper:".search-suggestions-helper"},h={config:"config"},c={hidden:"hidden",suggestionItem:"suggestion-item"},j="search-suggestion-template",f=Bootstrap.jQuery;
var d=e.SearchMobileSuggestions=function(){function u(x){g(this,u);
this.$el=x;
this.$suggestions=this.$el.find(k.suggestions);
this.$suggestionList=this.$suggestions.find(k.suggestionList);
this.$searchBox=this.$el.find(k.searchBox);
this.$helper=this.$el.find(k.helper);
this.searchService=new i.SearchService(this.getConfig());
this.results=[];
this.setMustacheTemplates();
this.bindUIEvents();
this.ally=new l.SearchMobileSuggestionsAlly(this)
}u.prototype.bindUIEvents=function m(){var x=this;
this.$searchBox.on("input",function(){return x.resolveSuggestions()
});
f(window).on("click",function(z){var y=f(z.target);
if(!y.parents(k.searchContainer).length){x.removeSuggestions()
}})
};
u.prototype.resolveSuggestions=function t(){var x=this;
this.searchService.getSuggestions({query:this.$searchBox.val()}).done(function(y){x.results=y||[];
if(x.results.length){x.showSuggestions()
}else{x.$helper.empty().html(0);
x.hideSuggestions()
}})
};
u.prototype.showSuggestions=function v(){this.$suggestions.removeClass(c.hidden).attr("aria-hidden",false);
this.$helper.empty().html(this.results.length);
this.$helper.parent().attr("aria-hidden",false);
this.render()
};
u.prototype.render=function n(){var x=this;
this.$suggestionList.empty();
this.results.forEach(function(y){return x.$suggestionList.mustache(j,{text:y})
});
this.$suggestionItems=this.$suggestionList.find(k.suggestionItem);
this.bindSuggestionsUIEvents()
};
u.prototype.bindSuggestionsUIEvents=function s(){var x=this;
this.$suggestionItems.on("click",function(y){return x.handleSuggestionChoice(f(y.target))
}).on("focusout",function(z){var y=f(z.relatedTarget);
if(!y.hasClass(c.suggestionItem)){x.hideSuggestions()
}});
this.ally.bindSuggestionsUIEvents()
};
u.prototype.handleSuggestionChoice=function p(x){var y=x.text();
this.hideSuggestions();
this.$searchBox.val(y)
};
u.prototype.hideSuggestions=function r(){this.removeSuggestions();
this.$searchBox.focus()
};
u.prototype.removeSuggestions=function o(){this.$suggestions.addClass(c.hidden).attr("aria-hidden",true);
this.$helper.parent().attr("aria-hidden",true)
};
u.prototype.getConfig=function w(){return this.$el.data(h.config)
};
u.prototype.setMustacheTemplates=function q(){f.Mustache.add(j,this.$el.find("."+j).html())
};
return u
}()
}),(function(b,f,a){f.__esModule=true;
var c=typeof Symbol==="function"&&typeof Symbol.iterator==="symbol"?function(m){return typeof m
}:function(m){return m&&typeof Symbol==="function"&&m.constructor===Symbol&&m!==Symbol.prototype?"symbol":typeof m
};
function h(m,n){if(!(m instanceof n)){throw new TypeError("Cannot call a class as a function")
}}var d={hidden:"hidden"},j={accountsButton:"my-accounts-button",loginButton:".login-button",registerButton:".register-button",logoutButton:".logout-button",pagePath:"[data-page-path]",loginLinks:".login-links"},i="ICIPDOMAINCOOKIE",g=Bootstrap.jQuery,e=g("body");
var l={checked:false,during:false,authorized:false,delayed:[]};
var k=f.HeaderLoggedUserState=function(){function r(s){h(this,r);
this.context=s;
this.$el=s.$el;
this.$logoutButton=this.$el.find(j.logoutButton);
this.$loginButton=this.$el.find(j.loginButton);
this.$loginLinks=this.$el.find(j.loginLinks);
this.$mobileAccountsButton=this.$el.find("."+j.accountsButton);
this.$registerButton=e.find(j.registerButton);
if(this.$el.hasClass(j.accountsButton)){this.$accountsButton=this.$el
}else{this.$accountsButton=g("<div></div>")
}this.adjustHeaderElements(this.$loginButton,this.$logoutButton);
this.adjustHeaderElements(this.$registerButton,this.$accountsButton);
this.adjustHeaderElements(g(),this.$mobileAccountsButton);
this.bindUiEvents()
}r.prototype.bindUiEvents=function q(){var s=this;
if(c(this.$logoutButton.attr("href"))===(true?"undefined":c(undefined))||this.$logoutButton.attr("href")===false){this.$logoutButton.on("click",function(){return s.redirectOnLogout()
})
}};
r.prototype.adjustHeaderElements=function o(t,u){var v=this;
var s=HSBC_utils.getCookie(i);
if(l.checked){this.changeLoggedState(l.authorized,t,u)
}else{if(l.during){l.delayed.push(function(w){return v.changeLoggedState(w,t,u)
})
}else{l.during=true;
g.ajax("/authorize.auth.json?q",{cache:false,contentType:"json"}).done(function(x){var w=x&&x.authorized;
v.changeLoggedState(x&&x.authorized,t,u);
l.during=false;
l.checked=true;
l.authorized=w;
l.delayed.forEach(function(y){return y(w)
});
l.delayed=[]
})
}}};
r.prototype.changeLoggedState=function n(u,s,t){if(u){s.addClass(d.hidden);
t.removeClass(d.hidden);
this.$loginLinks.remove()
}else{s.removeClass(d.hidden);
t.addClass(d.hidden)
}};
r.prototype.getPagePath=function m(){var s=g(document).find(j.pagePath);
return s?s.data("page-path"):""
};
r.prototype.redirectOnLogout=function p(){g("<form>",{method:"post",action:"/bin/logout."+this.getPagePath()}).appendTo("body").submit()
};
return r
}()
}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(c,b,d){var e=d(69);
var a=d(74);
c.exports=d(12)?function(f,g,h){return e.f(f,g,a(1,h))
}:function(f,g,h){f[g]=h;
return f
}
}),(function(b,a){b.exports=function(c){try{return !!c()
}catch(d){return true
}}
}),(function(b,a){var c={}.hasOwnProperty;
b.exports=function(e,d){return c.call(e,d)
}
}),(function(c,a){var d=0;
var b=Math.random();
c.exports=function(e){return"Symbol(".concat(e===undefined?"":e,")_",(++d+b).toString(36))
}
}),(function(b,a){var c=Math.ceil;
var d=Math.floor;
b.exports=function(e){return isNaN(e=+e)?0:(e>0?d:c)(e)
}
}),(function(c,d,a){d.__esModule=true;
function e(j,k){if(!(j instanceof k)){throw new TypeError("Cannot call a class as a function")
}}var f=Bootstrap.jQuery,i={tileWrapper:'[class*="O-TILE"], .O-MASTERTILE-DEV, .O-LINKSONTILE-DEV, .O-ICONTILE-DEV',masterTileItem:".M-MASTERTILEITEM-DEV .A-PNL-RW-ALL",linksOnTileItem:".M-LINKSONTILEITEM-DEV .A-PNL-RW-ALL",iconTileItem:".M-ICONTILEITEM-DEV .A-PNL-RW-ALL",tileItem:'[class*="M-TIL"] .A-PNL-RW-ALL, .M-MASTERTILEITEM-DEV .A-PNL-RW-ALL, .M-LINKSONTILEITEM-DEV .A-PNL-RW-ALL, .M-ICONTILEITEM-DEV .A-PNL-RW-ALL',imageWrapper:".image-wrapper"},h={tile43C:"O-TILE4THREECOL-RW-RBWM",tile34C:"O-TILE3FOURCOL-RW-RBWM",tile26C:"O-TILE2SIXCOL-RW-RBWM",tile1623C:"O-TILE1SIX2THREE-RW-RBWM",masterTile:"O-MASTERTILE-DEV",iconTile:"O-ICONTILE-DEV",linksOnTile:"O-LINKSONTILE-DEV"},b={tile43C:{first:".container:nth-child(-n+2) "+i.tileItem,second:".container:nth-child(n+3) "+i.tileItem},tile34C:{first:".container:not(:last-child) "+i.tileItem,second:""},tile26C:{first:".container "+i.tileItem,second:""},tile1623C:{first:"",second:""},masterTile:{first:".container.md-12 "+i.masterTileItem,second:".container.md-6 "+i.masterTileItem},linksOnTile:{first:"",second:""},iconTile:{first:".container:nth-child(-n+2) "+i.iconTileItem,second:".container:nth-child(n+3) "+i.iconTileItem}};
var g=d.TileMaster=function(){function p(s){e(this,p);
this.$el=f(s);
this.$tileItems=this.$el.find(i.tileItem);
this.$imageWrappers=this.$el.find(i.imageWrapper);
this.equalizeTiles();
this.bindUiEvents()
}p.prototype.bindUiEvents=function o(){var s=this;
f(window).on("resize",function(){return s.equalizeTiles()
})
};
p.prototype.equalizeTiles=function r(){this.resetElements();
if(HSBC_utils.matchMedia.desktop){this.equalizeTilesOnDesktop()
}else{if(HSBC_utils.matchMedia.tablet){this.equalizeTilesOnTablet()
}}};
p.prototype.resetElements=function l(){this.$tileItems.height("auto");
this.$imageWrappers.height("auto")
};
p.prototype.equalizeTilesOnDesktop=function k(){p.resizeElements(this.$imageWrappers);
p.resizeElements(this.$tileItems)
};
p.prototype.equalizeTilesOnTablet=function q(){var t=this.getTileSignature(),v=this.$el.find(b[t].first),s=this.$el.find(b[t].second),u=[v.find(i.imageWrapper),s.find(i.imageWrapper),v,s];
u.forEach(function(w){return p.resizeElements(w)
})
};
p.prototype.getTileSignature=function m(){for(var s in h){if(h.hasOwnProperty(s)&&this.$el.hasClass(h[s])){return s
}}return null
};
p.resizeElements=function j(s){s.height(this.getHighestElement(s))
};
p.getHighestElement=function n(s){return Math.max.apply(null,s.map(function(t,u){return f(u).height()
}))
};
return p
}();
(function(){var j={name:"tilemaster",selector:i.tileWrapper,init:function k(l){return new g(l)
}};
f(window).on("load",function(){return HSBC_utils.registerComponent(j)
})
})()
}),(function(b,a,c){}),(function(b,d,a){d.__esModule=true;
d.SearchField=undefined;
var i=a(37);
function g(l,m){if(!(l instanceof m)){throw new TypeError("Cannot call a class as a function")
}}var c={queryParamName:"q",moduleName:"heroSearch",moduleSelector:".O-HEROBANWSRCH-RW-DEV",searchQuery:"SEARCH_QUERY",empty:""},k={form:"form",searchInput:'input[type="search"]',tagsInput:'input[type="hidden"]',dataConfig:".O-SRCHRES-RW-RBWM [data-config]"},h={config:"config"},j=168,f=Bootstrap.jQuery;
var e=d.SearchField=function(){function m(u,w,t){var v=this;
g(this,m);
this.$el=f(u);
this.config=f(k.dataConfig).data(h.config);
this.$searchInput=this.$el.find(k.searchInput);
this.$tagsInput=this.$el.find(k.tagsInput);
this.$form=this.$el.find(k.form);
this.onSubmit=w;
this.setInputMaxLength();
this.disableAutocomplete();
this.suggestions=new i.SearchFieldSuggestions(this.$el,this.config);
this.$el.find("form").on("submit",function(x){x.preventDefault();
v.handleSubmit()
});
this.setSearchField(t);
this.trigger="free text"
}m.prototype.setInputMaxLength=function q(){this.$searchInput.attr("maxlength",j)
};
m.prototype.disableAutocomplete=function r(){this.$searchInput.attr("autocomplete","off")
};
m.prototype.handleSubmit=function l(){var t=this.$searchInput.val(),u=this.validateEmpty(t);
if(!u){this.setSearchField(c.empty)
}else{this.onSubmit(t)
}};
m.prototype.setSearchField=function p(t){this.$searchInput.val(t);
this.$searchInput.attr("aria-controls","search-results-container")
};
m.prototype.setTrigger=function n(t){this.trigger=t
};
m.prototype.updateTags=function s(t){this.$tagsInput.val(t)
};
m.prototype.validateEmpty=function o(t){t=t||"";
return !!t.trim().length
};
return m
}()
}),(function(b,d,a){d.__esModule=true;
d.SearchFieldSuggestions=undefined;
var g=a(8);
function f(k,l){if(!(k instanceof l)){throw new TypeError("Cannot call a class as a function")
}}var j={searchContainer:".search-panel",suggestions:".search-suggestions",suggestionList:".suggestion-list",searchField:".search-form .input",suggestionItem:".suggestion-item",helper:".search-suggestions-helper"},c={hidden:"hidden",suggestionItem:"suggestion-item"},i="search-suggestion-template",e=Bootstrap.jQuery;
var h=d.SearchFieldSuggestions=function(){function t(v,u){f(this,t);
this.$el=v;
this.config=u;
this.$suggestions=this.$el.find(j.suggestions);
this.$suggestionList=this.$suggestions.find(j.suggestionList);
this.$searchField=this.$el.find(j.searchField);
this.$helper=this.$el.find(j.helper);
this.searchService=new g.SearchService(this.config);
this.results=[];
this.setMustacheTemplates();
this.bindUIEvents()
}t.prototype.bindUIEvents=function k(){var u=this;
this.$searchField.on("input",function(){return u.resolveSuggestions()
});
e(window).on("click",function(w){var v=e(w.target);
if(!v.parents(j.searchContainer).length){u.removeSuggestions()
}})
};
t.prototype.resolveSuggestions=function r(){var u=this;
this.searchService.getSuggestions({query:this.$searchField.val()}).done(function(v){u.results=v||[];
if(u.results.length){u.showSuggestions()
}else{u.$helper.empty().html(0);
u.hideSuggestions()
}})
};
t.prototype.showSuggestions=function s(){this.$suggestions.removeClass(c.hidden);
this.$helper.empty().html(this.results.length);
this.render()
};
t.prototype.render=function l(){var u=this;
this.$suggestionList.empty();
this.results.forEach(function(v){return u.$suggestionList.mustache(i,{text:v})
});
this.$suggestionItems=this.$suggestionList.find(j.suggestionItem);
this.bindSuggestionsUIEvents()
};
t.prototype.bindSuggestionsUIEvents=function q(){var u=this;
this.$suggestionItems.on("click",function(v){return u.handleSuggestionChoice(e(v.target))
}).on("focusout",function(w){var v=e(w.relatedTarget);
if(!v.hasClass(c.suggestionItem)){u.hideSuggestions()
}})
};
t.prototype.handleSuggestionChoice=function n(u){var v=u.text();
this.hideSuggestions();
this.$searchField.val(v)
};
t.prototype.hideSuggestions=function p(){this.removeSuggestions();
this.$searchField.focus()
};
t.prototype.removeSuggestions=function m(){this.$suggestions.addClass(c.hidden)
};
t.prototype.setMustacheTemplates=function o(){e.Mustache.add(i,this.$el.find("."+i).html())
};
return t
}()
}),(function(c,a,g){a.__esModule=true;
function f(h,i){if(!(h instanceof i)){throw new TypeError("Cannot call a class as a function")
}}var b=HSBC_utils.keyCodes,d=Bootstrap.jQuery;
var e=a.SmartTabsAlly=function(){function j(u){f(this,j);
this.$el=u.$el;
this.context=u;
this.ariaSelectedfirstchild()
}j.prototype.bindUIEvents=function i(){var v=this;
this.context.$tabsMenuItem.find("a").on({keydown:function u(w){v.catchDataTarget(w);
v.keyboardNavigationMenu(w)
}});
this.context.$tabsContainer.on({keydown:function u(w){v.keyboardNavigationContainer(w)
}});
this.context.$tabsContent.on({keydown:function u(w){v.keyboardNavigationContent(w)
}})
};
j.prototype.changeAriaSelectState=function s(w){var v=d(w.target),u=v.hasClass("is-active");
this.context.$tabsMenuLink.attr("aria-selected",false);
v.attr("aria-selected",!u)
};
j.prototype.changeAriaHiddenTabindexState=function t(w){var u=d(w.target),v=u.attr("data-target");
this.context.$tabsContent.attr({"aria-hidden":true});
d(v).attr({"aria-hidden":false})
};
j.prototype.ariaSelectedfirstchild=function k(){this.context.$tabsMenuItem.first().find("a").attr("aria-selected",true)
};
j.prototype.goBackToTabMenuFromLastChild=function h(x){var v=d(x.target),w=v.closest(this.context.$tabsContent).attr("id"),u=v.closest(this.context.$tabsContent).find(HSBC_utils.focusables.join()),y=u.first().is(":focus");
if(y){this.context.$tabsContainer.attr("tabindex",-1);
d('[data-target="#'+w+'"]').focus();
x.preventDefault()
}};
j.prototype.focusTabPanel=function r(){this.context.$tabsContainer.attr("tabindex",0);
this.context.$tabsContainer.focus()
};
j.prototype.goBackToSelectedTab=function m(w){var u=d(w.target),v=u.find(this.context.$tabsContent).not(".hidden").attr("id");
d('[data-target="#'+v+'"]').focus();
w.preventDefault()
};
j.prototype.goBackToSelectedTabFromFirstChild=function p(x){var u=d(x.target),v=u.find(this.context.$tabsContent).not(".hidden").attr("id"),w=u.closest(this.context.$tabsContent).find(HSBC_utils.focusables.join());
if(w.length<1){x.preventDefault()
}this.context.$tabsContainer.attr("tabindex",-1);
d('[data-target="#'+v+'"]').focus()
};
j.prototype.keyboardNavigationMenu=function n(w){var x=w.keyCode,v=x===b.ENTER,u=x===b.SPACE;
if(v||u){this.changeAriaSelectState(w);
this.changeAriaHiddenTabindexState(w);
this.focusTabPanel();
w.preventDefault()
}};
j.prototype.keyboardNavigationContent=function l(x){var z=x.keyCode,w=x.shiftKey,v=z===b.ESC,y=z===b.TAB,u=y&&w;
if(u){this.goBackToTabMenuFromLastChild(x)
}if(v){this.goBackToSelectedTab(x)
}};
j.prototype.keyboardNavigationContainer=function o(w){var y=w.keyCode,v=w.shiftKey,x=y===b.TAB,u=x&&v;
if(u){this.goBackToSelectedTabFromFirstChild(w)
}};
j.prototype.catchDataTarget=function q(y){var w=d(y.target),z=w.attr("data-target"),x=y.keyCode,v=x===b.SPACE,u=x===b.ENTER;
if(u||v){this.context.hashChange(z);
this.changeAriaSelectState(y);
y.preventDefault()
}};
return j
}()
}),(function(b,a,c){}),(function(b,a,c){}),(function(d,a,g){a.__esModule=true;
function f(i,j){if(!(i instanceof j)){throw new TypeError("Cannot call a class as a function")
}}var b=HSBC_utils.keyCodes,e=Bootstrap.jQuery,c={hide:"hidden",modalAnnouncement:"modal-announcement-sr-text"};
var h=a.ModalAlly=function(){function k(l){f(this,k);
this.$el=l.$el;
this.context=l
}k.prototype.bindUIEvents=function i(){var m=this;
var l=this.context;
this.$focusables=l.$modal.find(HSBC_utils.focusables.join());
l.$modal.on("keydown",function(q){var s=e(document.activeElement),p=q.keyCode,o=p===b.ESC&&l.$modal.hasClass(c.isVisible),n=p===b.ENTER&&s.hasClass(c.closeTrigger),r=p===b.TAB;
if(o||n){q.preventDefault();
l.close()
}else{if(r){m.handleKeyPress(q)
}}})
};
k.prototype.handleKeyPress=function j(o){var l=this.context,q=document.activeElement,p=this.$focusables.first()[0],n=this.$focusables.last()[0],m=l.$modal.find("."+c.modalAnnouncement);
m.addClass(c.hide);
if(q==n&&!o.shiftKey){p.focus();
o.preventDefault()
}else{if(q==p&&o.shiftKey){n.focus();
o.preventDefault()
}}};
return k
}()
}),(function(b,d,a){d.__esModule=true;
function e(j,k){if(!(j instanceof k)){throw new TypeError("Cannot call a class as a function")
}}var i={headerMainMenu:".header-main-navigation",headerMainMenuTitle:".header-doormat-mobile-title",screenreaderText:".screenreader-text",doormatExpanded:".doormat-expanded",doormatCollapsed:".doormat-collapsed",navigationItem:".header-main-navigation-item"},c={active:"active",hidden:"hidden"},g=HSBC_utils.keyCodes,f=Bootstrap.jQuery;
var h=d.DoormatAlly=function(){function j(l){e(this,j);
this.$el=l.$el;
this.$navigationItem=l.$navigationItem;
this.context=l;
l.$allDoormatLinks.attr("tabindex",-1);
this.bindUIEvents()
}j.prototype.bindUIEvents=function k(){var r=this;
var n=this.context,m=this.$navigationItem.find("a"),l=m.first(),o=m.last(),p=this.$navigationItem.find(i.screenreaderText),q=this.$el.find("a");
this.$el.on("mouseout",function(){return p.removeClass(c.hidden)
});
this.$navigationItem.on("keydown",function(v){var s=f(v.target),u=v.keyCode,w=n.$doormatCollapsed.text(),t=s.prop("tagName");
if(u===g.ENTER||u===g.SPACE){if(!n.isEnterHandlerEnabled){n.isEnterHandlerEnabled=true;
n.isInMenu=true;
if(!s.hasClass(c.active)){r.$el.addClass(c.active);
r.$navigationItem.addClass(c.active)
}n.toggleMenuStatusText();
r.$el.attr("aria-hidden",false);
q.attr("tabindex",0);
q.first().focus();
v.preventDefault()
}else{n.removeActiveClassState(q);
p.addClass(c.hidden);
s.attr("aria-label",w).removeAttr("aria-label")
}}else{if(u===g.TAB&&t==="LI"){n.removeActiveClass();
n.toggleMenuStatusText();
p.removeClass(c.hidden);
n.isEnterHandlerEnabled=false
}}}).on("focus",function(u){var s=f(u.target),t=s.find(i.headerMainMenuTitle);
if(n.getFocusCondition()){t.attr("aria-hidden",false);
q.attr("tabindex",-1)
}}).on("focusout",function(u){var s=f(u.target),t=s.find(i.headerMainMenuTitle);
if(n.getFocusCondition()){t.attr("aria-hidden",true);
q.attr("tabindex",-1);
p.removeClass(c.hidden)
}});
q.on("keydown",function(t){var s=t.keyCode;
if(s===g.ESC){n.isInMenu=false;
p.addClass(c.hidden);
q.attr("tabindex",-1);
r.$navigationItem.focus();
t.preventDefault()
}});
l.on("keydown",function(u){var s=u.keyCode,t=u.shiftKey;
if(t&&s===g.TAB){n.isInMenu=false;
p.addClass(c.hidden);
q.attr("tabindex",-1);
r.$el.attr("aria-hidden",true);
r.$navigationItem.focus();
u.preventDefault()
}});
o.on("keydown",function(u){var s=u.keyCode,t=u.shiftKey;
if(!t&&s===g.TAB){n.removeActiveClassState(q);
p.removeClass(c.hidden)
}})
};
return j
}()
}),(function(b,a,c){}),(function(d,a,h){a.__esModule=true;
function g(i,j){if(!(i instanceof j)){throw new TypeError("Cannot call a class as a function")
}}var b=HSBC_utils.keyCodes,f=Bootstrap.jQuery,c={hide:"hidden",modalAnnouncement:"modal-announcement-sr-text",isVisible:"is-visible",cancelTrigger:"mw-cancel-trigger"};
var e=a.ModalWindowAlly=function(){function j(l){g(this,j);
this.$el=l.$el;
this.context=l
}j.prototype.bindUIEvents=function i(){var n,o=this;
var m=this.context,l=m.$modal.find(c.cancelTrigger);
this.$focusables=(n=this.context.$modal).find.apply(n,HSBC_utils.focusables);
l.on("click",function(){o.$focusables.first()[0].focus()
});
m.$modal.on("keydown",function(s){var u=f(document.activeElement),r=s.keyCode,q=r===b.ESC&&m.$modal.hasClass(c.isVisible),p=r===b.ENTER&&u.hasClass(c.cancelTrigger),t=r===b.TAB;
if(q||p){s.preventDefault();
m.close()
}else{if(t){o.handleKeyPress(s)
}}})
};
j.prototype.handleKeyPress=function k(o){var l=this.context,q=document.activeElement,p=this.$focusables.first()[0],n=this.$focusables.last()[0],m=l.$modal.find("."+c.modalAnnouncement);
m.addClass(c.hide);
if(q==n&&!o.shiftKey){p.focus();
o.preventDefault()
}else{if(q==p&&o.shiftKey){n.focus();
o.preventDefault()
}}};
return j
}()
}),(function(b,a,c){c(17);
c(47);
c(18);
c(4);
c(5);
c(49);
c(23);
c(51);
c(52);
c(24);
c(53);
c(54);
c(25);
c(55);
c(56);
c(26);
c(57);
c(58);
c(59);
c(28);
c(60);
c(61);
c(62);
c(63);
c(64);
c(65);
c(92);
c(93);
c(94);
c(35);
c(36);
c(37);
c(95);
c(8);
c(96);
c(97);
c(38);
c(0);
c(34);
c(98);
c(100);
c(101);
c(102);
c(103);
c(39);
c(104);
c(40);
c(105);
c(41);
c(14);
c(106);
c(108);
c(110);
c(111);
c(112);
c(42);
c(113);
c(114);
c(115);
c(118);
c(119);
c(120);
c(16);
c(122);
c(124);
c(15);
c(43);
c(126);
c(127);
c(44);
c(128);
c(129);
c(130);
b.exports=c(131)
}),(function(b,a){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){c(67);
b.exports=c(7).Object.entries
}),(function(c,b,e){var f=e(68);
var d=e(78)(true);
f(f.S,"Object",{entries:function a(g){return d(g)
}})
}),(function(c,g,b){var a=b(6);
var d=b(7);
var h=b(29);
var i=b(75);
var j=b(76);
var f="prototype";
var e=function(w,m,k){var l=w&e.F;
var o=w&e.G;
var t=w&e.S;
var n=w&e.P;
var s=w&e.B;
var u=o?a:t?a[m]||(a[m]={}):(a[m]||{})[f];
var r=o?d:d[m]||(d[m]={});
var v=r[f]||(r[f]={});
var x,y,q,p;
if(o){k=m
}for(x in k){y=!l&&u&&u[x]!==undefined;
q=(y?u:k)[x];
p=s&&y?j(q,a):n&&typeof q=="function"?j(Function.call,q):q;
if(u){i(u,x,q,w&e.U)
}if(r[x]!=q){h(r,x,p)
}if(n&&v[x]!=q){v[x]=q
}}};
a.core=d;
e.F=1;
e.G=2;
e.S=4;
e.P=8;
e.B=16;
e.W=32;
e.U=64;
e.R=128;
c.exports=e
}),(function(e,c,g){var b=g(70);
var f=g(71);
var d=g(73);
var h=Object.defineProperty;
c.f=g(12)?Object.defineProperty:function a(k,i,l){b(k);
i=d(i,true);
b(l);
if(f){try{return h(k,i,l)
}catch(j){}}if("get" in l||"set" in l){throw TypeError("Accessors not supported!")
}if("value" in l){k[i]=l.value
}return k
}
}),(function(c,b,d){var a=d(11);
c.exports=function(e){if(!a(e)){throw TypeError(e+" is not an object!")
}return e
}
}),(function(b,a,c){b.exports=!c(12)&&!c(30)(function(){return Object.defineProperty(c(72)("div"),"a",{get:function(){return 7
}}).a!=7
})
}),(function(d,c,f){var b=f(11);
var a=f(6).document;
var e=b(a)&&b(a.createElement);
d.exports=function(g){return e?a.createElement(g):{}
}
}),(function(c,b,d){var a=d(11);
c.exports=function(g,e){if(!a(g)){return g
}var f,h;
if(e&&typeof(f=g.toString)=="function"&&!a(h=f.call(g))){return h
}if(typeof(f=g.valueOf)=="function"&&!a(h=f.call(g))){return h
}if(!e&&typeof(f=g.toString)=="function"&&!a(h=f.call(g))){return h
}throw TypeError("Can't convert object to primitive value")
}
}),(function(b,a){b.exports=function(d,c){return{enumerable:!(d&1),configurable:!(d&2),writable:!(d&4),value:c}
}
}),(function(e,f,d){var b=d(6);
var g=d(29);
var j=d(31);
var i=d(32)("src");
var k="toString";
var h=Function[k];
var a=(""+h).split(k);
d(7).inspectSource=function(l){return h.call(l)
};
(e.exports=function(n,l,p,m){var o=typeof p=="function";
if(o){j(p,"name")||g(p,"name",l)
}if(n[l]===p){return
}if(o){j(p,i)||g(p,i,n[l]?""+n[l]:a.join(String(l)))
}if(n===b){n[l]=p
}else{if(!m){delete n[l];
g(n,l,p)
}else{if(n[l]){n[l]=p
}else{g(n,l,p)
}}}})(Function.prototype,k,function c(){return typeof this=="function"&&this[i]||h.call(this)
})
}),(function(c,b,d){var a=d(77);
c.exports=function(e,g,f){a(e);
if(g===undefined){return e
}switch(f){case 1:return function(h){return e.call(g,h)
};
case 2:return function(i,h){return e.call(g,i,h)
};
case 3:return function(i,h,j){return e.call(g,i,h,j)
}
}return function(){return e.apply(g,arguments)
}
}
}),(function(b,a){b.exports=function(c){if(typeof c!="function"){throw TypeError(c+" is not a function!")
}return c
}
}),(function(b,a,c){var f=c(79);
var e=c(13);
var d=c(91).f;
b.exports=function(g){return function(l){var o=e(l);
var n=f(o);
var m=n.length;
var k=0;
var h=[];
var j;
while(m>k){if(d.call(o,j=n[k++])){h.push(g?[j,o[j]]:o[j])
}}return h
}
}
}),(function(c,b,f){var a=f(80);
var e=f(90);
c.exports=Object.keys||function d(g){return a(g,e)
}
}),(function(d,a,f){var b=f(31);
var g=f(13);
var e=f(84)(false);
var c=f(87)("IE_PROTO");
d.exports=function(j,n){var m=g(j);
var l=0;
var h=[];
var k;
for(k in m){if(k!=c){b(m,k)&&h.push(k)
}}while(n.length>l){if(b(m,k=n[l++])){~e(h,k)||h.push(k)
}}return h
}
}),(function(b,a,c){var d=c(82);
b.exports=Object("z").propertyIsEnumerable(0)?Object:function(e){return d(e)=="String"?e.split(""):Object(e)
}
}),(function(b,a){var c={}.toString;
b.exports=function(d){return c.call(d).slice(8,-1)
}
}),(function(b,a){b.exports=function(c){if(c==undefined){throw TypeError("Can't call method on  "+c)
}return c
}
}),(function(c,b,e){var f=e(13);
var a=e(85);
var d=e(86);
c.exports=function(g){return function(n,j,i){var m=f(n);
var k=a(m.length);
var h=d(i,k);
var l;
if(g&&j!=j){while(k>h){l=m[h++];
if(l!=l){return true
}}}else{for(;
k>h;
h++){if(g||h in m){if(m[h]===j){return g||h||0
}}}}return !g&&-1
}
}
}),(function(d,b,e){var a=e(33);
var c=Math.min;
d.exports=function(f){return f>0?c(a(f),9007199254740991):0
}
}),(function(e,c,f){var b=f(33);
var a=Math.max;
var d=Math.min;
e.exports=function(g,h){g=b(g);
return g<0?a(g+h,0):d(g,h)
}
}),(function(c,a,e){var d=e(88)("keys");
var b=e(32);
c.exports=function(f){return d[f]||(d[f]=b(f))
}
}),(function(d,c,g){var a=g(7);
var e=g(6);
var f="__core-js_shared__";
var b=e[f]||(e[f]={});
(d.exports=function(h,i){return b[h]||(b[h]=i!==undefined?i:{})
})("versions",[]).push({version:a.version,mode:g(89)?"pure":"global",copyright:"© 2018 Denis Pushkarev (zloirock.ru)"})
}),(function(b,a){b.exports=false
}),(function(b,a){b.exports=("constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf").split(",")
}),(function(b,a){a.f={}.propertyIsEnumerable
}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(d,e,c){var g=c(8);
var h=c(36);
var a=c(14);
var b=c(2);
var i=c(35);
function f(j,k){if(!(j instanceof k)){throw new TypeError("Cannot call a class as a function")
}}(function(o){var r={results:".search-results",pagination:".generic-pagination",dataConfig:"[data-config]",dataServerErrorPageUrl:"[data-server-error-page-url]",noResults:".no-results",spellingSuggestionLink:".search-spelling-suggestion-link",spellingSuggestionContainer:".search-spelling-suggestion-container"},n={hidden:"hidden"},p={page:"page",config:"config",serverErrorPageUrl:"server-error-page-url"},m={resultsPageSize:8,moduleName:"searchRender",moduleSelector:".O-SRCHRES-RW-RBWM",moduleSearchField:".O-HEROBANWSRCH-RW-DEV"},q={spinner:"search-spinner",resultsNumber:"search-results-number",result:"search-result",noResults:"search-no-results",spellingSuggestion:"search-spelling-suggestion"},j={query:"q",tags:"tags"};
var l=function(){function O(Q,R){f(this,O);
this.$el=o(Q);
this.queryStringState=new i.QueryStringState(j,this.buildSearchName.bind(this),this.updateSearchState.bind(this));
this.searchField=new h.SearchField(o(m.moduleSearchField),this.onSubmit.bind(this),this.queryStringState.currentState.query);
this.config=this.$el.find(r.dataConfig).data(p.config);
this.serverErrorPageUrl=this.$el.find(r.dataServerErrorPageUrl).data(p.serverErrorPageUrl);
this.$pagination=this.$el.find(r.pagination);
this.$results=this.$el.find(r.results);
this.resultsPageSize=R||m.resultsPageSize;
this.$spellingSuggestionContainer=this.$el.find(r.spellingSuggestionContainer);
this.searchService=new g.SearchService(this.config,this.resultsPageSize);
this.setMustacheTemplates();
this.displayPageResult(this.queryStringState.currentState.query,1)
}O.prototype.buildSearchName=function P(R,Q){return"Search: "+Q
};
O.prototype.updateSearchState=function M(Q){this.displayPageResult(Q.query,Q.page||0);
this.searchField.setSearchField(Q.query)
};
O.prototype.setMustacheTemplates=function I(){var Q=this;
o.Mustache.options.warnOnMissingTemplates=true;
Object.keys(q).forEach(function(R){var S=q[R],T=Q.$el.find("."+S);
o.Mustache.add(S,T.html())
})
};
O.prototype.displaySpinner=function v(){this.$results.empty().mustache(q.spinner,{})
};
O.prototype.displayPageResult=function A(S,Q){var R=this;
var T={page:Q||1,query:S,requiredfields:this.getRequiredFields()};
this.searchField.updateTags(T.requiredfields);
if(T.query){this.displaySpinner(T.query);
this.searchService.getSearchResults(T).done(function(V){var U=V.results.numberOfResults;
R.renderSpellingSuggestion(V.results);
if(U==0){R.renderNoResults({query:V.results.queryString})
}else{R.renderSearchResults(V);
if(U>R.resultsPageSize){R.renderSearchPagination(V).done(function(W){return R.displayPageResult(S,W.page)
})
}}R.trackSearchEvent(V);
R.rememberSuggestionOrEmpty(window.sessionStorage,R.suggestionWordOrEmpty(V));
R.searchField.setTrigger("free text")
}).fail(function(){return R.redirectToServerErrorPage()
})
}};
O.prototype.trackSearchEvent=function x(S){var R=S.results.numberOfResults;
var Q=this.countOfSearchesPerformed(window.sessionStorage);
this.setCountOfSearchesPerformed(window.sessionStorage,++Q);
b.TealiumUtils.trackEvent({internal_search_term:S.results.queryString,internal_search_results:R>0?R:"0",previous_page:this.previousPageOrRollBackToCurrent(window.document),internal_search_null:this.emptyResultSetAndNoSuggestions(S)?1:0,internal_search:1,internal_searches_pagination:{perPage:m.resultsPageSize,pages:this.countOfPages(S.results.numberOfResults,m.resultsPageSize)},internal_searches:Q,internal_search_output:this.rememberedSuggestionOrEmpty(window.sessionStorage)})
};
O.prototype.rememberSuggestionOrEmpty=function J(R,Q){return R.setItem(m.spellingSuggestion,Q)
};
O.prototype.rememberedSuggestionOrEmpty=function C(Q){return Q.getItem(m.spellingSuggestion)||""
};
O.prototype.suggestionWordOrEmpty=function L(Q){return Q&&Q.results&&Q.results.suggestion?Q.results.suggestion:""
};
O.prototype.previousPageOrRollBackToCurrent=function F(Q){return Q.referrer||Q.URL
};
O.prototype.emptyResultSetAndNoSuggestions=function B(Q){return !(Q&&Q.results&&(Q.results.numberOfResults||Q.results.suggestion))
};
O.prototype.setCountOfSearchesPerformed=function E(R,Q){R.setItem(m.moduleName,Q)
};
O.prototype.countOfSearchesPerformed=function y(R){var Q=R.getItem(m.moduleName);
return Q>0?Q:0
};
O.prototype.redirectToServerErrorPage=function G(){document.location=this.serverErrorPageUrl
};
O.prototype.renderNoResults=function z(Q){this.$results.empty().mustache(q.noResults,Q);
this.$results.find(r.noResults).removeClass(n.hidden);
if(this.pagination){this.pagination.destroy()
}};
O.prototype.renderSpellingSuggestion=function N(R){var Q=this;
this.$spellingSuggestionContainer.empty();
if(R.suggestion){this.$spellingSuggestionContainer.mustache(q.spellingSuggestion,R);
this.$el.find(r.spellingSuggestionLink).on("click",function(S){Q.searchField.setSearchField(R.suggestion);
Q.searchField.setTrigger("auto");
Q.searchField.$form.trigger("submit");
S.preventDefault();
Q.$spellingSuggestionContainer.empty()
})
}};
O.prototype.renderSearchResults=function w(R){var Q=this;
this.$results.empty().mustache(q.resultsNumber,{count:R.results.numberOfResults});
o(R.results.rows).each(function(S,T){Q.$results.mustache(q.result,{url:T.url,title:T.title,screenReaderText:T.screenReaderText||"",summary:T.summary})
})
};
O.prototype.renderSearchPagination=function D(S){var Q=this.countOfPages(S.results.numberOfResults,m.resultsPageSize),R=S.params.page||1,T=o.Deferred();
this.pagination=new a.Pagination(this.$pagination,Q,R);
this.pagination.getPaginationControls().on("click",function(U){T.resolve(o(U.target).data(S.page));
U.preventDefault()
});
return T.promise()
};
O.prototype.countOfPages=function u(Q,R){return Math.ceil(Q/R)
};
O.prototype.onSubmit=function H(Q){this.queryStringState.updateParameter("q",Q);
this.displayPageResult(Q,1)
};
O.prototype.getTags=function t(){return this.queryStringState.currentState.tags
};
O.prototype.getRequiredFields=function K(){var Q=this.getTags();
if(Q){return"tag:"+Q
}return undefined
};
return O
}();
var k={name:"search-render",selector:".O-SRCHRES-RW-RBWM",init:function s(t){return new l(t)
}};
HSBC_utils.registerComponent(k)
})(Bootstrap.jQuery)
}),(function(b,a,c){}),(function(d,c,f){var b=f(38);
var a=f(0);
function e(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}(function(l){var h={activeClass:"is-active",hidden:"hidden"},k={pageHeader:".header",tabTitleItemLink:".tab-widget-link",tabTitleItemClass:".tab-widget-item",tabContent:".tab-widget-tab-content",tabsContainer:".tab-widget-tabs",tabListContainer:".tab-widget-list"},m=10;
var g=false;
var i=function(){function r(w){e(this,r);
this.$el=l(w);
this.$tabsMenuItem=this.$el.find(k.tabTitleItemClass);
this.$tabsMenuLink=this.$el.find(k.tabTitleItemLink);
this.$tabsContent=this.$el.find(k.tabContent);
this.$tabsContainer=this.$el.find(k.tabsContainer);
this.$elementsWithInlineStyleHeight=this.$tabsContent.find("[style*='height']");
this.$tabListContainer=this.$el.find(k.tabListContainer);
this.smartTabsAlly=new b.SmartTabsAlly(this);
this.bindUIEvents();
this.setUpAnchors();
this.setHeight(this.$elementsWithInlineStyleHeight);
this.tealiumObserver=new a.TealiumObserver(this.$tabsMenuLink,{event_type:"click",event_category:"content",event_action:"tab",event_content:function x(y){return decodeURI(l(y).attr("href")||l(y).parents(".A-EXPCNT-RW-RBWM").siblings(".anchor").attr("id")).replace("#","")
}})
}r.prototype.setUpAnchors=function t(){var A=this.$tabsMenuItem.find('a[data-target="'+window.location.hash+'"]');
if(A.length){var z=this.$el,w=l(k.pageHeader).first(),y=l.inArray(w.css("position"),["fixed","absolute"]),x=Math.round((z?z.offset().top:0)-(w&&y!==-1?w.outerHeight():0)-m);
this.togglePanel(A);
if(g){g=false
}else{if(document.readyState==="complete"){window.scrollTo(0,x)
}else{l(document).ready(function(){return window.scrollTo(0,x)
})
}}}};
r.prototype.bindUIEvents=function s(){var w=this;
this.smartTabsAlly.bindUIEvents();
this.$tabsMenuItem.find("a").on("click",function(y){var x=l(y.target),z=x.attr("data-target");
w.hashChange(z);
x.focus();
y.preventDefault()
});
l(window).on("hashchange",function(x){w.setUpAnchors();
x.preventDefault()
}).on("resize",function(){return w.setHeight(w.$elementsWithInlineStyleHeight)
})
};
r.prototype.hashChange=function q(x){var w=l(x);
x=x.replace("#","");
w.attr("id","");
document.location.hash=x.length?x:"";
w.attr("id",x);
g=true
};
r.prototype.togglePanel=function u(w){var y=w.attr("data-target"),x=this.$el.find(y);
if(!w.hasClass(h.activeClass)){this.cleanElements();
this.setSelectedElement(w,x)
}};
r.prototype.cleanElements=function v(){this.$tabsMenuLink.removeClass(h.activeClass);
this.$tabsContent.addClass(h.hidden)
};
r.prototype.setSelectedElement=function p(x,w){x.addClass(h.activeClass);
w.removeClass(h.hidden)
};
r.prototype.setHeight=function o(w){w.height("auto")
};
return r
}();
var j={name:"Smart Horizontal Tabs",selector:".O-HRZTAB-RW-RBWM",init:function n(o){return new i(o)
}};
HSBC_utils.registerComponent(j)
})(Bootstrap.jQuery)
}),(function(b,a,c){}),(function(b,a){b.exports=function(c){if(!c.webpackPolyfill){c.deprecate=function(){};
c.paths=[];
if(!c.children){c.children=[]
}Object.defineProperty(c,"loaded",{enumerable:true,get:function(){return c.l
}});
Object.defineProperty(c,"id",{enumerable:true,get:function(){return c.i
}});
c.webpackPolyfill=1
}return c
}
}),(function(b,a,d){function c(e,f){if(!(e instanceof f)){throw new TypeError("Cannot call a class as a function")
}}(function(g){var f={header:".header",exclude:".O-HRZTAB-RW-RBWM,.O-VRTTAB-RW-RBWM,.O-HRTAB-RW-RBWM",tabListClasses:".tab-widget-list",tabPanelClasses:".tab-widget-tabs",tabPanelContentClasses:".tab-widget-tab-content"},h=10;
var e=function(){function j(n){c(this,j);
this.$element=g(n);
this.bindUIEvents();
window.anchorsFuncionalityLoadedOnce=false
}j.prototype.bindUIEvents=function l(){var n=this;
g(window).on("load",function(o){if(!window.anchorsFuncionalityLoadedOnce){window.anchorsFuncionalityLoadedOnce=true;
n.checkAnchorRoots(o,window.location.hash)
}});
this.$element.on("click",function(o){return n.checkAnchorRoots(o)
})
};
j.prototype.scrollFire=function m(p){var o=g(f.header).first(),s=g(p),n=s.next().length===0?s:s.next(),r=g.inArray(o.css("position"),["fixed","absolute"]),t=Math.round((s&&s.offset()?s.offset().top:0)-(o&&r!==-1?o.outerHeight():0)-h),q=Math.round(g(window).scrollTop());
if(n.length===1&&q!==t){if(window.location.hash!==p){window.location.hash=p
}setTimeout(function(){g(window).scrollTop(t)
},10);
n.attr("tabindex",-1).focus()
}};
j.prototype.checkAnchorRoots=function k(n){var s=this;
var q=arguments.length>1&&arguments[1]!==undefined?arguments[1]:null;
var t="",u=false;
if(q!==null){t=q
}else{var o=g(n.target);
t=o.attr("href")||o.parent().attr("href"),u=o.parents(f.tabListClasses).length>0
}var v=false,r,p;
if(t!="#"){v=g(t).parent(f.tabPanelClasses).length>0,r=g(t).parents(f.tabPanelContentClasses),p=r.length>0
}if(p){var w=r[0].id;
n.preventDefault();
window.location.hash=w
}setTimeout(function(){if(!u){window.location.hash="";
window.location.hash=t
}if(t.length>1&&!v){n.preventDefault();
setTimeout(s.scrollFire(t),100)
}},0)
};
return j
}();
HSBC_utils.registerComponent({name:"anchor",selector:'a[href^="#"]',init:function i(j){return new e(j)
}})
})(Bootstrap.jQuery)
}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(c,b,e){var a=e(41);
function d(f,g){if(!(f instanceof g)){throw new TypeError("Cannot call a class as a function")
}}(function(j){var h={link:"A-MODLNK-RW-ALL",modal:"A-MOD-RW-ALL",modalOverlay:"modal-overlay",closeTrigger:"close-trigger",isVisible:"is-visible",hide:"hidden",modalAnnouncement:"modal-announcement-sr-text"},g={animation:200},i=j("body");
var k=function(){function u(x){d(this,u);
this.$link=j(x);
this.$modal=null;
this.bindUIEvents();
this.allyModule=new a.ModalAlly(this)
}u.prototype.bindUIEvents=function o(){var x=this;
this.$link.on("click",function(y){return x.linkClickHandler(y)
});
this.$link.on("modal:switchedToEdit",function(y){return x.close()
})
};
u.prototype.linkClickHandler=function w(x){x.preventDefault();
if(!HSBC_utils.isEditMode()){if(!this.$modal){this.getMarkup()
}else{this.open()
}}};
u.prototype.getMarkup=function t(){var z=this;
var y=this.$link.attr("href");
if(!y){return
}j.ajax({type:"GET",dataType:"HTML",url:y,success:function A(B){z.setUpModalWindow(B);
z.open()
},error:function x(B){return console.error(B)
}})
};
u.prototype.open=function s(){var x=this.$closeTriggers.first();
this.$modal.addClass(h.isVisible).siblings().attr("aria-hidden","true");
setTimeout(function(){return x.focus()
},g.animation)
};
u.prototype.close=function v(){if(this.$modal){var x=this.$modal.find("."+h.modalAnnouncement);
x.removeClass(h.hide);
this.$modal.removeClass(h.isVisible).siblings().removeAttr("aria-hidden")
}this.$link.focus()
};
u.prototype.setUpModalWindow=function p(y){var x=j(y).filter("."+h.modalOverlay);
x.removeClass(h.isVisible);
i.append(x);
this.$modal=i.children().last("."+h.modalOverlay);
this.cacheModalElements();
this.lateBindUIEvents()
};
u.prototype.cacheModalElements=function q(){this.$closeTriggers=this.$modal.find("."+h.closeTrigger)
};
u.prototype.lateBindUIEvents=function r(){var x=this;
this.$closeTriggers.on("click",function(y){return x.close()
});
this.$modal.on("click",function(z){var y=j(z.target);
if(!l(y)&&!y.hasClass(h.modal)){x.close()
}});
this.allyModule.bindUIEvents()
};
return u
}();
function l(o){return o.parents("."+h.modal).length
}function m(){j("."+h.link).trigger("modal:switchedToEdit")
}var f={name:"modal",selector:".A-MODLNK-RW-ALL",init:function n(o){return new k(o)
},switchToEditHandler:m};
HSBC_utils.registerComponent(f)
})(Bootstrap.jQuery)
}),(function(b,a,e){var c=e(107);
function d(f,g){if(!(f instanceof g)){throw new TypeError("Cannot call a class as a function")
}}(function(h){var n={activeClass:"is-active",expandedClass:"is-expanded",selectedClass:"is-selected",onTop:"on-top"},k={tabTitleItemClass:".tab-title-item",tabPanelItemClass:".tab-panel",pageHeader:".header",tabsMenu:".tabs",tabsContent:".tabs-content",simpleTable:".M-SMPTBL-RW-RBWM",calculatorLabelLeft:".heading-left",calculatorLabelRight:".heading-right"},i={tabSwitched:"tabs:tabSwitched"};
var l=false;
var f=function(){function p(y){d(this,p);
this.$el=h(y);
this.$tabsMenu=this.$el.find(k.tabsMenu);
this.$tabsContent=this.$el.find(k.tabsContent);
this.$tabs=this.$tabsMenu.find(k.tabTitleItemClass);
this.$tabsLinks=this.$tabs.find("a");
this.$panels=this.$tabsContent.find(k.tabPanelItemClass);
this.$activePanel=this.$tabsContent.find("."+n.activeClass);
this.$simpleTables=this.$tabsContent.find(k.simpleTable);
this.bindUIEvents();
this.ally=new c.TabsAlly(this);
this.setUpAnchors()
}p.prototype.setUpAnchors=function s(){var A=this.$tabsMenu.find('a[data-target="'+window.location.hash+'"]');
if(A.length){var y=h(k.pageHeader).height(),z=this.$el.offset().top-y;
this.togglePanel(A);
if(l){l=false
}else{if(document.readyState==="complete"){window.scrollTo(0,z)
}else{h(document).ready(function(){return window.scrollTo(0,z)
})
}}}};
p.prototype.bindUIEvents=function o(){var y=this;
this.$tabsMenu.find("a").on("click",function(z){return y.tabsMenuClickHandler(z)
});
h(window).on("hashchange",function(z){y.setUpAnchors();
y.ally.setAriaSelectedTags();
z.preventDefault()
})
};
p.prototype.tabsMenuClickHandler=function q(z){var y=h(z.target);
this.togglePanel(y);
this.tabsMenuEvents(y);
this.setEqualHeightsOfLabelsInChinaCalculator();
this.$simpleTables.trigger(i.tabSwitched);
z.preventDefault()
};
p.prototype.tabsMenuEvents=function r(z){var A=this.$tabsContent.find("."+n.activeClass),y=A.find(HSBC_utils.focusables.join()).add(this.$tabsContent);
y.attr("tabindex",0);
this.focusWithoutScrolling(y.first());
this.ally.setTabIndexesOnFocusLeave();
j(z.attr("data-target"))
};
p.prototype.togglePanel=function w(y){var z=y.attr("data-target").replace("#","#panel-"),B=this.$tabsContent.find(z),A=y.parent();
if(!A.hasClass(n.activeClass)){this.cleanElements();
p.setSelectedElement(A,B);
this.ally.setAriaSelectedTags()
}};
p.prototype.cleanElements=function t(){this.$panels.removeClass(n.activeClass);
this.$tabs.removeClass(n.activeClass+" "+n.selectedClass)
};
p.setSelectedElement=function u(y,z){z.addClass(n.activeClass);
y.addClass(n.activeClass)
};
p.prototype.focusWithoutScrolling=function x(A){var C=document.documentElement,z=window.pageXOffset!==undefined?window.pageXOffset:C.scrollLeft,B=window.pageYOffset!==undefined?window.pageYOffset:C.scrollTop;
A.focus();
window.scrollTo(z,B)
};
p.prototype.setEqualHeightsOfLabelsInChinaCalculator=function v(){var A=this.$tabsContent.find("."+n.activeClass),y=A.find(k.calculatorLabelLeft),z=A.find(k.calculatorLabelRight);
y.height("auto");
z.height("auto");
if(!HSBC_utils.matchMedia.mobile){var C=[y,z],D=[y.outerHeight(),z.outerHeight()],B=Math.max.apply(Math,D);
C.forEach(function(E){return E.outerHeight(B)
})
}};
return p
}();
function j(p){var o=h(p);
p=p.replace("#","");
o.attr("id","");
document.location.hash=p.length?p:"";
o.attr("id",p);
l=true
}var g={name:"tabs-tablet-desktop",selector:".generic-tabs.hide-on-mobile",init:function m(o){return new f(o)
}};
HSBC_utils.registerComponent(g)
})(Bootstrap.jQuery)
}),(function(d,b,h){b.__esModule=true;
function g(i,j){if(!(i instanceof j)){throw new TypeError("Cannot call a class as a function")
}}var f=Bootstrap.jQuery,c=HSBC_utils.keyCodes,a={activeClass:"is-active"};
var e=b.TabsAlly=function(){function l(o){g(this,l);
this.$el=o.$el;
this.$tabsMenu=o.$tabsMenu;
this.$tabsContent=o.$tabsContent;
this.$tabsLinks=o.$tabsLinks;
this.$panelFocusables=this.$tabsContent.find(HSBC_utils.focusables.join()).add(this.$tabsContent);
this.context=o;
this.setAriaSelectedTags();
this.bindUIEvents()
}l.prototype.bindUIEvents=function j(){var p=this;
var o=this.$tabsContent.find(HSBC_utils.focusables.join()).add(this.$tabsContent);
o.on("keydown",function(q){return p.tabsContentKeyEvents(q)
});
this.$tabsMenu.find("a").on("keydown",function(q){return p.tabsMenuKeyHandler(q)
});
this.$tabsLinks.on("focus",function(){p.$tabsContent.attr("tabindex",0);
p.$tabsLinks.attr("tabindex",0)
})
};
l.prototype.tabsMenuKeyHandler=function k(t){var r=t.keyCode,q=f(t.target),p=r===c.SPACE,o=r===c.ENTER,u=r===c.TAB&&!t.shiftKey,s=q.is(this.$tabsLinks.last());
if(o||p){this.context.tabsMenuClickHandler(t)
}else{if(u&&s){this.setTabIndexesOnFocusLeave()
}}};
l.prototype.tabsContentKeyEvents=function n(q){var o=q.keyCode,p=this.$tabsMenu.find("."+a.activeClass+" a");
if(o===c.ESC){this.context.focusWithoutScrolling(p);
q.preventDefault()
}};
l.prototype.setTabIndexesOnFocusLeave=function i(){var o=this.$tabsMenu.find("."+a.activeClass+" a");
this.$tabsContent.attr("tabindex",-1);
this.$tabsLinks.attr("tabindex",-1);
o.attr("tabindex",0)
};
l.prototype.setAriaSelectedTags=function m(){this.$tabsLinks.attr("aria-selected",false);
this.$tabsMenu.find("."+a.activeClass+" a").attr("aria-selected",true)
};
return l
}()
}),(function(b,a,e){var c=e(109);
function d(f,g){if(!(f instanceof g)){throw new TypeError("Cannot call a class as a function")
}}(function(g){var n={activeClass:"is-active",expandedClass:"is-expanded",selectedClass:"is-selected",onTop:"on-top"},k={tabTitleItemClass:".tab-title-item",tabPanelItemClass:".tab-panel",pageHeader:".header",tabsMenu:".tabs",tabsContent:".tabs-content",simpleTable:".M-SMPTBL-RW-RBWM"},i={tabSwitched:"tabs:tabSwitched"};
var l=false;
var h=function(){function t(B){d(this,t);
this.$el=g(B);
this.$tabsMenu=this.$el.find(k.tabsMenu);
this.$tabsContent=this.$el.find(k.tabsContent);
this.$tabs=this.$tabsMenu.find(k.tabTitleItemClass);
this.$tabsLinks=this.$tabs.find("a");
this.$panels=this.$tabsContent.find(k.tabPanelItemClass);
this.$simpleTables=this.$tabsContent.find(k.simpleTable);
this.bindUIEvents();
this.ally=new c.TabsMobileAlly(this);
this.setUpAnchors()
}t.prototype.setUpAnchors=function u(){var E=window.location.hash+"-mobile-anchor",D=this.$tabsMenu.find('a[data-target="'+E+'"]'),C=this.$tabsContent.find(E.replace("#","#panel-"));
if(D.length){var B=g(k.pageHeader).height();
this.cleanElements();
this.setSelectedElement(D.parent(),C);
if(l){l=false
}else{if(document.readyState==="complete"){window.scrollTo(0,this.$el.offset().top-B)
}}}this.ally.setAriaSelectedTags()
};
t.prototype.bindUIEvents=function o(){var C=this;
var B=g(k.pageHeader).height();
this.$tabsMenu.find("a").on("click",function(D){return C.tabsMenuClickHandler(D)
});
g(window).on("resize",function(){return t.resizeHandler()
}).on("hashchange",function(D){if(HSBC_utils.matchMedia.mobile){C.setUpAnchors();
C.ally.setUpAttributes();
D.preventDefault()
}});
g(document).ready(function(){return window.scrollTo(0,C.$el.offset().top-B)
})
};
t.prototype.tabsMenuClickHandler=function r(C){var B=g(C.target);
this.toggleDropdown(B);
this.tabsMenuEvents(B);
this.$simpleTables.trigger(i.tabSwitched);
C.preventDefault()
};
t.prototype.tabsMenuEvents=function s(C){var E=this.$tabsContent.find("."+n.activeClass),F=this.$tabsMenu.find("."+n.activeClass+" a"),B=E.find(HSBC_utils.focusables.join()).add(this.$tabsContent),D=this.$tabsMenu.hasClass(n.expandedClass);
B.attr("tabindex",D?-1:0);
if(D){t.focusWithoutScrolling(F)
}else{this.$tabsContent.attr("tabindex",0);
t.focusWithoutScrolling(B.first());
this.ally.setTabIndexesOnFocusLeave();
j(C.data("target"))
}t.focusWithoutScrolling(F)
};
t.prototype.toggleDropdown=function A(B){var D=B.attr("data-target").replace("#","#panel-"),F=this.$tabsContent.find(D),E=B.parent(),C=this.$tabsMenu.hasClass(n.expandedClass);
if(C){this.collapse(E,F)
}else{this.expand()
}};
t.prototype.expand=function y(){var B=this.$tabsMenu.find("."+n.activeClass);
this.$tabsMenu.addClass(n.expandedClass);
this.moveElementToTheTop(B);
this.$tabsMenu.addClass(n.onTop)
};
t.prototype.collapse=function x(C,D){var B=this.$tabsMenu.find("."+n.activeClass);
B.remove();
if(C.hasClass(n.activeClass)){this.$tabsMenu.find("."+n.selectedClass).addClass(n.activeClass)
}this.$tabs.removeClass(n.selectedClass);
this.$tabsMenu.removeClass(n.onTop).removeClass(n.expandedClass);
if(!C.hasClass(n.activeClass)){this.cleanElements();
this.setSelectedElement(C,D);
this.ally.setAriaSelectedTags()
}this.ally.setUpAttributes()
};
t.prototype.moveElementToTheTop=function p(B){var C=B.clone(true,true);
C.find("span.active-tab-hidden-text").text(this.ally.accessibility.expandedText);
c.TabsMobileAlly.cleanAccessibilityAttributes(B);
B.parent().prepend(C)
};
t.prototype.cleanElements=function w(){var B=this.$tabsMenu.find("."+n.activeClass);
c.TabsMobileAlly.cleanAccessibilityAttributes(B);
this.$panels.removeClass(n.activeClass);
this.$tabs.removeClass(n.activeClass+" "+n.selectedClass)
};
t.prototype.setSelectedElement=function v(B,C){C.addClass(n.activeClass);
if(B.length>1){B.each(function(D,F){var E=g(F);
if(!E.hasClass(n.selectedClass)){E.addClass(n.activeClass)
}})
}else{B.addClass(n.activeClass)
}};
t.resizeHandler=function q(){if(!HSBC_utils.matchMedia.mobile){return
}};
t.focusWithoutScrolling=function z(C){var B=window.pageXOffset!==undefined?window.pageXOffset:document.documentElement.scrollLeft,D=window.pageYOffset!==undefined?window.pageYOffset:document.documentElement.scrollTop;
C.focus();
window.scrollTo(B,D)
};
return t
}();
function j(p){var o=g(p);
p=p.replace("#","");
o.attr("id","");
document.location.hash=p.length?p.replace("-mobile-anchor",""):"";
o.attr("id",p);
l=true
}var f={name:"tabs-mobile",selector:".generic-tabs.hide-on-tablet-and-desktop",init:function m(o){return new h(o)
}};
HSBC_utils.registerComponent(f)
})(Bootstrap.jQuery)
}),(function(c,e,b){e.__esModule=true;
function f(j,k){if(!(j instanceof k)){throw new TypeError("Cannot call a class as a function")
}}var i={activeClass:"is-active",expandedClass:"is-expanded",selectedClass:"is-selected",onTop:"on-top"},g=Bootstrap.jQuery,h=HSBC_utils.keyCodes,a={defaultPhrases:{collapsed:"Dropdown menu, collapsed",expanded:"Dropdown menu, expanded",selected:"Selected"},properties:{collapsed:"dropdown-collapsed-text",expanded:"dropdown-expanded-text",selected:"dropdown-selected-text"}};
var d=e.TabsMobileAlly=function(){function k(t){f(this,k);
this.$el=t.$el;
this.$tabsMenu=t.$tabsMenu;
this.$tabsContent=t.$tabsContent;
this.$tabsLinks=t.$tabsLinks;
this.context=t;
this.accessibility=this.readAccessibility();
this.setUpAttributes();
this.bindUIEvents()
}k.prototype.setUpAttributes=function l(){var u=this.$tabsMenu.find("."+i.activeClass),t=u.find("a");
if(t.find(".active-tab-hidden-text").length){return
}t.prepend('<span class="visuallyhidden active-tab-hidden-text"> '+this.accessibility.collapsedText+", "+this.accessibility.selectedText+"</span>").attr({"aria-haspopup":"true",role:"button"}).find("span.active-tab-selected-text").attr("aria-hidden","true")
};
k.prototype.bindUIEvents=function j(){var u=this;
var t=this.$tabsContent.find(HSBC_utils.focusables.join()).add(this.$tabsContent);
this.$tabsMenu.find("a").on("keydown",function(v){return u.tabsMenuKeyHandler(v)
});
this.$tabsLinks.on("focus",function(){return u.$tabsLinks.attr("tabindex",0)
});
t.on("keydown",function(v){return u.tabsContentKeyEvents(v)
})
};
k.prototype.tabsMenuKeyHandler=function q(u){var C=u.keyCode,x=g(u.target),y=x.parent(),v=C===h.SPACE,z=C===h.ENTER,w=C===h.DOWN,B=C===h.UP,t=C===h.TAB&&!u.shiftKey,A=x.is(this.$tabsLinks.last());
if(z||v){this.context.tabsMenuClickHandler(u)
}else{if(t&&A){this.setTabIndexesOnFocusLeave()
}else{if(w){this.handleArrowKeyEvent(y,u,true)
}else{if(B){this.handleArrowKeyEvent(y,u,false)
}}}}};
k.prototype.handleArrowKeyEvent=function p(v,x,w){var u=w?"next":"prev",y=v[u](),t=y.hasClass(i.selectedClass)?y[u]().find("a"):y.find("a");
t.focus();
x.preventDefault()
};
k.prototype.setTabIndexesOnFocusLeave=function s(){var t=this.$tabsMenu.find("."+i.activeClass+" a");
this.$tabsContent.attr("tabindex",-1);
this.$tabsLinks.attr("tabindex",-1);
t.attr("tabindex",0)
};
k.prototype.tabsContentKeyEvents=function r(v){var t=v.keyCode,u=this.$tabsMenu.find("."+i.activeClass+" a");
if(t===h.ESC){this.context.focusWithoutScrolling(u);
v.preventDefault()
}};
k.prototype.setAriaSelectedTags=function o(){this.$tabsMenu.find("."+i.activeClass+" a").attr("role","button").find("span.active-tab-selected-text").attr("aria-hidden","true")
};
k.cleanAccessibilityAttributes=function m(t){t.removeClass(i.activeClass).addClass(i.selectedClass).find("a").removeAttr("aria-haspopup").attr("role","menuitem").find("span.active-tab-hidden-text").remove();
t.find("span.active-tab-selected-text").attr("aria-hidden","false")
};
k.prototype.readAccessibility=function n(){return{expandedText:this.$el.data(a.properties.expanded)||a.defaultPhrases.expanded,collapsedText:this.$el.data(a.properties.collapsed)||a.defaultPhrases.collapsed,selectedText:this.$el.data(a.properties.selected)||a.defaultPhrases.selected}
};
return k
}()
}),(function(b,a,d){var e=d(2);
function c(f,g){if(!(f instanceof g)){throw new TypeError("Cannot call a class as a function")
}}(function(i){var m={browserNotification:".browser-notification",closeButton:".close-browser-notification",oldIE:".ie7-9"},g={hidden:"hidden"},j={oldBrowserNotification:"oldBrowserNotification"},k={path:"/",expires:1},l=86400000;
var h=function(){function p(s){c(this,p);
this.$el=i(s);
this.$closeButton=this.$el.find(m.closeButton);
this.showBrowserNotification();
this.bindUiEvents()
}p.prototype.bindUiEvents=function q(){var s=this;
this.$closeButton.on("click",function(){return s.closeBanner()
})
};
p.prototype.showBrowserNotification=function o(){if(i("html").is(m.oldIE)){var s=HSBC_utils.getCookie(j.oldBrowserNotification);
if(!s){this.$el.removeClass(g.hidden);
e.TealiumUtils.trackEvent({event_category:"content",event_action:"popup",event_content:"Browser update banner"})
}}};
p.prototype.closeBanner=function r(){if(!this.$el.hasClass(g.hidden)){HSBC_utils.setCookie(j.oldBrowserNotification,true,k,l);
this.$el.addClass(g.hidden);
e.TealiumUtils.trackEvent({event_category:"content",event_action:"onsite",event_content:"Browser update banner close"})
}};
return p
}();
var f={name:"browserNotification",selector:m.browserNotification,init:function n(o){return new h(o)
}};
HSBC_utils.registerComponent(f)
})(Bootstrap.jQuery)
}),(function(b,a,c){}),(function(b,a,d){var e=d(42);
function c(f,g){if(!(f instanceof g)){throw new TypeError("Cannot call a class as a function")
}}(function(k){var i={expanded:"expanded",active:"active",hidden:"hidden",noSubtitles:"no-subtitles"},h={doormatMenu:".doormat-menu",headerMainMenu:".header-main-navigation",screenreaderText:".screenreader-text",doormatExpanded:".doormat-expanded",doormatCollapsed:".doormat-collapsed",doormatMainColumn:".doormat-main-column",navigationItem:".header-main-navigation-item",subTitle:".header-main-navigation-subtitle",hideOnMobileAndTablet:".hide-on-mobile-and-tablet",columnContent:".doormat-column-content",logoWrapper:".header-logo"},j=k("body");
var g=function(){function s(x){c(this,s);
this.$el=k(x);
this.$navigationItem=this.$el.closest(h.navigationItem);
this.$headerMainMenu=this.$el.parents(h.headerMainMenu);
this.$allDoormatLinks=this.$headerMainMenu.find("a");
this.$doormatExpanded=this.$navigationItem.find(h.doormatExpanded);
this.$doormatCollapsed=this.$navigationItem.find(h.doormatCollapsed);
this.$subTitle=this.$headerMainMenu.find(h.subTitle);
this.$logoWrapper=this.$headerMainMenu.siblings(h.logoWrapper);
this.isEnterHandlerEnabled=false;
this.isInMenu=false;
this.equalizeColumnHeight();
this.bindUiEvents();
this.updateMaxHeight();
new e.DoormatAlly(this)
}s.prototype.adjustLogoWrapperHeight=function r(){this.$logoWrapper.removeAttr("style");
this.$logoWrapper.height(Math.max(this.$logoWrapper.height(),this.$headerMainMenu.height()))
};
s.prototype.equalizeColumnHeight=function u(){var x=this.$el.find(h.doormatMainColumn),y=Math.max.apply(null,x.map(function(z,A){return k(A).find(h.columnContent).height()
}).get());
x.height(y)
};
s.prototype.updateMaxHeight=function w(){var x=k(window).height()-this.$el.offset().top;
this.$el.css("max-height",x)
};
s.prototype.removeActiveClass=function q(){this.$el.removeClass(i.active);
this.$navigationItem.removeClass(i.active)
};
s.prototype.removeActiveClassState=function n(x){x.attr("tabindex",-1);
this.toggleMenuStatusText(true);
this.removeActiveClass();
this.isEnterHandlerEnabled=false;
this.isInMenu=false
};
s.prototype.resize=function p(){this.equalizeColumnHeight();
this.updateMaxHeight()
};
s.prototype.bindUiEvents=function t(){var x=this;
k(window).on("resize",function(){return x.resize()
});
this.$navigationItem.on("focus",function(){if(x.getFocusCondition()){x.$el.addClass(i.active);
x.$navigationItem.addClass(i.active)
}}).on("focusout",function(){if(x.getFocusCondition()){x.removeActiveClass();
x.toggleMenuStatusText()
}});
this.$el.on("mouseout",function(){return x.removeActiveClassState(x.$allDoormatLinks)
});
k(document.body).on("click",function(z){var y=k(z.target);
if(!s.isInDoormat(y)&&!y.hasClass(i.headerMainMenu)){x.removeActiveClassState(x.$allDoormatLinks)
}})
};
s.prototype.toggleMenuStatusText=function v(){var x=arguments.length>0&&arguments[0]!==undefined?arguments[0]:false;
if(x){this.$doormatCollapsed.removeClass(i.hidden);
this.$doormatExpanded.addClass(i.hidden)
}else{this.$doormatCollapsed.addClass(i.hidden);
this.$doormatExpanded.removeClass(i.hidden)
}};
s.prototype.getFocusCondition=function m(){return !(this.isInMenu||this.isEnterHandlerEnabled)
};
s.isInDoormat=function o(x){return !!x.parents("."+i.headerMainMenu).length
};
return s
}();
var f={name:"doormat",selector:h.hideOnMobileAndTablet+" "+h.doormatMenu,init:function l(m){return new g(m)
}};
HSBC_utils.registerComponent(f)
})(Bootstrap.jQuery)
}),(function(b,a,d){function c(e,f){if(!(e instanceof f)){throw new TypeError("Cannot call a class as a function")
}}(function(h){var f={placeholderLeft:".placeholder-left",placeholderRight:".lg-4",cta:".O-PRIMCTA-RW-RBWM"};
var g=function(){function k(m){c(this,k);
this.$el=h(m);
i(this.$el);
this.bindUiEvents()
}k.prototype.bindUiEvents=function l(){var m=this;
h(window).on("resize",function(){i(m.$el)
})
};
return k
}();
function i(k){var n=k.find(f.placeholderLeft),m=k.find(f.placeholderRight),l=m.find(f.cta),o=l.outerHeight(true)-l.outerHeight(false);
n.height("auto");
if(HSBC_utils.matchMedia.tablet||HSBC_utils.matchMedia.desktop){if(m.outerHeight()-o>=n.outerHeight()){n.height(m.outerHeight()-o)
}}}var e={name:"equalize",selector:".equalize",init:function j(k){return new g(k)
}};
HSBC_utils.registerComponent(e)
})(Bootstrap.jQuery)
}),(function(b,a,d){function c(e,f){if(!(e instanceof f)){throw new TypeError("Cannot call a class as a function")
}}(function(h){var f={footer:"footer",footerMobileSubmenuWrapper:"sidebar-submenu-wrapper",mobileSidebar:"header-mobile-sidebar",headerDoormatMobile:"header-mobile-doormat",headerMobileFooterItem:"header-mobile-footer-item",headerMobileFooterItemWrapper:"header-mobile-footer-item-wrapper",footerLarge:"footer-large",footerSupplementary:"footer-supplementary",headerMobileFooterMenu:"header-mobile-footer-menu",footerTrigger:"sidebar-submenu-trigger",headerMobileTitle:"header-doormat-mobile-title",opinionLabTrigger:"opinion-lab-trigger"};
var g=function(){function m(p){c(this,m);
this.$el=h(p);
this.bindUIElements();
this.createFooterMobileElements();
this.buildFooterMobile();
this.bindUIEvents()
}m.prototype.bindUIElements=function j(){this.$mobileSidebar=h("."+f.mobileSidebar);
this.$headerDoormatMobile=this.$mobileSidebar.find("."+f.headerDoormatMobile);
this.$headerMobileFooterItem=this.$el.find("."+f.headerMobileFooterItem);
this.$headerMobileFooterItemWrapper=this.$el.find("."+f.headerMobileFooterItemWrapper);
this.$footerLarge=this.$el.find("."+f.footerLarge).clone();
this.$footerSupplementary=this.$el.find("."+f.footerSupplementary).clone()
};
m.prototype.bindUIEvents=function k(){var p=this;
h(document).on("click","."+f.opinionLabTrigger,function(q){q.preventDefault();
p.opinionLabShow(q)
})
};
m.prototype.createFooterMobileElements=function o(){this.$footerMobileMenu=h("<div>",{"class":f.headerMobileFooterMenu+" "+f.footerMobileSubmenuWrapper,"data-source":"mobile-footer"})
};
m.prototype.buildFooterMobile=function n(){this.$headerMobileFooterItem.find("."+f.headerMobileTitle).data("target","mobile-footer").addClass(f.footerTrigger);
this.$headerDoormatMobile.append(this.$headerMobileFooterItem);
this.$headerMobileFooterItemWrapper.remove();
this.$footerMobileMenu.insertAfter(this.$headerDoormatMobile);
this.$footerMobileMenu.append(this.$footerLarge).append(this.$footerSupplementary)
};
m.prototype.opinionLabShow=function l(q){var p=window.oo_feedback||(window.OOo?window.OOo.oo_feedback:null);
if(p){p.show(q)
}};
return m
}();
var e={name:"footer",selector:"."+f.footer,init:function i(j){return new g(j)
}};
HSBC_utils.registerComponent(e)
})(Bootstrap.jQuery)
}),(function(d,b,f){var a=f(15);
var c=f(117);
function e(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}(function(m){var l={active:"is-active",hidden:"hidden",headerSearchBlack:"header-search-black"},k={desktopClearCircle:".header-clear-container",searchBox:".search-box",searchButton:".header-search-button",pageOverlay:".page-overlay",headerSearch:".header-search"},h=m(k.pageOverlay),i=HSBC_utils.keyCodes;
var g=function(){function u(y){e(this,u);
this.$el=m(y);
this.$desktopClearCircle=this.$el.find(k.desktopClearCircle);
this.$searchBox=this.$el.find(k.searchBox);
this.$searchButton=this.$el.find(k.searchButton);
if(!u.isVirtualAssistant()){this.suggestions=new a.SearchMobileSuggestions(this.$el)
}this.bindUIEvents();
this.manageClearCircleVisibility();
this.manageTypeOfSearchButton();
new c.DesktopSearchAlly(this)
}u.prototype.bindUIEvents=function p(){var y=this;
this.$searchButton.on("click",function(){return y.toggleSearchBox()
});
this.$desktopClearCircle.on("click",function(){y.clearSearchBox();
y.manageClearCircleVisibility()
});
this.$el.on("focusout",function(z){var A=m(z.relatedTarget).closest(k.headerSearch).length;
if(!A){h.addClass(l.hidden)
}}).on("focusin",function(A){var z=m(A.target).is(y.$searchButton),B=y.$searchBox.val()==="";
if(!(z&&B)){h.removeClass(l.hidden)
}else{h.addClass(l.hidden)
}});
if(u.isVirtualAssistant()){m(document).on("keyup",function(z){if(z.keyCode===i.ESC){y.fixVirtualAssistantSearchExit()
}}).on("mouseup",function(){return y.fixVirtualAssistantSearchExit()
})
}};
u.prototype.clearSearchBox=function s(){this.$searchBox.val("").focus();
this.manageTypeOfSearchButton()
};
u.prototype.isExpanded=function o(){return this.$searchBox.hasClass(l.active)
};
u.prototype.isSearchBoxEmpty=function q(){return !this.$searchBox.val().length
};
u.prototype.toggleSearchBox=function v(){if(this.isExpanded()&&this.isSearchBoxEmpty()){this.$searchBox.removeClass(l.active);
this.$el.addClass(l.headerSearchBlack)
}else{this.$searchBox.addClass(l.active);
this.$el.removeClass(l.headerSearchBlack);
this.$searchBox.focus()
}};
u.prototype.manageClearCircleVisibility=function w(){var y=this.isSearchBoxEmpty()?"none":"inline-block";
this.$desktopClearCircle.css("display",y)
};
u.prototype.manageTypeOfSearchButton=function r(){var y=this.isSearchBoxEmpty()?"button":"submit";
this.$searchButton.attr("type",y)
};
u.prototype.fixVirtualAssistantSearchExit=function x(){var y=this;
setTimeout(function(){if(y.$searchBox.val()=="Search"){y.$searchBox.val("").change();
y.manageClearCircleVisibility()
}},1)
};
u.isVirtualAssistant=function t(){return !!m("#virtual-assistant-search").length
};
return u
}();
var j={name:"Desktop Search",selector:k.headerSearch,init:function n(o){return new g(o)
}};
HSBC_utils.registerComponent(j)
})(Bootstrap.jQuery)
}),(function(c,a,f){a.__esModule=true;
function e(h,i){if(!(h instanceof i)){throw new TypeError("Cannot call a class as a function")
}}var d=Bootstrap.jQuery,b=HSBC_utils.keyCodes;
var g=a.SearchMobileSuggestionsAlly=function(){function l(m){e(this,l);
this.$el=m.$el;
this.$suggestionItems=m.$suggestionItems;
this.context=m;
this.bindUIEvents()
}l.prototype.bindUIEvents=function j(){var m=this;
this.context.$searchBox.on("keyup",function(o){if(m.context.results.length){var n;
var p=(n={},n[b.DOWN]=function(){return m.$suggestionItems.first().focus()
},n[b.ESC]=function(){return m.context.hideSuggestions()
},n);
m.handleKeyPress(o,p)
}})
};
l.prototype.bindSuggestionsUIEvents=function i(){var m=this;
this.$suggestionItems.on("keydown",function(n){var o;
var p=(o={},o[b.ENTER]=m.context.handleSuggestionChoice,o[b.ESC]=m.context.hideSuggestions,o[b.DOWN]=function(q){return q.next().focus()
},o[b.UP]=function(q){return q.prev().focus()
},o);
m.handleKeyPress(n,p)
});
this.$suggestionItems.first().on("keydown",function(n){return m.handleArrowKeys(n,true)
});
this.$suggestionItems.last().on("keydown",function(n){return m.handleArrowKeys(n,false)
})
};
l.prototype.handleArrowKeys=function h(n,m){var o=n.keyCode===(m?b.UP:b.DOWN);
if(o){this.hideSuggestions()
}};
l.prototype.handleKeyPress=function k(o,p){var n=o.keyCode,m=d(o.target);
if(p.hasOwnProperty(n)){o.preventDefault();
p[n].call(this,m)
}};
return l
}()
}),(function(d,b,f){b.__esModule=true;
function e(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}var a={openSearchBox:"data-aria-label-open-searchbox",closeSearchBox:"data-aria-label-close-searchbox",displaySearchResults:"data-aria-label-display-search-results"};
var c=b.DesktopSearchAlly=function(){function j(m){e(this,j);
this.$el=m.$el;
this.$searchButton=m.$searchButton;
this.$searchBox=m.$searchBox;
this.context=m;
this.setSearchButtonAriaLabelTexts();
this.bindUIEvents()
}j.prototype.setSearchButtonAriaLabelTexts=function i(){this.searchButtonAriaLabels={open:this.$searchButton.attr(a.openSearchBox),close:this.$searchButton.attr(a.closeSearchBox),displayResults:this.$searchButton.attr(a.displaySearchResults)}
};
j.prototype.bindUIEvents=function k(){var n=this;
var m=this.context;
this.$searchBox.on("keyup",function(){m.manageClearCircleVisibility();
m.manageTypeOfSearchButton();
n.setSearchButtonTabindex()
}).on("change",function(){return n.submitText()
});
this.$searchButton.on("click",function(){return n.toggleSearchButtonText()
});
m.$desktopClearCircle.on("click",function(){n.$searchButton.attr("aria-label",n.searchButtonAriaLabels.close);
n.setSearchButtonTabindex()
})
};
j.prototype.toggleSearchButtonText=function h(){var m=this.context.isExpanded()?this.searchButtonAriaLabels.close:this.searchButtonAriaLabels.open;
this.$searchButton.attr("aria-label",m);
this.setSearchButtonTabindex()
};
j.prototype.submitText=function l(){this.$searchButton.attr("aria-label",this.searchButtonAriaLabels.displayResults)
};
j.prototype.setSearchButtonTabindex=function g(){if(this.context.isExpanded()&&this.context.isSearchBoxEmpty()){this.$searchButton.attr("tabindex",-1);
this.$searchButton.attr("aria-hidden","true")
}else{this.$searchButton.attr("tabindex",0);
this.$searchButton.attr("aria-hidden","false")
}};
return j
}()
}),(function(b,a,d){function c(e,f){if(!(e instanceof f)){throw new TypeError("Cannot call a class as a function")
}}(function(h){var l={skipToContentLink:".skip-to-content-link",topOfContent:".top-of-content",configPage:".configPage",headerMain:".header-main"},f={active:"active",patternLab:"header-patternlab",noPatternLab:"header-no-patternlab"},g=h(document).find("body"),i=HSBC_utils.keyCodes,j=500;
var k=function(){function s(t){c(this,s);
this.$header=h(t);
this.cacheDomElements();
this.bindUiEvents();
this.togglePositionFixed();
this.detectPatternLab();
this.zoomDetectionTimeout()
}s.prototype.detectPatternLab=function p(){if(HSBC_utils.isPatternLab()){this.$header.addClass(f.patternLab)
}else{this.$header.addClass(f.noPatternLab)
}};
s.prototype.cacheDomElements=function n(){this.$skipToContentLink=this.$header.find(l.skipToContentLink);
this.$topOfContent=h(document).find(l.topOfContent)
};
s.prototype.togglePositionFixed=function o(){if(!h(document.body).hasClass(f.configPage)&&!HSBC_utils.isEditMode()&&!HSBC_utils.isPatternLab()){this.$header.css("position","fixed");
this.$header.parent().css("padding-top",this.$header.innerHeight());
h(window).trigger("headerResize")
}};
s.prototype.bindUiEvents=function r(){var t=this;
this.$skipToContentLink.on("click",function(u){t.$topOfContent.addClass(f.active).focus();
u.preventDefault()
});
h(window).on("load resize headerMessageChange",function(){t.togglePositionFixed()
})
};
s.prototype.zoomDetectionTimeout=function q(){var v=this;
var u=h(l.headerMain),t=u.height();
setInterval(function(){var w=u.height();
if(w!=t){t=w;
v.togglePositionFixed()
}},j)
};
return s
}();
var e={name:"header",selector:".header",init:function m(n){return new k(n)
}};
HSBC_utils.registerComponent(e)
})(Bootstrap.jQuery)
}),(function(b,a,d){function c(e,f){if(!(e instanceof f)){throw new TypeError("Cannot call a class as a function")
}}(function(k){var h={HTML_SEP:"-",ISO_SEP:"_",HSBC_CLIENT_COOKIE:"HSBC_CLIENT_COOKIE",PREFERRED_LOCALE_PREFIX:"PreferredLocale="},g={localeManagement:".locale-management",selectedTriggerLink:".is-selected a[lang]",triggerLink:"a[lang]"},j=86400000;
var i={path:"/",expires:365};
var f=function(){function o(t){c(this,o);
this.$el=k(t);
this.$selectedTriggerLink=this.$el.find(g.selectedTriggerLink);
this.fetchGlobalSettings();
this.observeTriggers();
this.initLocale()
}o.prototype.initLocale=function n(){this.updateLocale(this.$selectedTriggerLink.attr("lang"))
};
o.prototype.fetchGlobalSettings=function q(){var t=k("body").data("global-settings");
if(t&&t.cookieDomain){i.domain=t.cookieDomain
}};
o.prototype.observeTriggers=function p(){var t=this;
this.$el.find(g.triggerLink).on("click",function(u){t.updateLocale(u.target.lang)
})
};
o.prototype.updateLocale=function s(v){var u=this.getLocale(),t=e(v)||"";
if(t.length&&u!=t){this.setLocale(t)
}};
o.prototype.setLocale=function m(u){var w=HSBC_utils.getCookie(h.HSBC_CLIENT_COOKIE),t=void 0;
var v=new RegExp("^(.*,)?"+h.PREFERRED_LOCALE_PREFIX+"[^,]*(,.*)?$");
u=u||"";
t=h.PREFERRED_LOCALE_PREFIX+u;
if(!w){w=t
}else{if(w.indexOf(h.PREFERRED_LOCALE_PREFIX)!==-1){w=w.replace(v,"$1"+t+"$2")
}else{w=w+","+t
}}HSBC_utils.deleteCookie(h.HSBC_CLIENT_COOKIE,i.path);
HSBC_utils.setCookie(h.HSBC_CLIENT_COOKIE,w,i,j)
};
o.prototype.getLocale=function r(){var u=HSBC_utils.getCookie(h.HSBC_CLIENT_COOKIE),t=new RegExp("^(.*,)?"+h.PREFERRED_LOCALE_PREFIX+"([^,]*)(,.*)?$");
if(u&&u.indexOf(h.PREFERRED_LOCALE_PREFIX)!==-1){return u.replace(t,"$2")
}return null
};
return o
}();
function e(n){var m=n;
if(n&&n.indexOf(h.HTML_SEP)!==-1){m=n.split(h.HTML_SEP)[0];
m+=h.ISO_SEP;
m+=n.split(h.HTML_SEP)[1].toUpperCase()
}return m
}HSBC_utils.registerComponent({name:"localemanagement",selector:g.localeManagement,init:function l(m){return new f(m)
}})
})(Bootstrap.jQuery)
}),(function(b,a,e){var f=e(121);
var d=e(16);
function c(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}(function(k){var i={expanded:"is-expanded",hidden:"hidden"},h={selectedItem:".selected-item",itemList:".item-list",items:".item",loginButtonExpanded:".login-button-expanded",loginButtonCollapsed:".login-button-collapsed"},j={up:"icon-chevron-up-small",down:"icon-chevron-down-small"};
var m=function(){function r(s){c(this,r);
this.$el=k(s);
this.isExpanded=false;
this.$arrowIcon=this.$el.find(".icon").first();
this.$menuItems=this.$el.find(h.items+" a");
this.$selectedItem=this.$el.find(h.selectedItem);
this.$loginButtonExpanded=this.$selectedItem.find(h.loginButtonExpanded);
this.$loginButtonCollapsed=this.$selectedItem.find(h.loginButtonCollapsed);
this.bindUIEvents();
new f.HeaderDropdownAlly(this);
new d.HeaderLoggedUserState(this)
}r.prototype.bindUIEvents=function n(){var s=this;
this.$selectedItem.on("click",function(){s.toggleDropdown()
});
this.$menuItems.on("click",function(){return s.collapse()
});
k(document).on("click",function(t){var u=t.target;
if(!s.$el.is(u)&&!s.$el.has(u).length){s.collapse()
}})
};
r.prototype.toggleDropdown=function p(){if(this.isExpanded){this.collapse()
}else{this.expand()
}};
r.prototype.expand=function o(){this.$el.addClass(i.expanded);
this.$arrowIcon.addClass(j.up).removeClass(j.down);
this.$loginButtonExpanded.removeClass(i.hidden);
this.$loginButtonCollapsed.addClass(i.hidden);
this.isExpanded=true
};
r.prototype.collapse=function q(){this.$el.removeClass(i.expanded);
this.$arrowIcon.addClass(j.down).removeClass(j.up);
this.$loginButtonExpanded.addClass(i.hidden);
this.$loginButtonCollapsed.removeClass(i.hidden);
this.isExpanded=false
};
return r
}();
var g={name:"header-dropdown",selector:".header-dropdown",init:function l(n){return new m(n)
}};
HSBC_utils.registerComponent(g)
})(Bootstrap.jQuery)
}),(function(d,a,g){a.__esModule=true;
function f(i,j){if(!(i instanceof j)){throw new TypeError("Cannot call a class as a function")
}}var c={itemList:".item-list",items:".item",onlyOneLink:"only-one-link"},b=HSBC_utils.keyCodes,e=Bootstrap.jQuery;
var h=a.HeaderDropdownAlly=function(){function l(m){f(this,l);
this.context=m;
this.$el=m.$el;
this.$menuItems=this.$el.find(c.items+" a");
this.bindUIEvents()
}l.prototype.bindUIEvents=function j(){var n=this;
var m=this.context;
this.$menuItems.on("keydown",function(o){return n.handleItemsKeyEvent(o)
});
m.$selectedItem.on("click",function(){if(m.isExpanded){n.$menuItems.first().focus()
}}).on("keydown",function(r){var q=r.keyCode,p=q===b.SPACE,o=q===b.ENTER;
if(p||o){m.$selectedItem.trigger("click");
if(n.isLogonWithOnlyOneLink(r)){return
}r.preventDefault()
}})
};
l.prototype.isLogonWithOnlyOneLink=function k(m){return m.target.classList.contains(c.onlyOneLink)
};
l.prototype.handleItemsKeyEvent=function i(n){var o=this.context,w=n.keyCode,r=n.shiftKey,u=w===b.ENTER,q=w===b.DOWN,v=w===b.UP,m=w===b.TAB,t=m&&r,p=e(n.target),s=p.parent();
if(q){s.next().find("a").focus()
}else{if(v||t){if(this.$menuItems.first().is(p)){o.toggleDropdown();
o.$selectedItem.focus()
}else{s.prev().find("a").focus()
}}}if(m&&!r){if(this.$menuItems.last().is(p)){o.toggleDropdown()
}}else{if(!u){n.preventDefault()
}}};
return l
}()
}),(function(b,a,f){var c=f(123);
var e=f(16);
function d(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}(function(k){if(HSBC_utils.isIE8orLower()){return
}var h={sidebar:"header-mobile-sidebar",sidebarTrigger:"header-sidebar-trigger",sidebarOpen:"sidebar-open",sidebarOverlay:"header-mobile-overlay",logoMobile:"header-mobile-logo",expanded:"expanded",active:"active",expandedAndActive:"expanded active",safariFixPadding:"safari-fix-padding",submenuTrigger:"sidebar-submenu-trigger",submenu:"sidebar-submenu-wrapper",doormatTrigger:"header-main-navigation-item",doormatSidebarTitle:"header-doormat-mobile-title",sidebarLinks:"header-mobile-sidebar-footer",sidebarHiddenCloseButton:"sidebar-hidden-close-button",closeSubmenuTrigger:"close-submenu-trigger",submenuExpanded:"submenu-expanded",doormatContainer:"doormat-container",doormatMenu:"doormat-menu",searchBox:"search-box",headerSearchButton:"header-search-button",contentOverlay:"header-mobile-overlay"},i=k("html"),j=k("body"),n={doormatSectionHeading:".sidebar-submenu-label, .footer-section-title",doormatSidebarItems:".header-doormat-mobile-title, .header-mobile-selected-item, .search-box, .header-mobile-search-container"};
var l=void 0;
var m=function(){function D(F){d(this,D);
D.initSelectorsObject();
this.cacheDomElements(F);
this.bindUIEvents();
this.ally=new c.MobileHeaderAlly(this);
new e.HeaderLoggedUserState(this)
}D.prototype.cacheDomElements=function t(F){this.$el=k(F);
this.$sidebarTrigger=this.$el.find(n.sidebarTrigger);
this.$sidebar=this.$el.find(n.sidebar);
this.$header=this.$el.parent();
this.$sidebarOverlay=this.$el.find(n.sidebarOverlay);
this.$logoMobile=this.$el.find(n.logoMobile);
this.$sidebarLinks=this.$el.find(n.sidebarLinks);
this.$sidebarHiddenCloseButton=this.$el.find(n.sidebarHiddenCloseButton);
this.$submenuWrapper=this.$el.find(n.submenu);
this.$doormatContainer=this.$el.find(n.doormatContainer);
this.$doormatMenu=this.$el.find(n.doormatMenu);
this.$doormatSidebarTitle=this.$el.find(n.doormatSidebarTitle);
this.$doormatSidebarItems=this.$el.find(n.doormatSidebarItems);
this.$submenuTrigger=this.$el.find(n.submenuTrigger);
this.$closeSubmenuTrigger=this.$el.find(n.closeSubmenuTrigger);
this.$searchBox=this.$el.find(n.searchBox);
this.$doormatSectionHeading=this.$el.find(n.doormatSectionHeading);
this.$headerSearchButton=this.$el.find(n.headerSearchButton);
this.$contentOverlay=this.$el.find(n.contentOverlay)
};
D.prototype.bindUIEvents=function q(){var F=this;
this.$el.on("click",n.submenuTrigger,function(G){return F.toggleSubmenu(G)
}).on("click",n.closeSubmenuTrigger,function(){return F.collapseSubmenu()
});
this.$sidebarTrigger.on("click",function(G){G.preventDefault();
F.toggleSidebar()
});
this.$sidebarHiddenCloseButton.on("click",function(G){G.preventDefault();
F.closeSidebar();
F.$sidebarTrigger.focus()
});
this.$sidebarOverlay.on("click",function(){return F.closeSidebar()
});
k(window).on("resize",function(){return F.resizeEventHandler()
}).on("load",function(){return F.fixPaddingSafari()
}).on("resize resize_when_banner_closed",function(){F.calculateOverlayPosition();
F.ally.calculatePositionSidebarHiddenCloseButton()
})
};
D.prototype.toggleSidebar=function y(){if(this.isExpanded()){this.closeSidebar()
}else{this.openSidebar()
}};
D.prototype.isExpanded=function p(){return this.$sidebar.hasClass(h.expandedAndActive)
};
D.prototype.openSidebar=function C(){this.$sidebar.addClass(h.expandedAndActive);
l=k(document.body).scrollTop()||i.scrollTop();
k(document.body).addClass(h.sidebarOpen).css("marginTop",-l);
this.positionSidebarLinks();
this.ally.openSidebar();
this.calculateOverlayPosition();
this.ally.makePageContentInaccessible();
this.$sidebarHiddenCloseButton.addClass(h.sidebarOpen);
this.ally.calculatePositionSidebarHiddenCloseButton()
};
D.prototype.closeSidebar=function x(){k(document.body).css("marginTop",0);
this.$sidebar.removeClass(h.expandedAndActive+" "+h.submenuExpanded);
k(document.body).removeClass(h.sidebarOpen);
this.$sidebar.find(n.expandedOrActive).removeClass(h.expandedAndActive);
D.scrollTop();
this.ally.closeSidebar();
this.ally.makePageContentAccessible();
this.$sidebarHiddenCloseButton.removeClass(h.sidebarOpen);
if(z.length){z.css("top","")
}};
var z=k(".header-mobile-selected-item, .header .header-mobile-sidebar-content .header-main-navigation-item .header-doormat-mobile-title, .header-mobile-footer-item");
D.prototype.toggleSubmenu=function v(K){var H=k(K.target),G=H.hasClass(h.submenuTrigger)?H:H.closest(n.submenuTrigger),F=G.data("target"),J=this.$el.find("[data-source="+F+"]"),I=J.hasClass(h.expandedAndActive);
this.collapseSubmenu();
if(!I){G.addClass(h.expandedAndActive).attr("aria-expanded","true");
this.ally.openSubmenu();
J.removeAttr("tabindex").addClass(h.expandedAndActive).attr("aria-hidden","false").find(HSBC_utils.focusables.join()).first().focus();
this.$sidebar.addClass(h.submenuExpanded);
K.preventDefault();
if(z.length){z.css("top","5rem")
}}else{if(z.length){z.css("top","")
}}this.ally.updateFocusables()
};
D.prototype.collapseSubmenu=function A(){var F=this.$submenuTrigger.filter(".expanded");
this.$sidebar.removeClass(h.submenuExpanded).find(n.expandedOrActive).removeClass(h.expandedAndActive);
this.ally.closeSubmenu();
if(z.length){z.css("top","")
}if(k(document.activeElement).is(this.$closeSubmenuTrigger)){F.focus()
}this.ally.updateFocusables()
};
D.prototype.fixPaddingSafari=function E(){if(HSBC_utils.isSafari){this.$doormatContainer.addClass(h.safariFixPadding)
}};
D.prototype.positionSidebarLinks=function u(){try{var G=this.$sidebarLinks.siblings(":visible").eq(-2),J=G.outerHeight(),I=this.$sidebarLinks.outerHeight();
var F=0;
if(this.$sidebar.hasClass(h.expandedAndActive)){F=k(window).height()-G.offset().top-J-I
}if(F>0){this.$sidebarLinks.css("top",F)
}}catch(H){}};
D.prototype.resizeEventHandler=function B(){if(HSBC_utils.matchMedia.desktop){this.closeSidebar()
}else{this.positionSidebarLinks()
}};
D.prototype.calculateOverlayPosition=function w(){this.$contentOverlay.css("top",this.$header.innerHeight())
};
D.initSelectorsObject=function r(){Object.keys(h).map(function(F){return n[F]="."+h[F]
});
n.expandedOrActive="."+h.expanded+",."+h.active
};
D.scrollTop=function s(){k(document.body).scrollTop(l);
i.scrollTop(l)
};
return D
}();
var g={name:"Mobile Header",selector:".header-mobile",init:function o(p){return new m(p)
}};
HSBC_utils.registerComponent(g)
})(Bootstrap.jQuery)
}),(function(b,e,a){e.__esModule=true;
function f(j,k){if(!(j instanceof k)){throw new TypeError("Cannot call a class as a function")
}}var d={sidebarTrigger:"header-sidebar-trigger",submenuTrigger:"sidebar-submenu-trigger",closeSubmenuTrigger:"close-submenu-trigger",expanded:"expanded",hidden:"hidden",expandedAndActive:"expanded active",submenuExpanded:"submenu-expanded"},i={doormatTrigger:".header-main-navigation-item"},g=Bootstrap.jQuery,h=HSBC_utils.keyCodes;
var c=e.MobileHeaderAlly=function(){function o(A){f(this,o);
this.$el=A.$el;
this.$target=A.$target;
this.$sidebar=A.$sidebar;
this.$header=A.$header;
this.$sidebarTrigger=A.$sidebarTrigger;
this.$doormatMenu=A.$doormatMenu;
this.$doormatSidebarTitle=A.$doormatSidebarTitle;
this.$doormatSidebarItems=A.$doormatSidebarItems;
this.$submenuTrigger=A.$submenuTrigger;
this.$closeSubmenuTrigger=A.$closeSubmenuTrigger;
this.$submenuWrapper=A.$submenuWrapper;
this.$searchBox=A.$searchBox;
this.$doormatSectionHeading=A.$doormatSectionHeading;
this.$headerSearchButton=A.$headerSearchButton;
this.$sidebarHiddenCloseButton=A.$sidebarHiddenCloseButton;
this.context=A;
this.updateDoormatAccessibility();
this.setSidebarAriaLabelTexts();
this.updateFocusables();
this.bindUIEvents()
}o.prototype.bindUIEvents=function j(){var A=this;
this.$el.on("keydown",function(B){return A.keydownEventHandler(B)
});
this.$sidebarTrigger.on("click",function(){return A.updateDoormatAccessibility()
})
};
o.prototype.keydownEventHandler=function y(C){var B=C.keyCode,D=B===h.TAB,A=B===h.ENTER;
if(D){this.tabPressedEventHandler(C)
}else{if(A){this.enterPressedEventHandler(C)
}}};
o.prototype.tabPressedEventHandler=function x(E){var G=E.target,H=this.$sidebar.hasClass(d.expanded),D=G===this.$firstFocusable[0]&&E.shiftKey,B=G===this.$lastFocusable[0]&&!E.shiftKey,F=g(G).hasClass(d.sidebarTrigger),A=this.$sidebar.hasClass(d.submenuExpanded);
if(H&&F&&!A){var C=E.shiftKey?this.$lastFocusable:this.$firstFocusable;
C.focus();
E.preventDefault()
}else{if(H&&F&&A){this.$closeSubmenuTrigger.focus();
E.preventDefault()
}else{if(D||B){this.$sidebarTrigger.focus();
E.preventDefault()
}}}};
o.prototype.enterPressedEventHandler=function k(C){var B=this.context,A=g(C.target);
if(A.hasClass(d.submenuTrigger)){B.toggleSubmenu(C)
}else{if(A.hasClass(d.closeSubmenuTrigger)){B.collapseSubmenu()
}}};
o.prototype.updateDoormatAccessibility=function m(){this.$sidebar.find(i.doormatTrigger).removeAttr("tabindex aria-expanded").attr("role","presentation").children(this.$doormatSidebarTitle).attr("tabindex",0);
this.$submenuTrigger.attr({role:"menuitem","aria-haspopup":true})
};
o.prototype.setSidebarAriaLabelTexts=function s(){this.sideBarAriaLabels={open:this.$sidebarTrigger.attr("data-aria-label-open-menu"),close:this.$sidebarTrigger.attr("data-aria-label-close-menu")}
};
o.prototype.updateFocusables=function p(){var B=this.$sidebar.find(HSBC_utils.focusables.join()),A=B.filter(function(C,D){return g(D).css("display")!=="none"
});
this.$firstFocusable=A.first();
this.$lastFocusable=A.last()
};
o.prototype.closeSidebar=function q(){this.$sidebarTrigger.attr("aria-label",this.sideBarAriaLabels.open)
};
o.prototype.openSidebar=function v(){this.$sidebarTrigger.attr("aria-label",this.sideBarAriaLabels.close);
this.showSidebarForScreenReaders()
};
o.prototype.closeSubmenu=function n(){this.$submenuTrigger.attr("aria-expanded","false");
this.$closeSubmenuTrigger.addClass(d.hidden);
this.showSidebarForScreenReaders()
};
o.prototype.openSubmenu=function u(){this.$closeSubmenuTrigger.removeClass(d.hidden);
this.hideSidebarForScreenReaders()
};
o.prototype.hideSidebarForScreenReaders=function w(){this.$doormatSectionHeading.attr("tabindex",0);
this.$doormatSidebarItems.attr({tabindex:-1,"aria-hidden":"true"});
this.$submenuWrapper.attr("aria-hidden","false")
};
o.prototype.showSidebarForScreenReaders=function t(){this.$doormatMenu.attr("aria-hidden","true");
this.$doormatSectionHeading.attr("tabindex",-1);
this.$doormatSidebarItems.attr({tabindex:0,"aria-hidden":"false"});
this.$submenuWrapper.attr("aria-hidden","true")
};
o.prototype.makePageContentInaccessible=function z(){this.$header.siblings("div").wrapAll(g("<div>").addClass("page"));
this.$header.siblings(".page").attr("aria-hidden","true");
this.$sidebar.siblings("div").attr("aria-hidden","true")
};
o.prototype.makePageContentAccessible=function r(){this.$header.siblings(".page").children().unwrap();
this.$sidebar.siblings("div").removeAttr("aria-hidden")
};
o.prototype.calculatePositionSidebarHiddenCloseButton=function l(){this.$sidebarHiddenCloseButton.css("top",this.$header.innerHeight()-28)
};
return o
}()
}),(function(d,b,f){var a=f(15);
var c=f(125);
function e(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}(function(l){var k={searchContainer:".header-mobile-search-container",clearCircle:".clear-container",searchBox:".search-box",searchOverlay:".search-overlay"},j={hidden:"hidden"};
var h=function(){function n(t){e(this,n);
this.$el=l(t);
this.$clearCircle=this.$el.find(k.clearCircle);
this.$searchBox=this.$el.find(k.searchBox);
this.$searchOverlay=this.$el.find(k.searchOverlay);
this.suggestions=new a.SearchMobileSuggestions(this.$el);
this.bindUIEvents();
this.manageClearCircleVisibility();
new c.SearchMobileAlly(this)
}n.prototype.bindUIEvents=function p(){var w=this;
this.$clearCircle.on("click",function(){w.clearSearchBox();
w.manageClearCircleVisibility()
});
this.$searchBox.on({blur:function v(){return w.setOverlayVisibility(false)
},focusin:function u(){return w.setOverlayVisibility(true)
},input:function t(){return w.handleInputChange()
}})
};
n.prototype.handleInputChange=function s(){this.manageClearCircleVisibility()
};
n.prototype.clearSearchBox=function q(){this.$searchBox.val("").focus()
};
n.prototype.manageClearCircleVisibility=function o(){g(this.$clearCircle,this.$searchBox.val().length)
};
n.prototype.setOverlayVisibility=function r(t){g(this.$searchOverlay,t)
};
return n
}();
function g(o,n){if(n){o.removeClass(j.hidden)
}else{o.addClass(j.hidden)
}}var i={name:"Mobile Search",selector:k.searchContainer,init:function m(n){return new h(n)
}};
HSBC_utils.registerComponent(i)
})(Bootstrap.jQuery)
}),(function(d,a,f){a.__esModule=true;
function e(g,h){if(!(g instanceof h)){throw new TypeError("Cannot call a class as a function")
}}var c={searchButton:".header-search-button"};
var b=a.SearchMobileAlly=function(){function h(j){e(this,h);
this.$el=j.$el;
this.context=j;
this.$searchButton=this.$el.find(c.searchButton);
this.changeSearchButtonBehavior();
this.bindUIEvents()
}h.prototype.bindUIEvents=function g(){var k=this;
var j=this.context;
j.$searchBox.on("input",function(){return k.changeSearchButtonBehavior()
});
j.$clearCircle.on("click",function(){return k.changeSearchButtonBehavior()
})
};
h.prototype.changeSearchButtonBehavior=function i(){var j=this.context,l=!j.$searchBox.val().length?-1:0,k=!j.$searchBox.val().length?"true":"false";
this.$searchButton.attr("tabindex",l);
this.$searchButton.attr("aria-hidden",k)
};
return h
}()
}),(function(b,a,c){}),(function(c,v,d){var e=d(44);
function f(w,x){if(!(w instanceof x)){throw new TypeError("Cannot call a class as a function")
}}var h=Bootstrap.jQuery,t={description:"text-container",modalWindow:"M-MODWIN-DEV",modalWindowOverlay:"modal-window-overlay",externalLinkModal:"external-link-modal",cancelTrigger:"mw-cancel-trigger",allowTrigger:"mw-allow-trigger",isVisible:"is-visible",hide:"hidden",modalAnnouncement:"modal-announcement-sr-text",scrollbarHidden:"vertical-scrollbar-hidden"},r="data-content-id",m="default",g={link:"a",component:"[data-external-link-modal-url]",allContents:"[data-content-id]",allNonDefaultContents:"["+r+"]["+r+' != "'+m+'"]'},a="external-link-modal-url",j={animation:200},q=h("body"),u=h(document);
var k=function(){function F(K){f(this,F);
this.$moduleElement=h(K);
this.modalSource=this.$moduleElement.data(a);
this.$link=null;
this.$modal=null;
this.bindUIEvents();
this.allyModule=new e.ModalWindowAlly(this)
}F.prototype.bindUIEvents=function x(){var K=this;
if(this.modalSource){u.on("click",g.link,function(L){return K.linkClickHandler(L)
}).on("modalWindow:switchedToEdit",g.link,function(L){return K.close()
})
}};
F.prototype.linkClickHandler=function J(L){this.$link=h(L.target);
if(L.target.tagName.toLowerCase()!==g.link){this.$link=this.$link.parents(g.link)
}var K=this.$link.attr("href")||"";
if(!K.length){return
}this.$link.data("which",L.which);
if(L.which!=1){L.preventDefault()
}if(this.isModalUrl(K,window.dpwsExternalLinkConfiguration)){L.preventDefault();
if(!HSBC_utils.isEditMode()){if(!this.$modal){this.getMarkup();
n(q,t.scrollbarHidden)
}else{this.open();
n(q,t.scrollbarHidden)
}}}};
F.prototype.isModalUrl=function D(L,Q){var M=new RegExp("(^#)|(^/)|(^../)|(^mailto:)|(^tel:)|(^javascript*)((?!.location=).)*$"),P=new RegExp("(^http)|(^ftp)|(^//)|(^javascript.*.location=)");
if(P.test(L)){var K=L.split("//").slice(1)[0],N=K.split("/")[0],O=K.split("/").slice(1).join("/");
this.contentId=b(N,O,Q.blacklist);
return this.contentId||!p(N,O,Q.whitelist)
}else{if(M.test(L)){return false
}}return true
};
F.prototype.getMarkup=function E(){var L=this;
if(!this.modalSource){return
}h.ajax({type:"GET",dataType:"HTML",url:this.modalSource,success:function M(N){L.setUpModalWindow(h('<div class="'+t.modalWindowOverlay+" "+t.externalLinkModal+'"><div class="'+t.modalWindow+'">'+N+"</div></div>"));
L.open()
},error:function K(N){return console.error(N)
}})
};
F.prototype.open=function C(){var K=this;
this.setSpecificContent();
this.$modal.addClass(t.isVisible).removeAttr("aria-hidden").siblings().attr("aria-hidden","true");
this.setTabIndexElementValue(-1,this.$descriptionEl);
this.defer(function(){return K.$descriptionEl.focus()
},j.animation)
};
F.prototype.setSpecificContent=function A(){this.$modal.find(g.allContents).addClass(t.hide);
this.$modal.find("["+r+'="'+(this.contentId||m)+'"]').removeClass(t.hide)
};
F.prototype.close=function I(){if(this.$modal){var L=this.$modal.find("."+t.modalAnnouncement);
L.removeClass(t.hide);
this.$modal.removeClass(t.isVisible).attr("aria-hidden","true").siblings().removeAttr("aria-hidden")
}if(this.$link){this.$link.removeAttr("data-which");
var K=this;
this.defer(function(){K.$link.get(0).focus()
})
}n(q,t.scrollbarHidden)
};
F.prototype.defer=function w(L,K){setTimeout(L||function(){},K||5)
};
F.prototype.leave=function H(){var K=this.$link.attr("href"),L=this.$link.data("which")==2?"_blank":this.$link.attr("target");
if(L){window.open(K,L)
}else{window.location.href=K
}this.close()
};
F.prototype.setUpModalWindow=function y(K){this.$modal=u.find(t.externalLinkModal);
if(!this.$modal.length){this.$modal=K;
this.$modal.appendTo(q)
}this.$modal.removeClass(t.isVisible);
this.cacheModalElements();
this.lateBindUIEvents();
this.$modal.find(g.allNonDefaultContents).each(function(){h(this).parent().replaceWith(this)
})
};
F.prototype.setTabIndexElementValue=function G(L,K){if(!K.attr("tabindex")){K.attr("tabindex",L)
}else{return
}};
F.prototype.cacheModalElements=function z(){this.$cancelTriggers=this.$modal.find("."+t.cancelTrigger);
this.$allowTriggers=this.$modal.find("."+t.allowTrigger);
this.$descriptionEl=this.$modal.find("."+t.description)
};
F.prototype.lateBindUIEvents=function B(){var K=this;
this.$cancelTriggers.on("click",function(L){return K.close()
});
this.$allowTriggers.on("click",function(L){return K.leave()
});
this.$modal.on("click",function(M){var L=h(M.target);
if(!i(L)&&!L.hasClass(t.modalWindowOverlay)){K.close()
}});
this.allyModule.bindUIEvents()
};
return F
}();
function n(x,w){x.hasClass(w)?x.removeClass(w):x.addClass(w)
}function i(w){return w.parents("."+t.modalWindow).length
}function o(){h(g.link).trigger("modalWindow:switchedToEdit")
}function b(A,B,z){for(var w in z){var x=z[w];
for(var y=0;
y<x.length;
y++){if(l(A,B,x[y])){return w
}}}return null
}function p(y,z,x){for(var w=0;
w<x.length;
w++){if(l(y,z,x[w])){return true
}}return false
}function l(A,B,x){var w=x,z="",y=false;
if(x.indexOf("://")>=0){x=w=x.split("://").slice(1)[0]
}if(x.indexOf("/")>=0){w=x.split("/")[0];
z=x.split("/").slice(1).join("/")
}if(A.length>=w.length){if(A==w){y=true
}else{if(A.indexOf(w)>=0){if(A.lastIndexOf("."+w)==A.length-w.length-1){y=true
}}}if(y){if(z.length==0||B.indexOf(z)==0){return true
}}}return false
}HSBC_utils.registerComponent({name:"externalLinkModalWindow",selector:g.component,init:function s(w){return new k(w)
},switchToEditHandler:o})
}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){}),(function(b,a,c){})]);
jQuery(document).ready(function(){var O=jQuery("#dcc-header");
var k=O.find(".log-off"),t=k.attr("data-logoutService"),s=k.attr("data-logOffUrl"),M=k.attr("data-navigateAfterServiceCall");
var N={};
N.logoutService=t;
N.logOffUrl=s;
N.navigateAfterServiceCall=M;
jQuery(document.body).on("show.bs.modal,shown.bs.modal",function(){if(navigator.userAgent.indexOf("Windows")!=-1){O.removeClass("grid")
}O.css("padding-right","17px");
if(window.innerWidth<760){setTimeout(function(){jQuery(".modal").css("padding-right","0")
},0)
}});
jQuery(document.body).on("hide.bs.modal,hidden.bs.modal",function(){O.addClass("grid")
});
var y="<div id='dcclogoffconfig' style='display:none;'>"+JSON.stringify(N)+"</div>";
jQuery(document.body).append(y);
k.on("click",function(j){var i=j.target.classList.contains("active");
if(!i){j.preventDefault();
D("leavePage",jQuery(this).attr("data-logoutservice"));
return false
}});
function D(i,e){var Q={url:e,isLogOffClicked:true};
var j=new CustomEvent(i,{detail:Q});
window.dispatchEvent(j)
}var v=O.find(".locale-management.lang-selectors li a");
var d=window.location.search;
var K=d!=="";
for(var J=0;
J<v.length;
J++){var q=v[J].href.indexOf("?")!==-1;
var g=q?v[J].href.substring(v[J].href.indexOf("?")):"";
if(K&&d!==g){if(g===""){v[J].href=v[J].href+d
}else{v[J].href=v[J].href.substring(0,v[J].href.indexOf("?")+1)+d
}}}var f=O.find(".row .header-main-navigation-item .doormat-container .doormat-links li a i, .header-mobile-doormat .header-main-navigation-item .doormat-container .doormat-links li a i");
var z="cam-hint";
var u=window.HSBC_utils.getCookie("cam-level-hint");
u=u===undefined?"0":u;
for(var I=0;
I<f.length;
I++){var E=f[I].getAttribute("class");
f[I].setAttribute("class",E.replace(z,u))
}var b=O.find(".row .header-main-navigation-item .doormat-container .doormat-links li, .header-mobile-doormat .header-main-navigation-item .doormat-container .doormat-links li");
var w="seg-hint";
var n=window.HSBC_utils.getCookie("segment-hint");
n=n===undefined?"mass":n;
for(I=0;
I<b.length;
I++){var m=b[I].getAttribute("class");
b[I].setAttribute("class",m.replace(w,n))
}try{var A=document.querySelectorAll(".doormat-links li");
var B,H,l,G=location.hostname;
if(A){for(l=0;
l<A.length;
l++){B=A[l].getAttribute("data-defaultdomain");
H=A[l].getAttribute("data-configdomain");
if(B!=G&&H!=G){A[l].classList.add("hide")
}}}}catch(L){console.log("Something went wrong in link check=>",L.message)
}try{var r=document.getElementsByClassName("doormat-heading");
var P,c,o;
if(r){for(o=0;
o<r.length;
o++){P=r[o].nextSibling&&r[o].nextSibling;
c=r[o].nextSibling.nextSibling&&r[o].nextSibling.nextSibling;
if(c.childElementCount===0){r[o].classList.add("hide")
}}}}catch(L){console.log("Something went wrong in headings hide=>",L.message)
}if(navigator.userAgent.indexOf("MSIE")>-1||navigator.appVersion.indexOf("Trident/")>0){var x={HTML_SEP:"-",ISO_SEP:"_",HSBC_CLIENT_COOKIE:"HSBC_CLIENT_COOKIE",PREFERRED_LOCALE_PREFIX:"PreferredLocale="};
var F={path:"/",expires:365,secure:true,httpOnly:true};
var C=86400000;
O.find(".item-list.locale-management.lang-selectors li a[lang]").click(function(i){var e=jQuery(this).attr("href");
var j=jQuery(this).attr("lang");
i.preventDefault();
setTimeout(function(){var S=a(),R=p(j)||"";
if(R.length&&S!=R){h(R)
}var W=HSBC_utils.getCookie(x.HSBC_CLIENT_COOKIE);
R=R||"";
var Q=x.PREFERRED_LOCALE_PREFIX+R;
var T=new RegExp("^(.*,)?"+x.PREFERRED_LOCALE_PREFIX+"[^,]*(,.*)?jQuery");
if(!W){W=Q
}else{if(W.indexOf(x.PREFERRED_LOCALE_PREFIX)!==-1){W=W.replace(T,"jQuery1"+Q+"jQuery2")
}else{W=W+","+Q
}}HSBC_utils.deleteCookie(x.HSBC_CLIENT_COOKIE,F.path);
HSBC_utils.setCookie(x.HSBC_CLIENT_COOKIE,W,F,C);
var V=i.target.classList.contains("active");
if(!V){i.preventDefault();
var X={url:e,isLogOffClicked:false};
var U=new CustomEvent("leavePage",{detail:X});
window.dispatchEvent(U);
return false
}},0)
});
function a(){var i=HSBC_utils.getCookie(x.HSBC_CLIENT_COOKIE),e=new RegExp("^(.*,)?"+x.PREFERRED_LOCALE_PREFIX+"([^,]*)(,.*)?jQuery");
if(i&&i.indexOf(x.PREFERRED_LOCALE_PREFIX)!==-1){return i.replace(e,"jQuery2")
}return null
}function h(i){var Q=HSBC_utils.getCookie(x.HSBC_CLIENT_COOKIE);
i=i||"";
var e=x.PREFERRED_LOCALE_PREFIX+i;
var j=new RegExp("^(.*,)?"+x.PREFERRED_LOCALE_PREFIX+"[^,]*(,.*)?jQuery");
if(!Q){Q=e
}else{if(Q.indexOf(x.PREFERRED_LOCALE_PREFIX)!==-1){Q=Q.replace(j,"jQuery1"+e+"jQuery2")
}else{Q=Q+","+e
}}HSBC_utils.deleteCookie(x.HSBC_CLIENT_COOKIE,F.path);
HSBC_utils.setCookie(x.HSBC_CLIENT_COOKIE,Q,F,C)
}function p(i){var e=i;
if(i&&i.indexOf(x.HTML_SEP)!==-1){e=i.split(x.HTML_SEP)[0];
e+=x.ISO_SEP;
e+=i.split(x.HTML_SEP)[1].toUpperCase()
}return e
}}if(window.hsbcparm&&window.hsbcparm.initiate){window.hsbcparm.initiate(null,[])
}});